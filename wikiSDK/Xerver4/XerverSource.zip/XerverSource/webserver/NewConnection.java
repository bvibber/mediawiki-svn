//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.lang.Object.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * Every time a connection is established to Xerver, a <CODE>NewConnection</CODE> is created.
 * <BR>
 * <CODE>NewConnection</CODE> is a <CODE>Thread</CODE> and reads what the user requested and gives the user an appropriate response to his/her request.
 * <BR>
 * This is the most "important class" in Xerver and is probably the class you shall rewrite if you want to add more features to Xerver.
 * <BR>
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class NewConnection extends Thread
{
	private static String hiddenFolder="data"+File.separator;
	private static String errorFilesFolder="errorHTML"+File.separator;
	private static String s_replyServerName=XerverKernel.getXerverName();
	private final static boolean b_showErrors=false;	//Set this to true if and only if you are debugging and want to see what is happening all the time
	private final static int i_soTimeoutAfterKeepAliveTransfer=5000;
	private final static int i_maxsizeOfFileNameInDirListing=35;
	private final static int i_maxFileSizeLength=15;

	private final static String s_charsetToUse="";//"; charset=ISO-8859-2";

	public static long totalNumberOfHits=0;
	public static long totalNumberOfBytesDownloaded=0;	//Number of bytes sent via headers/directory listings etc. are NOT included. Only number of bytes from files are content. (HOWEVER: directory listing does show icons, which are downloaded as regular files, so a directory listing with an browser supporting images WILL result in that "totalNumberOfBytesDownloaded" will increase in value)

	public static MenuOptions myMenuOptions;
	public static int i_portNr;
	public static String [] as_indexNames;
	public static String [] as_sharedPaths;
	public static String [] as_fileExtensions;	//Is always lower case...
	public static String s_rootPath;
	public static MyHashTable myHT_runnableExtensions;
	public static MyHashTable myHT_allAliases;
	public static String [] as_xerverPasswd;
	public static boolean b_allowFolderListing;
	public static boolean b_allowTheseFileExtensions;
	public static boolean b_shareHiddenFiles;
	public static boolean b_startupWindowMode;	//If this is true, no window will be opened. If this is false, the awt-window will be used. NOTE: When you start this class from the Swing interface, this will be set to true so that the AWT-window won't popup		//When you call the XerverKernel()-constructor this varaiable will be set to true/false depending on what you have choosed in the setup-file: true=[0=you have choosen to run with no "window"]; false=[1 = you have choosen to use a static window (AWT); 2 = you have choosen to use the most advanced interface (with logging) (Swing)]
	public static boolean b_allowExecuteScript;
	public static String s_defaultRootLocationWithoutSlashAtEnd;
	public static Log l_logFile;

	public static boolean b_acceptConnections=true;
	private RunScript rs_process=null;
	private boolean b_environmentHasBeenSetUp, b_isRunningScript;	//b_isRunningScript is used so we know if a script is being run. If a script is being run, NewConnection shall not close the OutputStream, but ReadInputStreamSTDERR/STDOUT shall close the stream.  //b_isRunningScript is also used to that if an exception occur so that the NewConnection thread will terminate then we shall kill the script-process so that we don't end up with for example 20 perl.exe processes running
	private Date d_dateToday;
	private DateFormat df_dateFormat;
	private final static int i_maxLineLengthReadFromHeader=512;	//This can be set to anything you believe is suitable. This is to make sure we don't read and buffer very long header-lines sent by browser (in case a hacker would try to do this)
	//private static HashMap HM_allFileExt;

	public String 	s_errorStatus;					// By default: "200 OK"
	private String 	s_requestedDocumentWithoutUnescape,		// s_requestedDocumentWithoutUnescape is only used when someone visits "http://server.com/folder" and shall be redirected to "http://server.com/folder/". This is a MUST when the folder contains for example the swedish letters ���.
				//if someone visits "http://server.com/folder/folder2/file.txt" the variables below will get these values:
				s_requestDocument,			// "/folder/folder2/file.txt"
				s_requestedFolderLocation,	// "/folder/folder2/"
				s_requestedFileName,			// "file.txt"
				s_requestedFileExtension,	// "txt"
				s_requestedFileType,			// "text/plain"
				s_requestMethod,				// For example: "GET", "POST" or "HEAD"
				s_requestedHTTP,				// For example: "HTTP/1.1", "HTTP/1.0" or "HTTP/0.9"
				s_requestQueryString,		//	"file.htm?hello" ==> "hello", otherwise an empty string ("").
				s_loginRealm,			//When a user enters a password, he is entering for a whole realm
				s_encryptedPasswordGiven,			//Format: "encryptedPassword" (actually, it is "user:pass" but encrypted)
				s_visitorUsername,	//Note: the username for this login: [user:Donald; pass:Duck] can be "anOtherUsername" (it can of course also be "Donald")
				s_hostnameGivenByBrowser=null;	//The string sent by browser in "Host:" header.

	private String [] as_variablesGivenByBrowser, as_allEnvironmentVariables;	//For each and every time you are going to use any of these, call "createEnvironmentVariables()" (after you have called "createEnvironmentVariables()" once, you can call "createEnvironmentVariables()" several times without wasteing system resources (the first call does however "use system resources"))
	private Socket so_userConnection;
	private boolean b_logThisHit=false, b_useKeepAlive, b_hasBeenRedirected;	//reserved path ==> "/Image:XXXX"
	private int i_valueOfHttpContentLength;
	private int i_fileStatus;
	private final static int ISFILE=1;
	private final static int ISFOLDER=2;
	private final static int DOESNOTEXISTS=3;
	private final static int maxNumbersOfENVAccepted=200;	//Maximum number of environment variables the *browser can tell us* to create. (Note: We might have more than 200 environment variables; because we don't only create environment variables that the browser tell us to create).	  If a browser gives more than 200 environment variables, we just ignore the last variables.
	private DataInputStreamWithReadLine DISWR_theInputWeGetFromBrowser;
	private String tmpStr;	//NOTE: this should be used as a temporary variable when needed (for optimization purpose)...
	private static String s_defaultLoginName="[No Login]";
	private static String s_defaultRealmName="[No Login]";

	private static final String CONSTANT_POST="POST";	//Optimization...
	private static final String CONSTANT_HEAD="HEAD";	//We don't need to create these all the time...
	private static final String CONSTANT_HTTP09="HTTP/0.9";
	private static final String CONSTANT_HTTP10="HTTP/1.0";
	private static final String CONSTANT_HTTP11="HTTP/1.1";

	private static final int DATATYPE_HEADONLY=0;
	private static final int DATATYPE_BODYONLY=1;
	private static final int DATATYPE_BODYANDHEAD=2;
	private int i_sendWhatData;

	public NewConnection(Socket agrUserConnection, ThreadGroup argThreadGroup)// throws IOException
	{
		super(argThreadGroup,"Connection");
		//crateHashTableWithFileExtensions();
		initEverything(agrUserConnection);
	}

	private void initEverything(Socket agrUserConnection)
	{
try
{
	so_userConnection=agrUserConnection;
	if (!b_acceptConnections)
		so_userConnection.close();

	/* Init.. */
	b_hasBeenRedirected=false;
	b_useKeepAlive=true;
	b_environmentHasBeenSetUp=false;
	b_isRunningScript=false;
	s_loginRealm=s_defaultRealmName;
	s_visitorUsername=s_defaultLoginName;
	b_logThisHit=true;	//Always log
	i_valueOfHttpContentLength=0;
	i_fileStatus=-1;
	i_sendWhatData=DATATYPE_BODYANDHEAD;
	/* End Init... */

	d_dateToday = new Date();
	df_dateFormat=DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
	s_errorStatus="200 OK";	//By default the request is successful.
} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ NewConnection:\n"+e.getMessage());}
	}

	public void run()
	{
		try {
			s_requestedHTTP=null;
			s_requestMethod=null;
			s_requestDocument=null;

			readHeaderSentByBrowser();

			if (s_requestedHTTP==null || s_requestMethod==null || s_requestDocument==null)
			{
				s_requestDocument="/";	//Set this to something... don't matters to what. This will be sent together with the header for the "400 Bad Request".
				b_logThisHit=false;
				s_errorStatus="400 Bad Request";
				showError("The client has sent an invalid request.",errorFilesFolder,"error400badrequest.html");
			}

			setLocationParts(s_requestDocument,s_defaultRootLocationWithoutSlashAtEnd);//you MUST run "readHeaderSentByBrowser();" before you run this line!
			initializeRequestedFileExtension();

			if (b_hasBeenRedirected)	//IMPORTANT: This is especially important to make sure that a password protected folder wont be listed when entering "GET /secretFolderWITHOUTslashAtEnd HTTP/1.1"! Without this the server first sends the 302 Redirected header, and then the listing of the folder (which won't be listed with a normal browser, as the 302-header is sent first, but still, the hidden data is being showed! (with this we have prevented this scenario))
			{
				//Do nothing... The user has already been redirected
			}//Some paths are "reserved", such as "/Image:showFolder"...	//s_requestDocument has to be set when you run checkForReservedPaths
			else if (checkForReservedPaths())
			{
				//"checkForReservedPaths()" will show the image automatically
			}
			else if (!accessToFolderIsOK(s_requestedFolderLocation))
			{
				s_errorStatus="401 Not Authorized";
				showAccessDenied(s_loginRealm);
			}
			else if (!isFolderAllowed(s_requestedFolderLocation))
			{
				s_errorStatus="403 Forbidden";
				showError("You have tried to reach a folder you do not have permission to access ("+s_requestedFolderLocation+").",errorFilesFolder,"error403noaccessfolder.html");
			}
			else if (i_fileStatus == DOESNOTEXISTS)
			{
				s_errorStatus="404 Not Found";
				showError("The file you have tried to reach doesn't exist.",errorFilesFolder,"error404filedoesnotexist.html");
			}
			else if (s_requestedFileName.equals(""))//If you are visiting a folder and there is no index-file to show...
			{
				if (b_allowFolderListing)	//If you are allowed to list the content of this directory...
					showDirectorylisting();
				else
				{
					s_errorStatus="403 Forbidden";
					showError("Directory listing is not allowed.",errorFilesFolder,"error403nodirectorylisting.html");
				}
			}
			else if (!isFileExtensionAllowed(s_requestedFileExtension))
			{
				s_errorStatus="403 Forbidden";
				showError("You have tried to download a file with an extension that you are not allowed to download.",errorFilesFolder,"error403noaccessextension.html");
			}
			else if (!accessToFileIsOK(s_requestedFolderLocation+s_requestedFileName))
			{
				s_errorStatus="403 Forbidden";
				showError("Unfortunately, the web server couldn't read the requested file. If you are server admin, make sure the web server has read permission for the file.",errorFilesFolder,"error403webservercantreadfile.html");
			}
			else if (!isHTTPrecognized(s_requestedHTTP))
			{
				s_errorStatus="505 HTTP Version Not Supported";
				showError("Unfortunately, the web server doesn't support "+s_requestedHTTP+".",errorFilesFolder,"error505unknownhttp.html");
			}
			else
			{
				returnThisPage(s_requestedFolderLocation+s_requestedFileName);//returnThisPage(s_requestDocument);
			}

			if (b_logThisHit)	//Don't count when moving from "/folder" ==> "/folder/" and don't count the reserved paths (when the user is downloading an image while listing the content in a directory)
				addThisHitToLog();
		}
		catch(Exception e)
		{
			if (b_showErrors)		//Probably beacuse an invalid Header has been sent
				System.out.println("An error occured @ run:\n"+e.getMessage());
		};


		try {
			so_userConnection.getOutputStream().flush();
			if (!b_isRunningScript)	//If, and only if, we are NOT running a script we shall use Keep-Alive. Otherwise ReadInputStreamSTDERR/STDOUT should close the stream.
			{
				//yield();//Do I want this line or not??

				//sleep(150);		//Wait before we close the OutputStream so that all data actually get sent before we close the OutputStream
				//so_userConnection.getOutputStream().close();

				//so_userConnection.close();

				//This is faster than closing the connection (without Keep-Alive) */
				if (b_useKeepAlive)
				{
					initEverything(so_userConnection);
					run();
				}
				else if (!b_isRunningScript)	//IF [it isn't a script that has been running (but an old browser without Keep-Alive)]...
				{
					so_userConnection.getOutputStream().flush();
					sleep(20);	//Needed??
					so_userConnection.getOutputStream().close();
				}
			}
		}catch(Exception e){};
	}


	protected void addThisHitToLog()
	{
		totalNumberOfHits++;
		if (s_errorStatus.equals("200 OK"))	//If the visitor has downloaded correctly (for example: not a "404 error" or a "redirect" site)
			tmpStr=s_requestedFolderLocation+s_requestedFileName;//s_defaultRootLocationWithoutSlashAtEnd+s_requestedFolderLocationWithoutRoot+s_requestedFileName;
		else
			tmpStr=s_requestDocument;

		HitStatistic hs_hit = new HitStatistic(so_userConnection.getInetAddress().getHostAddress()+"/"+so_userConnection.getInetAddress().getHostName(),s_errorStatus, tmpStr, new Date(System.currentTimeMillis()), s_requestedFileExtension, s_loginRealm, s_visitorUsername);
		if (myMenuOptions!=null)	//IMPORTANT to make sure that this isn't null as ReadInputStreamXXX can call this method directly
		{
			myMenuOptions.addIPToList(hs_hit);	//Use intern to use less memory (it does really use less memory? I hope so...)
			//Not needed anymore: myMenuOptions.statsHasBeenUpdated();
		}
		NewConnection.l_logFile.writeToLog(hs_hit.toString());
	}


	//The following variables will be set here:
	//s_requestedHTTP
	//s_requestMethod
	//s_requestDocument
	private void readHeaderSentByBrowser()
	{
		try
		{
			String firstLineIndata;

			//##########################READ INFORMATION GIVEN BY BROWSER####################
			//NOTE:
			//The first line in the Header-data that the browser sends is:
			//"GET /folder/file.txt HTTP/1.1"
			//However, if you run the command "lynx myserver.com", Lynx establishes two connections.
			//The first one sends this first line header:
			//"GET /folder/ HTTP/1.0"
			//The second time it sends this line, which is a HTTP/0.9-syntax:
			//"GET /folder/"
			//
			//Also beware, a request for a folder such as "/dir with space/" is sent as:
			//"GET /dir with space/ HTTP/1.0"
			//and then (which also is a HTTP/0.9-syntax):
			//"GET /dir with space/"
			//
			//Note, no headers shall be sent when a HTTP/0.9 request is received, a valid request/response might be:
			//"GET /foo.txt"
			//"This is a one-line file."
			//
			//But Xerver don't care about this and sends an valid HTTP/1.1-response to a HTTP/0.9-request.
			//The reason for this is that (for example) Lynx sends HTTP/0.9-requests, despite it understands HTTP/1.1-responses.

			DISWR_theInputWeGetFromBrowser = new DataInputStreamWithReadLine(so_userConnection.getInputStream());
			firstLineIndata=DISWR_theInputWeGetFromBrowser.myReadLine(i_maxLineLengthReadFromHeader*10);	//"GET /mapp/fil.txt HTTP/1.1"		//i_maxLineLengthReadFromHeader*4 can be anything that you believe is long enough to store an URL and the GET-data which might come with it, but not so long that a hacker would try to use all our memory by sending a very large string

//System.out.println("READ: "+firstLineIndata);
			int firstLineIndataIndexOfSpace=firstLineIndata.indexOf(" ");		//Optimization...
			int firstLineIndataLastIndexOfSpace=firstLineIndata.lastIndexOf(" ");	//Optimization...
			if (firstLineIndataIndexOfSpace!=firstLineIndataLastIndexOfSpace)	//There are two " " in firstLineIndata
			{
				if (isHTTPFormatRecognized(firstLineIndata.substring(firstLineIndataLastIndexOfSpace+1)))	//If firstLineIndata ends with "HTTP/0.9", "HTTP/1.0" or "HTTP/1.1"	//(everything is correct)
				{
					s_requestedDocumentWithoutUnescape=removeEncodedNullCharFromString(firstLineIndata.substring(firstLineIndataIndexOfSpace+1,firstLineIndataLastIndexOfSpace));
					s_requestMethod=firstLineIndata.substring(0,firstLineIndataIndexOfSpace);
					s_requestDocument=MyString.unescape(s_requestedDocumentWithoutUnescape);
					s_requestedHTTP=firstLineIndata.substring(firstLineIndataLastIndexOfSpace+1).toUpperCase();
				}
				else	//A request such as "GET /dir with space/" has been made (probably by lynx, but might also happen with other browsers, don't know)
				{
					s_requestedDocumentWithoutUnescape=removeEncodedNullCharFromString(firstLineIndata.substring(firstLineIndataIndexOfSpace+1));
					s_requestMethod=firstLineIndata.substring(0,firstLineIndataIndexOfSpace);
					s_requestDocument=MyString.unescape(s_requestedDocumentWithoutUnescape);
					s_requestedHTTP=CONSTANT_HTTP10;	//Set this to anything you want, it doesn't matter...
				}
			}
			else	//Lynx sometimes sends a stupid request like "GET /", which will result in... (This is a valid HTTP/0.9-syntax, but I have only seen Lynx be using it)
			{
				s_requestedDocumentWithoutUnescape=removeEncodedNullCharFromString(firstLineIndata.substring(firstLineIndataIndexOfSpace+1));
				s_requestMethod=firstLineIndata.substring(0,firstLineIndataIndexOfSpace);
				s_requestDocument=MyString.unescape(s_requestedDocumentWithoutUnescape);
				s_requestedHTTP=CONSTANT_HTTP09;	//Set this to anything you want, it doesn't matter...
			}

			if (!s_requestedHTTP.equals(CONSTANT_HTTP11))
			{
				b_useKeepAlive=false;
				if (s_requestedHTTP.equals(CONSTANT_HTTP09))
				{
					i_sendWhatData=DATATYPE_BODYONLY;
				}
			}


			s_requestDocument=s_requestDocument.trim();	//"/folder/ " ==> "/folder/" (This line is in case someone makes a request such as "GET /folder/  HTTP/1.0", which would result in that the s_requestMethod=="/folder/ ", which is incorrect)

			if (s_requestMethod.toUpperCase().indexOf(CONSTANT_POST)!=-1)
				s_requestMethod=CONSTANT_POST;
			else if (s_requestMethod.toUpperCase().indexOf(CONSTANT_HEAD)!=-1)
			{
				i_sendWhatData=DATATYPE_HEADONLY;
				s_requestMethod=CONSTANT_HEAD;
			}
			else
				s_requestMethod="GET";


			s_requestQueryString="";
			int requestDocumentIndexOfQuestion=s_requestDocument.indexOf("?");
			if (requestDocumentIndexOfQuestion!=-1)	//	"mapp1/mapp2/fil.htm?hejsan" ==> "mapp1/mapp2/fil.htm"
			{
				s_requestQueryString=s_requestDocument.substring(requestDocumentIndexOfQuestion+1);
				s_requestDocument=s_requestDocument.substring(0,requestDocumentIndexOfQuestion);
			}
		}
		catch (Exception e)
		{
		//System.out.println("DIED!!!");
			try 	{
				so_userConnection.close();
				/*
				s_requestDocument="/";	//Set this to something... don't matters to what. This will be sent together with the header for the "400 Bad Request".
				b_logThisHit=false;
				s_errorStatus="400 Bad Request";
				showError("The client has sent an invalid request.",errorFilesFolder,"error400badrequest.html");
				*/
			}catch(Exception exc){}

			if (b_showErrors)		//Probably beacuse an invalid Header has been sent
				System.out.println("An error occured @ readHeaderSentByBrowser:\n"+e.getMessage());
		}
	}





//From Opera:
//GET /?y4errewfdpp HTTP/1.1
//User-Agent: Mozilla/4.0 (compatible; MSIE 5.0; Windows XP) Opera 6.0  [sv]
//Host: localhost:12345
//Accept: text/html, image/png, image/jpeg, image/gif, image/x-xbitmap, */*
//Accept-Language: sv
//Accept-Charset: windows-1252;q=1.0, utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1
//Accept-Encoding: deflate, gzip, x-gzip, identity, *;q=0
//Cache-Control: no-cache
//Connection: Keep-Alive, TE
//TE: deflate, gzip, chunked, identity, trailers


	private void setLocationParts(String relativePath, String rootLocationWithoutSlashAtEnd)
	{
		String s_fileOrFolderThatIsReadOnHardDrive;
		String fileExtension="", folderLocation="", fileName="";
		File thisFolder;
		int sizeOfAliasName;
		int fileStatus=-1;
		sizeOfAliasName=myHT_allAliases.giveBiggestKeySize(relativePath);	//gives the size of the alias name... ("/alias/folder/file.txt" ==> "7")

		//##############Start giving values to the variables##############

 		if (sizeOfAliasName==-1)	//You are not visiting an alias
		{
			s_fileOrFolderThatIsReadOnHardDrive=rootLocationWithoutSlashAtEnd + relativePath.replace('/', File.separatorChar);
		}
 		else	//you are visiting an alias
 		{
 			s_fileOrFolderThatIsReadOnHardDrive=getCorrectFolderFromAlias(relativePath.substring(0,sizeOfAliasName)) + relativePath.substring(sizeOfAliasName).replace('/', File.separatorChar);
 		}
 		thisFolder=new File(s_fileOrFolderThatIsReadOnHardDrive);

		if (thisFolder.exists())
		{
			if (thisFolder.isFile() && !relativePath.endsWith("/"))
			{
				fileStatus=ISFILE;
				folderLocation=s_fileOrFolderThatIsReadOnHardDrive.substring(0,s_fileOrFolderThatIsReadOnHardDrive.lastIndexOf(File.separatorChar)+1);
				fileName=s_fileOrFolderThatIsReadOnHardDrive.substring(s_fileOrFolderThatIsReadOnHardDrive.lastIndexOf(File.separatorChar)+1);
				while (fileName.endsWith(".")) { fileName=fileName.substring(0,fileName.length()-1); }	//"script.pl..." ==> "script.pl" (since Xerver consider "script.pl..." to be the filename (and null is the file extension), but the file system will show the content of "script.pl" when xerver asks for the content of "script.pl...", so you can see source code of arbitrary script file)
				fileExtension=fileName.substring(fileName.lastIndexOf('.')+1);

			}
			else if (thisFolder.isDirectory())
			{
				fileStatus=ISFOLDER;
				folderLocation=s_fileOrFolderThatIsReadOnHardDrive;
				fileName=giveNameOfIndexFile(folderLocation);	//Returns the name of the correct index-file, if there is any. Otherwise this returns ""
				fileExtension="";
			}
			else	//someone is visiting "/folder/fileExists.txt/". thisFolder.exists() tells this is a file, but as the visitor did request "/folder/fileExists.txt/" (and not "/folder/fileExists.txt") we pretend the file doesn't exists
			{
				fileStatus=DOESNOTEXISTS;
				folderLocation=s_fileOrFolderThatIsReadOnHardDrive;
				fileName="";
				fileExtension="";
			}
		}
		else
		{
			fileStatus=DOESNOTEXISTS;
			folderLocation=s_fileOrFolderThatIsReadOnHardDrive;
			fileName="";
			fileExtension="";
		}
		//##############At this line, all variables shall have been set##############

		//Finally, set the local variables to the global variables
		s_requestedFolderLocation=folderLocation;
		s_requestedFileName=fileName;
		s_requestedFileExtension=fileExtension;
		i_fileStatus=fileStatus;

		if (fileStatus == ISFOLDER && !s_requestDocument.endsWith("/"))	//If [Visiting a folder] AND [the URL entered does NOT end with "/" ], then...	//NOTE: You CAN'T change "s_requestDocument" to "relativePath". (reason: lets say you visit "http://server.com/alias" (relativePath=="/alias"), and this doesn't match any file/folder on the hard drive, then we check with relativePath+"/" (relativePath=="/alias/"))
			redirectToItselfWithSlash();	//If location is "http://server.com/folder" ==> "http://server.com/folder/"

		if (fileStatus == DOESNOTEXISTS && !relativePath.endsWith("/"))	//If [the file/folder doesn't exists] AND [the URL entered does NOT end with "/" ], then...	//(reason for this check: lets say you visit "http://server.com/alias" (relativePath=="/alias"), and this doesn't match any file/folder on the hard drive, then we check with relativePath+"/" (relativePath=="/alias/"))
			setLocationParts(relativePath+"/", rootLocationWithoutSlashAtEnd);
	}


	private String getCorrectFolderFromAlias(String theAlias)	//If no alias is found returns null, otherwise the path given by the alias.
	{
		tmpStr=myHT_allAliases.giveValueByIndex(theAlias);
		if (tmpStr==null)
			return null;
		else
		{
			return tmpStr;
		}
	}


	private String removeEncodedNullCharFromString(String str)
	{
		int i_indexOfNull = str.indexOf("%00");
		if (i_indexOfNull != -1)	//Someone has added "%00" to the URL: "/folder/%00/" should be ==> "/folder/"
		{
			return str.substring(0,i_indexOfNull);
		}
		return str;
	}


	private String [] getEnvironmentVariablesGivenByBrowser(DataInputStreamWithReadLine theInput)
	{
		String [] allENVVariablesTMP=new String[maxNumbersOfENVAccepted], allENVVariables=new String[0];
try {
		String tmp;
		int numberOfENVGivenByBrowser=0;	//This is the number of ENV-variables we set after we have read what the browser has given us. For example both CONTENT_TYPE and HTTP_CONTENT_TYPE are set when we have read "CONTENT_TYPE". The number of lines given to us from the browser is not necessey (and probably not) ==numberOfENVGivenByBrowser

		String tmpStr="_";	//Set this to any none-empty string (!="") (don't set it to null)
		while (numberOfENVGivenByBrowser<maxNumbersOfENVAccepted-1)	//(assume: maxNumbersOfENVAccepted=200) less than 199 because it is possible to run "numberOfENVGivenByBrowser++" twice in this loop. (If we start the loop with 199 and run "numberOfENVGivenByBrowser++" twice we will try to write to index 200 (no, not 201; reason: we don't have "++numberOfENVGivenByBrowser"), but the last index of the array is 199 ==> exception is thrown!!!).
		{
			//First I only had the "tmpStr=br_theInputWeGetFromBrowser.readLine();" line here, and it worked OK. But after a while I saw I sometimes got problems: "tmpStr=br_theInputWeGetFromBrowser.readLine();" did never quit, the Thread had stopped here. I don't know for sure, but the reason might be that the browser never sends a "\n" or "\r" at the end of the line, so it never becomes a "line". However, now we instead read "i_valueOfHttpContentLength" from the stream after we have read one empty line (==""). This seems to work without any problems.	//(BTW: the problem occured after I had implemented the "401 Not Authorized"-support (so the browser sends a "AUTHORIZATION=Basic enctyptedPass" line now). Is it possible this has anything to do with that the browser doesn't send an \n after the POST-data? (Did the browser send a \n after the POST-data before this?) I don't know... :/ )
			if (!tmpStr.equals(""))		//If this is not the empty line before the POST-line
				tmpStr=DISWR_theInputWeGetFromBrowser.myReadLine(i_maxLineLengthReadFromHeader);
			else if (i_valueOfHttpContentLength!=0)	//This is the empty line before the POST-line
			{
				//Next line is the POST-data

// // Was used before:
// // 				char[] cbuf=new char[i_valueOfHttpContentLength];
// // 				br_theInputWeGetFromBrowser.read( cbuf, 0, i_valueOfHttpContentLength);
// // 				b_STDINDataFromPOSTIsAvailable=true;

				break;	//We have read everything we want to read
			}
			else	//This happenes if there is no "CONTENT_LENGTH"-line in the browser request. So this won't happen with a valid browser...
				break;	//We have read everything we want to read


			if (tmpStr!=null)
			{
				if (tmpStr.indexOf(":")!=-1)	//If the line read really is a line such as "HTTP_Connection: Keep-Alive". Otherwise this is the empty line before the POST-line
				{
					//"tmpStr" has this format: "CONTENT_LENGTH=65" (after the line below has been run)
					String tmpEnvVarName=tmpStr.substring(0,tmpStr.indexOf(":")).toUpperCase().replace('-','_');
					String tmpEnvVarValue=tmpStr.substring(tmpStr.indexOf(":")+1).trim();
					tmpStr=tmpEnvVarName+"="+tmpEnvVarValue;
					allENVVariablesTMP[numberOfENVGivenByBrowser++]="HTTP_"+tmpStr;

// System.out.println("HEADER FROM BROWSER: "+tmpStr);
					if (tmpEnvVarName.equals("CONTENT_LENGTH"))
					{
						allENVVariablesTMP[numberOfENVGivenByBrowser++]=tmpStr;
						i_valueOfHttpContentLength=Integer.parseInt(tmpEnvVarValue);					//...Save the length of the POST data
					}
					else if (tmpEnvVarName.equals("HOST"))
					{
						s_hostnameGivenByBrowser=tmpEnvVarValue;
					}
					else if (tmpEnvVarName.equals("CONTENT_TYPE"))
					{
						allENVVariablesTMP[numberOfENVGivenByBrowser++]=tmpStr;
					}
					else if (tmpEnvVarName.equals("AUTHORIZATION"))
					{
						s_encryptedPasswordGiven=tmpStr.substring(tmpStr.indexOf("=Basic ")+("=Basic ".length()));	//Format: "encryptedPassword" (actually, it is "user:pass" encrypted)
					}
//					else if (tmpStr.startsWith("COOKIE="))
//						s_cookiesFromBrowser=tmpStr.substring("COOKIE=".length());	//We don't need this
				}
// Next 5 lines not in use anymore; was in use:
// 				else if (s_requestMethod.equals(CONSTANT_POST) && !tmpStr.equals(""))	//If, and only if, a POST-request has been made there is POST-data to read... (If tmpStr is empty we are at the empty line before the POST-data
// 				{
// 					s_stdinDataForPOSTRequests=tmpStr.substring(0,i_valueOfHttpContentLength);	//Guaranty that "s_stdinDataForPOSTRequests" doesn't contain more than "i_valueOfHttpContentLength" chars
// 					break;	//With a correct request, this is not necessey, as the POST-lien data is the last one
// 				}
			}
		}


		allENVVariables=new String[numberOfENVGivenByBrowser];
		/*
		for (int i=0; i<numberOfENVGivenByBrowser; i++)
			allENVVariables[i]=allENVVariablesTMP[i];
		*/

		System.arraycopy(allENVVariablesTMP,0,allENVVariables,0,numberOfENVGivenByBrowser);


//List all ENV from browser:
//for (int i=0; i<numberOfENVGivenByBrowser; i++)
//	System.out.println("data  "+allENVVariables[i]);



//From Opera:
//GET /?y4errewfdpp HTTP/1.1
//User-Agent: Mozilla/4.0 (compatible; MSIE 5.0; Windows XP) Opera 6.0  [sv]
//Host: localhost:12345
//Accept: text/html, image/png, image/jpeg, image/gif, image/x-xbitmap, */*
//Accept-Language: sv
//Accept-Charset: windows-1252;q=1.0, utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1
//Accept-Encoding: deflate, gzip, x-gzip, identity, *;q=0
//Cache-Control: no-cache
//Connection: Keep-Alive, TE
//TE: deflate, gzip, chunked, identity, trailers

} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getEnvironmentVariablesGivenByBrowser:\n"+e.getMessage());}
	return allENVVariables;
	}


	//s_requestDocument has to be set when you run checkForReservedPaths
	//Returns true if there is a reserved path, otherwise false
	private boolean checkForReservedPaths()
	{
		if (s_requestDocument.equals("/Image:showFolder"))
		{
			b_logThisHit=false;
			s_requestedFolderLocation=(new File(hiddenFolder)).getAbsolutePath()+File.separator;
			s_requestedFileName="imagefolder.gif";
			s_requestedFileExtension="gif";
			returnThisPage(s_requestedFolderLocation+s_requestedFileName);
			return true;
		}

		if (s_requestDocument.equals("/Image:showFileicon"))
		{
			b_logThisHit=false;
			s_requestedFolderLocation=(new File(hiddenFolder)).getAbsolutePath()+File.separator;
			s_requestedFileName="imagefileicon.gif";
			s_requestedFileExtension="gif";
			returnThisPage(s_requestedFolderLocation+s_requestedFileName);
			return true;
		}
return false;
	}


	private String [] getAllEnvironmentVariables()	//Se http://hoohoo.ncsa.uiuc.edu/cgi/env.html
	{
		String [] envVariables, envVariablesTMP;
		int variablesGivenByBrowserLength=as_variablesGivenByBrowser.length;
		int maxNumberOfEnvironmentVariables=maxNumbersOfENVAccepted+variablesGivenByBrowserLength;
		String s_tmpStr;

		envVariablesTMP=new String[maxNumberOfEnvironmentVariables];
		/*
		for (;i<variablesGivenByBrowserLength; i++)	//Optimization...
		{
			envVariablesTMP[i]=as_variablesGivenByBrowser[i];
		}
		*/
		System.arraycopy(as_variablesGivenByBrowser, 0, envVariablesTMP, 0, variablesGivenByBrowserLength);

		int i=variablesGivenByBrowserLength;
		s_tmpStr=System.getProperty("java.library.path",".");	//We set the default value to ".", in case we don't get anything from "java.library.path"
		envVariablesTMP[i++]="PATH="+s_tmpStr;

		s_tmpStr=System.getProperty("systemroot");
		if (s_tmpStr!=null)
		{
			envVariablesTMP[i++]="systemroot="+s_tmpStr;  //Without this line we will get an error while using MySQL (I have tried PHPBB with MySQL, and it said: "Warning: mysql_connect(): Can't create TCP/IP socket (10106) in <b>d:\folder\file.php</b> on line XXX") (For example "C:\\WINNT" as value)
		}

		s_tmpStr=System.getProperty("windir");
		if (s_tmpStr!=null)
		{
			envVariablesTMP[i++]="windir="+s_tmpStr;
		}

		s_tmpStr=System.getProperty("pathext");
		if (s_tmpStr!=null)
		{
			envVariablesTMP[i++]="pathext="+s_tmpStr;
		}

		s_tmpStr=System.getProperty("comspec");
		if (s_tmpStr!=null)
		{
			envVariablesTMP[i++]="comspec="+s_tmpStr;
		}

		if (s_hostnameGivenByBrowser==null)
		{
			envVariablesTMP[i++]="SERVER_NAME="+HostInfo.getLocalHostNameOrLocalhost();//XerverKernel.s_egetIp;
		}
		else
		{
			envVariablesTMP[i++]="SERVER_NAME="+s_hostnameGivenByBrowser;
		}

		envVariablesTMP[i++]="SERVER_SOFTWARE="+s_replyServerName;
		envVariablesTMP[i++]="GATEWAY_INTERFACE=CGI/1.1";
		envVariablesTMP[i++]="SERVER_PROTOCOL="+s_requestedHTTP;
		envVariablesTMP[i++]="SERVER_PORT="+i_portNr;
		envVariablesTMP[i++]="REQUEST_METHOD="+s_requestMethod;
		envVariablesTMP[i++]="DOCUMENT_NAME="+s_requestedFileName;
		envVariablesTMP[i++]="DOCUMENT_URI="+s_requestDocument;

		//#######################################
		//## For PHP 5 for Windows:
		//## This is enough to run PHP scripts:
		//## C:\>set
		//## PATH=c:/program files/php
		//## SCRIPT_FILENAME=C:\files\test.php
		//## C:\>php-cgi
		//## Content-type: text/html
		//## X-Powered-By: PHP/5.0.3
		//##
		//## Hello World
		//#######################################

		//#######################################
		//## For PHP 5 for Windows:
		//## However, when we have the SERVER_NAME
		//## variable we also need set the
		//## REDIRECT_STATUS variable,
		//## otherwise we get error ("Security Alert!").
		//## C:\>set
		//## PATH=c:/program files/php
		//## SCRIPT_FILENAME=C:\files\test.php
		//## SERVER_NAME=Xerver
		//## REDIRECT_STATUS=200
		//## C:\>php-cgi
		//## Content-type: text/html
		//## X-Powered-By: PHP/5.0.3
		//##
		//## Hello World
		//#######################################


		//EXAMPLE PATH_INFO:
		//http://server/dir/file.pl ==> "/dir/file.pl"
		//http://site.com/script.pl/extra/folder/ ==> "/extra/folder/"
		envVariablesTMP[i++]="PATH_INFO="+s_requestDocument;

		//EXAMPLE PATH_TRANSLATED
		//http://server/dir/file.pl ==> "d:\root\path\dir\file.pl"
		//http://site.com/script.pl/extra/folder/ ==> "/path/to/root/extra/folder/"
		envVariablesTMP[i++]="PATH_TRANSLATED="+s_requestedFolderLocation+s_requestedFileName;

		//EXAMPLE SCRIPT_NAME
		//http://server/dir/file.pl ==> "/dir/file.pl"
		//http://site.com/script.pl/extra/folder/ ==> "/extra/folder/"
		envVariablesTMP[i++]="SCRIPT_NAME="+s_requestDocument;

		//SCRIPT_FILENAME is what PHP uses to execute scripts.
		//SCRIPT_FILENAME can be c:\scripts\php\test.php
		//Without this we get "No input file specified.":
		envVariablesTMP[i++]="SCRIPT_FILENAME="+s_requestedFolderLocation+s_requestedFileName;	//The local path to the script

		envVariablesTMP[i++]="QUERY_STRING="+s_requestQueryString;

		try {
			s_tmpStr=so_userConnection.getInetAddress().getHostName();
			envVariablesTMP[i++]="REMOTE_HOST="+so_userConnection.getInetAddress().getHostName();	//"This variable is not set if the server failed to look up the host name or skipped the lookup in the interest of speed."
		} catch(Exception e){}	//Do nothing if we fail look up

		envVariablesTMP[i++]="REMOTE_ADDR="+so_userConnection.getInetAddress().getHostAddress();//.toString().substring(so_userConnection.getInetAddress().toString().indexOf("/")+1);

		if (!s_visitorUsername.equals(s_defaultLoginName))	//visitor has not visited a password protected folder
		{
			envVariablesTMP[i++]="AUTH_TYPE=Basic";	//"Contains the type of authentication being used to limit access to the current document. E.g. "Basic" or "Digest". "
			envVariablesTMP[i++]="REMOTE_USER="+s_visitorUsername;	//"REMOTE_USER is only set for pages in a directory or subdirectory that's password-protected via a .htaccess file."
		}
//		envVariablesTMP[i++]="REMOTE_IDENT=aaaaa";	//"If the HTTP server supports RFC 931 identification, then this variable will be set to the remote user name retrieved from the server. Usage of this variable should be limited to logging only."
// 	envVariablesTMP[i++]="CONTENT_TYPE=aaaaa";	//This will be set automatically when POST has been used
//		envVariablesTMP[i++]="CONTENT_LENGTH=aaaaa";	//This will be set automatically when POST has been used
		envVariablesTMP[i++]="REDIRECT_STATUS="+s_errorStatus;
//		envVariablesTMP[i++]="redirect_status_env=0";//PHP STUFF!!!!!
//		envVariablesTMP[i++]="PHP_DOCUMENT_ROOT=e:\\";//PHP STUFF!!!!!
//		envVariablesTMP[i++]="DOCUMENT_ROOT=e:\\";//PHP STUFF!!!!!
//		envVariablesTMP[i++]="DOC_ROOT=e:\\";//PHP STUFF!!!!!



		//i now contains the number of environmentvariables that shall be set
		envVariables=new String[i];
		/*
		for (int k=0; k<i; k++)
		{
			envVariables[k]=envVariablesTMP[k];
System.out.println(envVariables[k]);
		}
		*/
		System.arraycopy(envVariablesTMP, 0, envVariables, 0, i);

	return envVariables;
	}


	private void initializeRequestedFileExtension()//This MUST be called once before the page is showed, or the page won't work with for example Netscape 1	//You can safely run initializeRequestedFileExtension more than once if you want
	{
		s_requestedFileExtension=s_requestedFileName.substring(s_requestedFileName.lastIndexOf(".")+1);	//If there is no file extension s_requestedFileExtension is the same as the file name

		s_requestedFileType=getMimeTypeFromFileExt(s_requestedFileExtension);

		/*
		s_requestedFileType=(String)HM_allFileExt.get(s_requestedFileExtension);
		if (s_requestedFileType==null)
		{
			s_requestedFileType="text/html";	//Default
		}
		*/

		/*
		//The most common types are at top...
		if (s_requestedFileName.equals(""))
				s_requestedFileType="text/html";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("htm") ||
				s_requestedFileExtension.equalsIgnoreCase("shtml") ||
				s_requestedFileExtension.equalsIgnoreCase("html") ||
				s_requestedFileExtension.equalsIgnoreCase("shtm") ||
				s_requestedFileExtension.equalsIgnoreCase("asp"))
					s_requestedFileType="text/html";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("txt") ||
				s_requestedFileExtension.equalsIgnoreCase("text") ||
				s_requestedFileExtension.equalsIgnoreCase("ini") ||
				s_requestedFileExtension.equalsIgnoreCase("c") ||
				s_requestedFileExtension.equalsIgnoreCase("cc") ||
				s_requestedFileExtension.equalsIgnoreCase("c++") ||
				s_requestedFileExtension.equalsIgnoreCase("h") ||
				s_requestedFileExtension.equalsIgnoreCase("pl") ||
				s_requestedFileExtension.equalsIgnoreCase("java") ||
				s_requestedFileExtension.equalsIgnoreCase("webl") ||
				s_requestedFileExtension.equalsIgnoreCase("inf"))
					s_requestedFileType="text/plain";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("jpeg") ||
				s_requestedFileExtension.equalsIgnoreCase("jpg") ||
				s_requestedFileExtension.equalsIgnoreCase("jpe"))
					s_requestedFileType="image/jpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("gif"))
					s_requestedFileType="image/gif";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("png"))
					s_requestedFileType="image/png";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("uu") ||
							s_requestedFileExtension.equalsIgnoreCase("exe"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ps"))
					s_requestedFileType="application/postscript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("zip"))
					s_requestedFileType="application/zip";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sh"))
					s_requestedFileType="application/x-shar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tar"))
					s_requestedFileType="application/x-tar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("au") ||
							s_requestedFileExtension.equalsIgnoreCase("snd"))
					s_requestedFileType="audio/basic";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("wav"))
					s_requestedFileType="audio/x-wav";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xml"))
					s_requestedFileType="text/xml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("hqx"))
					s_requestedFileType="application/mac-binhex40";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("cpt"))
					s_requestedFileType="application/mac-compactpro";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ai"))
					s_requestedFileType="application/postscript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("aif"))
					s_requestedFileType="audio/x-aiff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("aifc"))
					s_requestedFileType="audio/x-aiff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("aiff"))
					s_requestedFileType="audio/x-aiff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("au"))
					s_requestedFileType="audio/basic";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("avi"))
					s_requestedFileType="video/x-msvideo";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("bcpio"))
					s_requestedFileType="application/x-bcpio";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("bin"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("bmp"))
					s_requestedFileType="image/x-xbitmap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("cdf"))
					s_requestedFileType="application/x-netcdf";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("class"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("cpio"))
					s_requestedFileType="application/x-cpio";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("cpt"))
					s_requestedFileType="application/mac-compactpro";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("csh"))
					s_requestedFileType="application/x-csh";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("css"))
					s_requestedFileType="text/css";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dcr"))
					s_requestedFileType="application/x-director";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dir"))
					s_requestedFileType="application/x-director";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dll"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dms"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("doc"))
					s_requestedFileType="application/msword";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dtd"))
					s_requestedFileType="text/xml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dvi"))
					s_requestedFileType="application/x-dvi";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dwg"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("dxr"))
					s_requestedFileType="application/x-director";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("eps"))
					s_requestedFileType="application/postscript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("etx"))
					s_requestedFileType="text/x-setext";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("evy"))
					s_requestedFileType="application/x-envoy";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("exe"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("fif"))
					s_requestedFileType="application/fractals";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("fli"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("gl"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("gtar"))
					s_requestedFileType="application/x-gtar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("gz"))
					s_requestedFileType="application/x-gzip";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("hdf"))
					s_requestedFileType="application/x-hdf";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("hpx"))
					s_requestedFileType="application/mac-binhex40";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("hqx"))
					s_requestedFileType="application/mac-binhex40";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ice"))
					s_requestedFileType="x-conference/x-cooltalk";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ief"))
					s_requestedFileType="image/ief";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("iges"))
					s_requestedFileType="model/iges";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("igs"))
					s_requestedFileType="model/iges";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("isv"))
					s_requestedFileType="bws-internal/intrasrv-urlencoded";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("jfm"))
					s_requestedFileType="bws-internal/intrasrv-form";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("jrp"))
					s_requestedFileType="bws-internal/intrasrv-report";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("js"))
					s_requestedFileType="application/x-javascript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("kar"))
					s_requestedFileType="audio/midi";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("latex"))
					s_requestedFileType="application/x-latex";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("lha"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ls"))
					s_requestedFileType="application/x-javascript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("lzh"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("man"))
					s_requestedFileType="application/x-troff-man";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("me"))
					s_requestedFileType="application/x-troff-me";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mesh"))
					s_requestedFileType="model/mesh";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mid"))
					s_requestedFileType="audio/midi";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("midi"))
					s_requestedFileType="audio/midi";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mif"))
					s_requestedFileType="application/x-mif";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mocha"))
					s_requestedFileType="application/x-javascript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mov"))
					s_requestedFileType="video/quicktime";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("movie"))
					s_requestedFileType="video/x-sgi-movie";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mp2"))
					s_requestedFileType="audio/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mp3"))
					s_requestedFileType="audio/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mpe"))
					s_requestedFileType="video/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mpeg"))
					s_requestedFileType="video/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mpg"))
					s_requestedFileType="video/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("mpga"))
					s_requestedFileType="audio/mpeg";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ms"))
					s_requestedFileType="application/x-troff-ms";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("msh"))
					s_requestedFileType="model/mesh";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("nc"))
					s_requestedFileType="application/x-netcdf";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("oda"))
					s_requestedFileType="application/oda";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pac"))
					s_requestedFileType="application/x-ns-proxy-autoconfig";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pbm"))
					s_requestedFileType="image/x-portable-bitmap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pdb"))
					s_requestedFileType="chemical/x-pdb";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pdf"))
					s_requestedFileType="application/pdf";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pgm"))
					s_requestedFileType="image/x-portable-graymap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("php3"))
					s_requestedFileType="application/x-httpd-php3";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("phtml-msql2"))
					s_requestedFileType="application/x-httpd-php-msql2";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("phtml"))
					s_requestedFileType="application/x-httpd-php";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("pnm"))
					s_requestedFileType="image/x-portable-anymap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ppm"))
					s_requestedFileType="image/x-portable-pixmap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ppt"))
					s_requestedFileType="application/powerpoint";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ps"))
					s_requestedFileType="application/postscript";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("qt"))
					s_requestedFileType="video/quicktime";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ra"))
					s_requestedFileType="audio/x-realaudio";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ram"))
					s_requestedFileType="audio/x-pn-realaudio";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ras"))
					s_requestedFileType="image/x-cmu-raster";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("rgb"))
					s_requestedFileType="image/x-rgb";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("roff"))
					s_requestedFileType="application/x-troff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("rpm"))
					s_requestedFileType="audio/x-pn-realaudio-plugin";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("rtf"))
					s_requestedFileType="application/rtf";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("rtx"))
					s_requestedFileType="text/richtext";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("scm"))
					s_requestedFileType="application/octet-stream";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sgm"))
					s_requestedFileType="text/x-sgml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sgml"))
					s_requestedFileType="text/x-sgml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sh"))
					s_requestedFileType="application/x-sh";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("shar"))
					s_requestedFileType="application/x-shar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("silo"))
					s_requestedFileType="model/mesh";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sit"))
					s_requestedFileType="application/stuffit";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sit"))
					s_requestedFileType="application/x-stuffit";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("skd"))
					s_requestedFileType="application/x-koan";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("skm"))
					s_requestedFileType="application/x-koan";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("skp"))
					s_requestedFileType="application/x-koan";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("skt"))
					s_requestedFileType="application/x-koan";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("snd"))
					s_requestedFileType="audio/basic";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("src"))
					s_requestedFileType="application/x-wais-source";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sv4cpio"))
					s_requestedFileType="application/x-sv4cpio";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("sv4crc"))
					s_requestedFileType="application/x-sv4crc";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("swf"))
					s_requestedFileType="application/x-shockwave-flash";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("t"))
					s_requestedFileType="application/x-troff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tar"))
					s_requestedFileType="application/x-tar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tcl"))
					s_requestedFileType="application/x-tcl";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tex"))
					s_requestedFileType="application/x-tex";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("texi"))
					s_requestedFileType="application/x-texinfo";
//		else		if (	s_requestedFileExtension.equalsIgnoreCase("texi"))
//					s_requestedFileType="application/x-textinfo";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("texinfo"))
					s_requestedFileType="application/x-textinfo";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tif"))
					s_requestedFileType="image/tiff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tiff"))
					s_requestedFileType="image/tiff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tr"))
					s_requestedFileType="application/x-troff";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tsp"))
					s_requestedFileType="application/dsptype";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("tsv"))
					s_requestedFileType="text/tab-separated-values";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("txt"))
					s_requestedFileType="text/plain";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("ustar"))
					s_requestedFileType="application/x-ustar";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("vcd"))
					s_requestedFileType="application/x-cdlink";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("vox"))
					s_requestedFileType="audio/voxware";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("vrml"))
					s_requestedFileType="model/vrml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("wrl"))
					s_requestedFileType="model/vrml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xbm"))
					s_requestedFileType="image/x-xbitmap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xml"))
					s_requestedFileType="text/xml";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xpm"))
					s_requestedFileType="image/x-xpixmap";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xwd"))
					s_requestedFileType="image/x-xwindowdump";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("xyz"))
					s_requestedFileType="chemical/x-pdb";
		else		if (	s_requestedFileExtension.equalsIgnoreCase("z"))
					s_requestedFileType="application/x-compress";
		else
					s_requestedFileType="text/plain";
					*/
	}


	private boolean accessToFolderIsOK(String folder)
	{
		String s_allUsersAndPasswords=null;
		int longestPath=-1;	//If the visitor is visiting "/abc/def/ghi/" and we have password protected both "/abc/" and "/abc/def/" only the password for "/abc/def/" shall be asked.
		if (folder==null)
			return false;

//		We have removed this so we shall not receive a "401 not authorized" error when someone tries to download "http://www.sida.com/folder/../../secretfile.txt"
// 		if (folder.indexOf("..")!=-1)	//You have tried to reach a folder with "http://www.sida.com/folder/../../secretfile.txt"
// 			return false;

		int xerverPasswdLength=as_xerverPasswd.length;	//Optimization...
		if (xerverPasswdLength==0)	//If we have no password protected folders
			return true;

		for (int i=0; i<xerverPasswdLength; i++)	//Optimization...
		{
			//Format of as_xerverPasswd[i]: "/path/to/folder/*=realmName=user1:pass1;user2:pass2"
			String tmpDir=as_xerverPasswd[i];
			tmpDir=tmpDir.substring(0,tmpDir.indexOf("<<@>>"));	//Format: "/path/to/folder/*"
			if (tmpDir.endsWith("*"))	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(true,0,folder,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (case insensitive)]...
				{
					if (tmpDir.length()>longestPath)	//If the visitor is visiting "/abc/def/ghi/" and we have password protected both "/abc/" and "/abc/def/" only the password for "/abc/def/" shall be asked.
					{
						String [] tmpPartOfInfo=MyString.makeArrayOfString(as_xerverPasswd[i],"<<@>>");
						s_loginRealm=tmpPartOfInfo[1];
						s_allUsersAndPasswords=tmpPartOfInfo[2];
						longestPath=tmpDir.length()-1;	//"-1" because the "*" in the end
					}
				}
			}
			else if (tmpDir.equalsIgnoreCase(folder))
			{
				if (tmpDir.length()>longestPath)	//If the visitor is visiting "/abc/def/ghi/" and we have password protected both "/abc/" and "/abc/def/" only the password for "/abc/def/" shall be asked.
				{
					String [] tmpPartOfInfo=MyString.makeArrayOfString(as_xerverPasswd[i],"<<@>>");
					s_loginRealm=tmpPartOfInfo[1];
					s_allUsersAndPasswords=tmpPartOfInfo[2];
					longestPath=tmpDir.length();
				}
			}
		}

		if (longestPath!=-1)
		{
			createEnvironmentVariables(false);	//This will set "s_encryptedPasswordGiven"
			return passwordMatch(s_encryptedPasswordGiven, MyString.makeArrayOfString(s_allUsersAndPasswords,";"));	//The folder we are visiting is password protected, demand a correct password to show this site
		}
		else
			return true;	//The folder we are visiting is not password protected, allow this folder to be viewed
	}

	private boolean passwordMatch(String passWord, String [] allUsersAndPasswords)
	{	//Format of "allUsersAndPasswords[i]": "user:pass"
		for (int i=0 , allUsersAndPasswordsLength=allUsersAndPasswords.length; i<allUsersAndPasswordsLength;i++)	//Optimization...
		{
			String tmpallUsersAndPasswordsI=allUsersAndPasswords[i];
			if (tmpallUsersAndPasswordsI.substring(tmpallUsersAndPasswordsI.indexOf(":")+1).equals(passWord))
			{
				s_visitorUsername=tmpallUsersAndPasswordsI.substring(0,tmpallUsersAndPasswordsI.indexOf(":"));	//In case we choose to log his activites, the webserver actually doesn't need to save this
				return true;
			}
		}
		return false;
	}


	private boolean isFolderAllowed(String folder)
	{
		if (folder==null)
			return false;

		if (folder.indexOf(File.separator+".."+File.separator)!=-1 ||
			folder.endsWith(File.separator+".."))	//You have tried to reach a folder with "http://www.sida.com/folder/../../secretfile.txt"
			return false;

		for (int i=0 , sharedPathsLength=as_sharedPaths.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=as_sharedPaths[i];//.replace('\\','/');
			if (tmpDir.endsWith("*"))	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(true,0,folder,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (case insensitive)]...
					return true;
			}
			else if (tmpDir.equalsIgnoreCase(folder))
				return true;
		}
		return false;
	}


	private boolean isFileExtensionAllowed(String fileExtension)
	{
		if (fileExtension==null)	//be safe, make a check
			return false;

	//NOTE: If you receive an error saying "You have tried to download a file with an extension that you are not allowed to download." when you actually have requested a folder it's because an index file was found in the folder, but the extension of this index file is not allowed to be viewed. This is good, as you are not allowed to view the content of a folder with an index file with an extension you are not allowed to view.

		for (int i=0 , fileExtensionsLength=as_fileExtensions.length; i<fileExtensionsLength; i++)	//Optimization...
			if (as_fileExtensions[i].equals(fileExtension))
				return b_allowTheseFileExtensions;	//If b_allowTheseFileExtensions==true, then you are only allowed to download files with an extension listed in "as_fileExtensions". Otherwise you are not allowed to download these file extensions.
		return !b_allowTheseFileExtensions;
	}

	private boolean accessToFileIsOK(String fileName)
	{
		File theDocument=new File(fileName);
		if (theDocument.canRead())
			return true;
		else
			return false;
	}

	private boolean isHTTPFormatRecognized(String httpRequest)
	{
		if (httpRequest==null)	//be safe, make a check
			return false;

		if (httpRequest.toUpperCase().startsWith("HTTP"))
			return true;
		else
			return false;
	}


	private boolean isHTTPrecognized(String httpRequest)
	{
		if (httpRequest==null)	//be safe, make a check
			return false;

		if (	httpRequest.equalsIgnoreCase(CONSTANT_HTTP11) ||
				httpRequest.equalsIgnoreCase(CONSTANT_HTTP10) ||
				httpRequest.equalsIgnoreCase(CONSTANT_HTTP09))	//For example Netscape 1(.22) uses HTTP/1.0
			return true;
		else
			return false;
	}


	private String giveNameOfIndexFile(String folder)	//returns the name of the index file, if there is no index file, returns ""
	{
		if (File.separatorChar=='\\')	//Windows user... don't make difference on "index.html" and "INDEX.HTML"
		{
			for (int i=0 , indexNamesLength=as_indexNames.length; i<indexNamesLength; i++)
			{
				File thisFile=new File(folder+as_indexNames[i]);
				if (thisFile.isFile())
				{
					return as_indexNames[i];
				}
			}
		}
		else	//If UNIX, Linux etc...
		{
			//First make the fast search for a file with correct CaSe SeNsItIvItY
			for (int i=0 , indexNamesLength=as_indexNames.length; i<indexNamesLength; i++)
			{
				File thisFile=new File(folder+as_indexNames[i]);
				if (thisFile.isFile())
				{
					return as_indexNames[i];
				}
			}

			//Now make a slow search for a file with incorrect CaSe SeNsItIvItY (so "index.html" also matches "INDEX.HTML")
			String tmpIndexFile;
			File thisFolder=new File(folder);
			String [] allFilesInFolder=thisFolder.list();
			for (int i=0 , indexNamesLength=as_indexNames.length; i<indexNamesLength; i++)
			{
				tmpIndexFile=as_indexNames[i].toLowerCase();	//Optimization or not?? I don't know... The ".toLowerCase()" is not needed as we make a ".equalsIgnoreCase()" comparison, but as the ".equalsIgnoreCase()" is made very many times (it is called as many times as there are files in the folder), and the ".toLowerCase()" is only made once it might be worth to make one ".toLowerCase()" to speed up the ".equalsIgnoreCase()" method (or, does it really get faster?)
				for (int j=0 , allFilesInFolderLength=allFilesInFolder.length; j<allFilesInFolderLength; j++)
				{
					if (tmpIndexFile.equalsIgnoreCase(allFilesInFolder[j]))
					{
						return allFilesInFolder[j];
					}
				}
			}
		}
		return "";	//Return "" if no index file matched...
	}


	private void showError(String errorMessage, String folder, String showThisFile)// throws IOException
	{
try {
		if (b_showErrors)
			System.out.println(errorMessage);

		s_requestedFileName=showThisFile;	//This is needed in case an invalid header is given, then s_requestedFileName might not have been set.
		returnThisPage(folder+showThisFile);

		//NO MORE TIMEOUT STUFF:	yield();
		//NO MORE TIMEOUT STUFF:	sleep(125);	//Be safe, don't close before all data has been sent

		//REMOVE ALL CLOSE:	so_userConnection.close();
} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ showError:\n"+e.getMessage());}
	}

	private void createEnvironmentVariables(boolean b_createConstantEnvironmentVariables)	//There is no reason to set b_createConstantEnvironmentVariables==true unless you call "createEnvironmentVariables" just before you run a script (before you call "RunScript"). "createEnvironmentVariables(true)" ("b_createConstantEnvironmentVariables"==true) MUST be set to true and called (at least) ONCE before you run a script, or the environment variables WON'T BE SET!! (you can run this more than once, but it's unnecessary)
	{
		if (!b_environmentHasBeenSetUp)
		{
			b_environmentHasBeenSetUp=true;
			as_variablesGivenByBrowser=getEnvironmentVariablesGivenByBrowser(DISWR_theInputWeGetFromBrowser);
		}

		if (b_createConstantEnvironmentVariables)
			as_allEnvironmentVariables=getAllEnvironmentVariables();
	}

	private void readAllJunkHeaderData()
	{
		try{
		//System.out.println("JUNKDATA");
		BufferedInputStream bis = new BufferedInputStream(so_userConnection.getInputStream());
		//System.out.println(bis.available());
		bis.skip(bis.available());
		/*
		while (bis.available()>0)
		{
			System.out.print((char)bis.read());
		}
		System.out.println("");
		*/
		} catch (Exception e){if (b_showErrors)System.out.println("An error occured @ readAllJunkHeaderData:\n"+e.getMessage());}
	}

	private void returnThisPage(String documentToReturn)// throws IOException
	{
		initializeRequestedFileExtension();

		try
		{
			if (!b_allowExecuteScript || myHT_runnableExtensions.giveValueByIndex(s_requestedFileExtension)==null)	//If [you are not allowed to run scripts] OR [The file is not runnable], then show the content of this file...
			{
				File theFile=new File(documentToReturn);
				if (theFile.length()==0)
					s_errorStatus="204 No Content";

				so_userConnection.setSoTimeout(0);//This will make sure that the connection doesn't close immediately after the file download. Why this?: Because if we didn't have this, and lets say ".getSoTimeout()" is 5 sec, then a file download on for example 6 seconds would result in that the connection has been closed as soon as we had reached a ".read(XXX)"-method. Now we set this to 0 (infinity) before we send data and we set this back to for example 5 seconds before we read data (call the ".read(XXX)"-method).
				BufferedOutputStream theOutput=new BufferedOutputStream(new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream())));	//I "java.io.*"

				readAllJunkHeaderData();

				if (i_sendWhatData!=DATATYPE_BODYONLY)
				{
					theOutput.write((s_requestedHTTP+" "+s_errorStatus+"\r\n"+
   	          			 "Date: "+df_dateFormat.format(d_dateToday)+"\r\n"+
   	          			 "Server: "+s_replyServerName+"\r\n"+
   	         			 ((b_useKeepAlive)?("Connection: Keep-Alive\r\n"):("Connection: Close\r\n"))+
   	          			 "Content-Length: "+theFile.length()+"\r\n"+
   	          			 "Last-Modified: "+new Date(theFile.lastModified())+"\r\n"+
   	          			 "Location: "+s_requestDocument+"\r\n"+
   	           			 "Content-Type: "+s_requestedFileType+s_charsetToUse+"\r\n\r\n").getBytes());
				}

				writeFileToStream(theFile, theOutput);
				//theOutput.write(("\r\n").getBytes());

				//NO MORE TIMEOUT STUFF:	yield();
				//NO MORE TIMEOUT STUFF:	sleep(125);	//Be safe, don't close before all data has been sent

				theOutput.flush();
				//REMOVE ALL CLOSE:	theOutput.close();
			}
			else	//The file is runnable and you have permission to run the script
			{
				b_useKeepAlive=false;
				b_isRunningScript=true;
				b_logThisHit=false;	//The Threads created after the RunScript is started will make sure the user is "logged"
				DataOutputStream theOutput=new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));	//I "java.io.*"
				createEnvironmentVariables(true);	//This MUST be called. This set "as_allEnvironmentVariables".

				if (documentToReturn.indexOf(" ")!=-1)
					(rs_process=new RunScript(myHT_runnableExtensions.giveValueByIndex(s_requestedFileExtension)+" \""+documentToReturn+"\"\n", theOutput, as_allEnvironmentVariables, (i_valueOfHttpContentLength==0)?null:DISWR_theInputWeGetFromBrowser, s_requestDocument, documentToReturn, this)).start();		//Run: 'perl "c:/files/myFile.pl"'
				else
					(rs_process=new RunScript(myHT_runnableExtensions.giveValueByIndex(s_requestedFileExtension)+" "+documentToReturn+"\n",     theOutput, as_allEnvironmentVariables, (i_valueOfHttpContentLength==0)?null:DISWR_theInputWeGetFromBrowser, s_requestDocument, documentToReturn, this)).start();		//Run: 'perl c:/files/myFile.pl'

			}

			so_userConnection.setSoTimeout(i_soTimeoutAfterKeepAliveTransfer);//This make sure that the next time we read form the inputstream (read what the browser has sent to us) we will only wait for 5 seconds.
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ returnThisPage:\n"+e.getMessage());
		}
	}

	private void writeFileToStream(File theFile, OutputStream os)
	{
		FileInputStream fileStreamed=null;

		try
		{
			//setPriority(MIN_PRIORITY);
			int numberOfBytesThatWillBeSent=0;
			fileStreamed=new FileInputStream(theFile);

			byte [] myBuffer = new byte[8192];//	40960];	//2048*20	(i tested and this value seems to give a very high speed when you download files)
			if (i_sendWhatData!=DATATYPE_HEADONLY)
			{
				while ((numberOfBytesThatWillBeSent=fileStreamed.read(myBuffer))!=-1)
				{
					//We add all "n" to a variable to know how many bytes have been downloaded from Xerver
					os.write(myBuffer,0,numberOfBytesThatWillBeSent);
					if (b_logThisHit)	//Don't count the data sent when downloading reserved paths ( ==> "/Image:XXXX" )
					{
						totalNumberOfBytesDownloaded+=numberOfBytesThatWillBeSent;
						//Not needed anymore: myMenuOptions.statsHasBeenUpdated();
					}

					//NO MORE TIMEOUT STUFF:	yield();
					//This is not necessery anymore. It works fine now:	  sleep(25);	//I noticed that without this for example some large pictures (~200-300k) won't be shown. This might (but I don't know for sure) be valid also for other large files.
				}
			}

			//NO MORE TIMEOUT STUFF:	yield();
			//NO MORE TIMEOUT STUFF:	sleep(50);	//Be safe, don't close before all data has been sent

			//setPriority(NORM_PRIORITY);
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}

		try
		{
			if (fileStreamed!=null)	//If fileStreamed "holds" a file
			{
				fileStreamed.close();	//Important: This must be reached no matter what! Even if an exception occurs in the try block, whis must be reached. Otherwise the file will be locked by Xerver (locked by Java.exe) until the garbage collector is runned (and you don't know when it will run) and detects that the file (the object "fileStreamed") is no longer referenced from anywhere else and it release the file by automatic. Until this happenes, no other application can write to or rename this file (however, this problem is solved with this line).
			}
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}
	}


	private boolean isThisFileExtensionAllowed(String fileName)
	{
		fileName=fileName.toLowerCase();
		//String filAndelse=fileName.substring(fileName.lastIndexOf(".")+1);
		//   as_fileExtensions[i].equals(filAndelse)

		for (int i=0 , fileExtensionsLength=as_fileExtensions.length; i<fileExtensionsLength; i++)
			if (fileName.endsWith(as_fileExtensions[i]))
				return b_allowTheseFileExtensions;	//If  b_allowTheseFileExtensions==true, then you are only allowed to download files with extensions that can be found in "as_fileExtensions". Otwerwise these file extionsions shall not be viewable!
		return !b_allowTheseFileExtensions;
	}


	//The visitor has to enter a password for each "realm".
	private void showAccessDenied(String theRealm)// throws IOException
	{
try	{
			readAllJunkHeaderData();

			so_userConnection.setSoTimeout(0);//This will make sure that the connection doesn't close immediately after the file download. Why this?: Because if we didn't have this, and lets say ".getSoTimeout()" is 5 sec, then a file download on for example 6 seconds would result in that the connection has been closed as soon as we had reached a ".read(XXX)"-method. Now we set this to 0 (infinity) before we send data and we set this back to for example 5 seconds before we read data (call the ".read(XXX)"-method).

			File theFile=new File(errorFilesFolder+"error401notauthorized.html");
			DataOutputStream theOutput =new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));	//I "java.io.*"
			if (i_sendWhatData!=DATATYPE_BODYONLY)
			{
				theOutput.writeBytes(s_requestedHTTP+" 401 Not Authorized\r\n"+
				"Date: "+df_dateFormat.format(d_dateToday)+"\r\n"+
				"WWW-Authenticate: Basic realm=\""+theRealm+"\"\r\n"+
				"Server: "+s_replyServerName+"\r\n"+
				((b_useKeepAlive)?("Connection: Keep-Alive\r\n"):("Connection: Close\r\n"))+
	           		 "Location: "+s_requestDocument+"\r\n"+
				"Content-Length: "+theFile.length()+"\r\n"+
//				"Set-Cookie: hej=12345;\r\n"+
				"Content-Type: text/html\r\n\r\n");
			}

				writeFileToStream(theFile, theOutput);

				//NO MORE TIMEOUT STUFF:	yield();
				//NO MORE TIMEOUT STUFF:	sleep(125);	//Be safe, don't close before all data has been sent

				theOutput.flush();
				//REMOVE ALL CLOSE:	theOutput.close();

			so_userConnection.setSoTimeout(i_soTimeoutAfterKeepAliveTransfer);//This make sure that the next time we read form the inputstream (read what the browser has sent to us) we will only wait for 5 seconds.


} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ showAccessDenied:\n"+e.getMessage());}
	}





	private void showDirectorylisting()// throws IOException
	{
try	{
		int countFolders=0, countFiles=0;
		long totalFolderSize=0;

		File theFolder=new File(s_requestedFolderLocation);
		String [] allFilesAndFolders=theFolder.list();
		Arrays.sort(allFilesAndFolders, new ComparatorIgnoreCase());
		int allFilesAndFoldersLength=allFilesAndFolders.length;


		readAllJunkHeaderData();

		so_userConnection.setSoTimeout(0);//This will make sure that the connection doesn't close immediately after the file download. Why this?: Because if we didn't have this, and lets say ".getSoTimeout()" is 5 sec, then a file download on for example 6 seconds would result in that the connection has been closed as soon as we had reached a ".read(XXX)"-method. Now we set this to 0 (infinity) before we send data and we set this back to for example 5 seconds before we read data (call the ".read(XXX)"-method).
		//DataOutputStream theOutput =new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));	//I "java.io.*"
		ChunkedDataOutputStream theOutput=new ChunkedDataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()), s_requestedHTTP.equals(CONSTANT_HTTP11), b_logThisHit); //Chunked data transfer is supported only with HTTP/1.1

		if (i_sendWhatData!=DATATYPE_BODYONLY)
		{
			theOutput.writeBytes(s_requestedHTTP+" "+s_errorStatus+"\r\n"+
				"Date: "+df_dateFormat.format(d_dateToday)+"\r\n"+
				"Server: "+s_replyServerName+"\r\n"+
				((b_useKeepAlive)?("Connection: Keep-Alive\r\n"):("Connection: Close\r\n"))+
				"Location: "+s_requestDocument+"\r\n"+
//				"Set-Cookie: hej=12345;\r\n"+
				((s_requestedHTTP.equals(CONSTANT_HTTP11))?("Transfer-Encoding: chunked\r\n"):(""))+//Only HTTP/1.1-browser will understand this
				"Content-Type: text/html"+s_charsetToUse+"\r\n\r\n",false);//NOTE: WE MUST HAVE "false" WHEN SENDING THE HEADERS! Otherwise the Hexadecimal value will come before all the headers. It MUST come just before the raw data instead.
				//"Content-Type: text/html; charset=ISO-8859-1\r\n\r\n",false);//NOTE: WE MUST HAVE "false" WHEN SENDING THE HEADERS! Otherwise the Hexadecimal value will come before all the headers. It MUST come just before the raw data instead.
		}
		if (i_sendWhatData!=DATATYPE_HEADONLY)
		{
			theOutput.writeBytes("<HTML><HEAD><TITLE>Directory Listing for "+s_requestDocument+"</TITLE>"+
										"<STYLE TYPE=\"text/css\"><!--\n"+
										"A {text-decoration: none;}"+
										"\n//--></STYLE>"+
										"</HEAD>"+
										"<BODY BGCOLOR=\"#FFFFFF\" COLOR=\"#000000\">"+
										"<FONT FACE=\"tahoma, arial, verdana\"><H2>Directory Listing for "+s_requestDocument+"</H2></FONT>"+
										"<PRE>",true);
			theOutput.writeBytes(makeFilenameToNiceOutputWithoutHTML("File name","File size",""+"Last modified",i_maxsizeOfFileNameInDirListing),true);
			if (!s_requestDocument.equals("/"))
				theOutput.writeBytes("<A HREF=\"../\"><IMG SRC=\"/Image:showFolder\" BORDER=0 ALT=\"Dir\"> ../</A>\n",true);



		File theFile;
		String tmpFileName;
		for (int i=0; i<allFilesAndFoldersLength; i++)	//Optimization...
		{
			tmpFileName=allFilesAndFolders[i];
			theFile=new File(s_requestedFolderLocation+tmpFileName);
			if (theFile.isDirectory())
			{
				countFolders++;
				//NOTE: A link to a file called "abc%def.txt" won't work! All "%" has to be replaced with "%25". However, to check all filenames for a % during the listing does take to much time, so we won't bother about this. Note, this "problem" is a common problem (also for many other servers).
				theOutput.writeBytes("<A HREF=\""+tmpFileName+"\"><IMG SRC=\"/Image:showFolder\" BORDER=0 ALT=\"Dir\"> "+tmpFileName+"</A>\n",true);
				allFilesAndFolders[i]=null;
			}
		}

		//IF [no file extensions added to the list] AND [we allow all extensions], then we don't need to call "isThisFileExtensionAllowed(...)".
		boolean shallShowAllFile=(as_fileExtensions.length==0 && !b_allowTheseFileExtensions);	//Optimization...
		long tmpFileSize;
		for (int i=0; i<allFilesAndFoldersLength; i++)	//Optimization...
		{
			tmpFileName=allFilesAndFolders[i];
			if (tmpFileName!=null)	//It's a file...
			{
				theFile=new File(s_requestedFolderLocation+tmpFileName);
				if (b_shareHiddenFiles || !theFile.isHidden())	//If [you want share hidden files] OR [this is not a hidden file], then...
				{
					if (shallShowAllFile || isThisFileExtensionAllowed(tmpFileName))
					{
						tmpFileSize=theFile.length();
						countFiles++;
						totalFolderSize+=tmpFileSize;
						theOutput.writeBytes(makeFilenameToNiceOutput(tmpFileName,MyString.makeNumberToStringWithApostrophe(""+tmpFileSize),""+(new Date(theFile.lastModified())),i_maxsizeOfFileNameInDirListing),true);
					}
				}
			}
		}

				theOutput.writeBytes("\n",true);
				theOutput.writeBytes(makeFilenameToNiceOutputWithoutHTML("Folders: "+countFolders+"    Files: "+countFiles,MyString.makeNumberToStringWithApostrophe(""+totalFolderSize),"",i_maxsizeOfFileNameInDirListing),true);

				theOutput.writeBytes("</PRE>"+
											"<HR>"+
											"<FONT SIZE=\"-1\" FACE=\"arial,verdana\">"+
											"<CENTER><A HREF=\"http://www.JavaScript.nu/xerver/\">Hosted by Xerver</A></CENTER>"+
											"</FONT>"+
											"</BODY></HTML>",true);
				theOutput.finalizeDataTransfer();
			}	//			if (i_sendWhatData!=DATATYPE_HEADONLY)



			//NO MORE TIMEOUT STUFF:	yield();
			//NO MORE TIMEOUT STUFF:	sleep(125);	//Be safe, don't close before all data has been sent

			theOutput.flush();
			so_userConnection.setSoTimeout(i_soTimeoutAfterKeepAliveTransfer);//This make sure that the next time we read form the inputstream (read what the browser has sent to us) we will only wait for 5 seconds.

			//REMOVE ALL CLOSE:	theOutput.close();
} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ showDirectorylisting:\n"+e.getMessage());}
	}


	private String makeFilenameToNiceOutputWithoutHTML(String fileName, String fileSize, String lastModified, int argMaximumFileNameSize)
	{
		StringBuffer strBuf=new StringBuffer("&nbsp;  <B>");	//&nbsp; required, or Opera 7 will ignore the first spaces on each line, so start with &nbsp; instead...
		int fileNameLength=fileName.length();
		if (fileNameLength<argMaximumFileNameSize)
		{
			strBuf.append(fileName);
			strBuf.append("   ");
			int forGoesTo=argMaximumFileNameSize+i_maxFileSizeLength-fileNameLength-fileSize.length();	//Optimization...
			for (int i=0; i<forGoesTo; i++)	//Optimization...
				strBuf.append(" ");
		}
		else
		{
			strBuf.append(fileName.substring(0,argMaximumFileNameSize));
			strBuf.append("   ");
			int forGoesTo=fileNameLength-fileSize.length();	//Optimization...
			for (int i=0; i<forGoesTo; i++)	//Optimization...
				strBuf.append(" ");
		}

		strBuf.append(fileSize);
		strBuf.append("     ");
		strBuf.append(lastModified);
		strBuf.append("</B><BR>");

		return strBuf.toString();
	}

	private String makeFilenameToNiceOutput(String fileName, String fileSize, String lastModified, int argMaximumFileNameSize)
	{
		StringBuffer strBuf=new StringBuffer("<A HREF=\"");
		strBuf.append(fileName);
		strBuf.append("\" STYLE=\"text-decoration: none;\"><IMG SRC=\"/Image:showFileicon\" BORDER=0 ALT=\"File\"> ");


		int fileNameLength=fileName.length();
		if (fileNameLength<argMaximumFileNameSize)
		{
			strBuf.append(fileName);
			strBuf.append("</A>");
			strBuf.append("  ");
			int forGoesTo=argMaximumFileNameSize-fileNameLength+i_maxFileSizeLength-fileSize.length();	//-2, because we have two " " beside the <IMG ...> and </A>	//Optimization...
			for (int i=0; i<forGoesTo; i++)	//Optimization...
				strBuf.append(" ");
		}
		else
		{
			strBuf.append(fileName.substring(0,argMaximumFileNameSize));
			strBuf.append("</A>");
			strBuf.append("  ");
			int forGoesTo=i_maxFileSizeLength-fileSize.length();	//-2, because we have two " " beside the <IMG ...> and </A>	//Optimization...
			for (int i=0; i<forGoesTo; i++)	//Optimization...
				strBuf.append(" ");
		}
//		strBuf.append(fileName);

//		int forGoesTo=argMaximumFileNameSize+16-fileName.length()-fileSize.length();	//Optimization...
//		for (int i=0; i<forGoesTo; i++)	//Optimization...
//			strBuf.append(" ");
		strBuf.append(fileSize);
		strBuf.append("     ");
		strBuf.append(lastModified);
		strBuf.append("<BR>");

		return strBuf.toString();
	}

	//only s_requestedDocumentWithoutUnescape needs to be set (not the other location-variables) when this is called...
	private void redirectToItselfWithSlash()// throws IOException
	{
try {
		b_hasBeenRedirected=true;
		b_logThisHit=false;

		readAllJunkHeaderData();
		//s_errorStatus="301 Moved Permanently";

		so_userConnection.setSoTimeout(0);//This will make sure that the connection doesn't close immediately after the file download. Why this?: Because if we didn't have this, and lets say ".getSoTimeout()" is 5 sec, then a file download on for example 6 seconds would result in that the connection has been closed as soon as we had reached a ".read(XXX)"-method. Now we set this to 0 (infinity) before we send data and we set this back to for example 5 seconds before we read data (call the ".read(XXX)"-method).

//Vid test av fel i Explorer d� man bes�ker "/katalogUtanSlash" och man inte redirectas till "/katalogUtanSlash/".
//s_requestedHTTP=CONSTANT_HTTP10;
//b_useKeepAlive=false;
//i_sendWhatData=DATATYPE_HEADONLY;


//Note, a bug in Internet Explorer:
//The behaviour of Internet Explorer is:
//It sends a request for "/abc%20def" (this bug is only valid for folders with spaces in the name
//(maybe other special charaters as well)) and then Xerver responds with
//"HTTP/1.1 301 Moved Permanently" and with a new location which is "/abc%20def/".
//If the new request that Internet Explorer sends to "/abc%20def/" gives a 403 error response
//then Explorer will try again and again infinite times!!!
//
//So once again, if (1) explorer asks for a folder with a space in the name
//and (2) it ask for the folder name without the last slash (so it recieves a
//301 Moved Permanently message) and (3) the folder itself will return an error message,
//then explorer will go on forever and try to get the folder,
//ignoring all the 403 messages it receives.

		ChunkedDataOutputStream theOutput=new ChunkedDataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()), s_requestedHTTP.equals(CONSTANT_HTTP11), b_logThisHit); //Chunked data transfer is supported only with HTTP/1.1

//		theOutput.writeBytes(	"HTTP/1.0 303 See Other \r\n"+
//		theOutput.writeBytes(	s_requestedHTTP+" 302 Redirected\n"+	//WARNING!!!! THIS MUST BE "\n", CAN NOT BE "\r\n" HERE, OR IT WON'T WORK WITH ALL BROWSERS, FOR EXAMPLE NETSCAPE 1, EXPLORER 5 M.FL. (seems to be a suspect problem :/ )
		if (i_sendWhatData!=DATATYPE_BODYONLY)
		{
			theOutput.writeBytes((	s_requestedHTTP+" 301 Moved Permanently\r\n"+
				"Date: "+df_dateFormat.format(d_dateToday)+"\r\n"+
				"Server: "+s_replyServerName+"\r\n"+
				((s_requestedHTTP.equals(CONSTANT_HTTP11))?("Transfer-Encoding: chunked\r\n"):(""))+//Only HTTP/1.1-browser will understand this
				((b_useKeepAlive)?("Connection: Keep-Alive\r\n"):("Connection: Close\r\n"))+
				"Location: "+s_requestedDocumentWithoutUnescape+"/\r\n\r\n"),false);
		}
		if (i_sendWhatData!=DATATYPE_HEADONLY)
		{
			theOutput.writeBytes(("<html><head>\r\n"+
				"<title>301 Moved Permanently</title>\r\n"+
				"</head><body>\r\n"+
				"<h1>Moved Permanently</h1>\r\n"+
				"<p>The document has moved <a href=\""+
				s_requestedDocumentWithoutUnescape+"/"+
				"\">here</a>.</p>\r\n"+
				"</body></html>\r\n"),true);

		}

		theOutput.finalizeDataTransfer();


		//NO MORE TIMEOUT STUFF:	yield();
		//NO MORE TIMEOUT STUFF:	sleep(50);	//Be safe, don't close before all data has been sent


		//REMOVE ALL CLOSE:	theOutput.close();

		so_userConnection.setSoTimeout(i_soTimeoutAfterKeepAliveTransfer);//This make sure that the next time we read form the inputstream (read what the browser has sent to us) we will only wait for 5 seconds.

} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ redirectToItselfWithSlash:\n"+e.getMessage());}
	}

	/*
	private void crateHashTableWithFileExtensions()
	{
		HM_allFileExt=new HashMap();
		String val;
		val="text/html";
		HM_allFileExt.put("htm",val);
		HM_allFileExt.put("shtml",val);
		HM_allFileExt.put("html",val);
		HM_allFileExt.put("shtm",val);
		HM_allFileExt.put("asp",val);
		val="text/html";
		HM_allFileExt.put("txt",val);
		HM_allFileExt.put("text",val);
		HM_allFileExt.put("c++",val);
		HM_allFileExt.put("ini",val);
		HM_allFileExt.put("pl",val);
		HM_allFileExt.put("java",val);
		HM_allFileExt.put("inf",val);
		HM_allFileExt.put("cc",val);
		HM_allFileExt.put("c",val);
		val="image/jpeg";
		HM_allFileExt.put("jpg",val);
		HM_allFileExt.put("jpeg",val);
		HM_allFileExt.put("jpe",val);
		val="image/gif";
		HM_allFileExt.put("gif",val);
		val="image/png";
		HM_allFileExt.put("png",val);
	}
	*/


	private String getMimeTypeFromFileExt(String s_fileExt)
	{
			if (s_requestedFileName.equals(""))	//Note: "s_requestedFileName", not "s_fileExt"
					return "text/html";
			if (	s_fileExt.equalsIgnoreCase("htm") ||
				s_fileExt.equalsIgnoreCase("shtml") ||
				s_fileExt.equalsIgnoreCase("html") ||
				s_fileExt.equalsIgnoreCase("shtm") ||
				s_fileExt.equalsIgnoreCase("asp"))
					return "text/html";
			if (	s_fileExt.equalsIgnoreCase("txt") ||
				s_fileExt.equalsIgnoreCase("text") ||
				s_fileExt.equalsIgnoreCase("ini") ||
				s_fileExt.equalsIgnoreCase("c") ||
				s_fileExt.equalsIgnoreCase("cc") ||
				s_fileExt.equalsIgnoreCase("c++") ||
				s_fileExt.equalsIgnoreCase("h") ||
				s_fileExt.equalsIgnoreCase("pl") ||
				s_fileExt.equalsIgnoreCase("java") ||
				s_fileExt.equalsIgnoreCase("webl") ||
				s_fileExt.equalsIgnoreCase("inf"))
					return "text/plain";
			if (	s_fileExt.equalsIgnoreCase("jpeg") ||
				s_fileExt.equalsIgnoreCase("jpg") ||
				s_fileExt.equalsIgnoreCase("jpe"))
					return "image/jpeg";
			if (	s_fileExt.equalsIgnoreCase("gif"))
					return "image/gif";
			if (	s_fileExt.equalsIgnoreCase("png"))
					return "image/png";
			if (	s_fileExt.equalsIgnoreCase("mov"))
					return "video/quicktime";
			if (	s_fileExt.equalsIgnoreCase("js"))
					return "application/x-javascript";
			if (	s_fileExt.equalsIgnoreCase("midi"))
					return "audio/midi";
			if (	s_fileExt.equalsIgnoreCase("mp2"))
					return "audio/mpeg";
			if (	s_fileExt.equalsIgnoreCase("mp3"))
					return "audio/mpeg";
			if (	s_fileExt.equalsIgnoreCase("mpe"))
					return "video/mpeg";
			if (	s_fileExt.equalsIgnoreCase("mpeg"))
					return "video/mpeg";
			if (	s_fileExt.equalsIgnoreCase("mpg"))
					return "video/mpeg";
			if (	s_fileExt.equalsIgnoreCase("mpga"))
					return "audio/mpeg";
			if (	s_fileExt.equalsIgnoreCase("php3"))
					return "application/x-httpd-php3";
			if (	s_fileExt.equalsIgnoreCase("phtml-msql2"))
					return "application/x-httpd-php-msql2";
			if (	s_fileExt.equalsIgnoreCase("phtml"))
					return "application/x-httpd-php";
			if (	s_fileExt.equalsIgnoreCase("ps"))
					return "application/postscript";
			if (	s_fileExt.equalsIgnoreCase("wml"))
					return "text/vnd.wap.wml";
			if (	s_fileExt.equalsIgnoreCase("wbmp"))
					return "image/vnd.wap.wbmp";
			if (	s_fileExt.equalsIgnoreCase("wmls"))
					return "text/vnd.wap.wmlscript";
			if (	s_fileExt.equalsIgnoreCase("wmlc"))
					return "application/vnd.wap.wmlc";
			if (	s_fileExt.equalsIgnoreCase("wmlsc"))
					return "application/vnd.wap.wmlscriptc";
			if (	s_fileExt.equalsIgnoreCase("ra"))
					return "audio/x-realaudio";
			if (	s_fileExt.equalsIgnoreCase("ram"))
					return "audio/x-pn-realaudio";
			if (	s_fileExt.equalsIgnoreCase("pdf"))
					return "application/pdf";
			if (	s_fileExt.equalsIgnoreCase("swf"))
					return "application/x-shockwave-flash";
			if (	s_fileExt.equalsIgnoreCase("uu") ||
							s_fileExt.equalsIgnoreCase("exe"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("ps"))
					return "application/postscript";
			if (	s_fileExt.equalsIgnoreCase("zip"))
					return "application/zip";
			if (	s_fileExt.equalsIgnoreCase("sh"))
					return "application/x-shar";
			if (	s_fileExt.equalsIgnoreCase("tar"))
					return "application/x-tar";
			if (	s_fileExt.equalsIgnoreCase("au") ||
							s_fileExt.equalsIgnoreCase("snd"))
					return "audio/basic";
			if (	s_fileExt.equalsIgnoreCase("wav"))
					return "audio/x-wav";
			if (	s_fileExt.equalsIgnoreCase("xml"))
					return "text/xml";
			if (	s_fileExt.equalsIgnoreCase("hqx"))
					return "application/mac-binhex40";
			if (	s_fileExt.equalsIgnoreCase("cpt"))
					return "application/mac-compactpro";
			if (	s_fileExt.equalsIgnoreCase("ai"))
					return "application/postscript";
			if (	s_fileExt.equalsIgnoreCase("aif"))
					return "audio/x-aiff";
			if (	s_fileExt.equalsIgnoreCase("aifc"))
					return "audio/x-aiff";
			if (	s_fileExt.equalsIgnoreCase("aiff"))
					return "audio/x-aiff";
			if (	s_fileExt.equalsIgnoreCase("au"))
					return "audio/basic";
			if (	s_fileExt.equalsIgnoreCase("avi"))
					return "video/x-msvideo";
			if (	s_fileExt.equalsIgnoreCase("bcpio"))
					return "application/x-bcpio";
			if (	s_fileExt.equalsIgnoreCase("bin"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("bmp"))
					return "image/x-xbitmap";
			if (	s_fileExt.equalsIgnoreCase("cdf"))
					return "application/x-netcdf";
			if (	s_fileExt.equalsIgnoreCase("class"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("cpio"))
					return "application/x-cpio";
			if (	s_fileExt.equalsIgnoreCase("cpt"))
					return "application/mac-compactpro";
			if (	s_fileExt.equalsIgnoreCase("csh"))
					return "application/x-csh";
			if (	s_fileExt.equalsIgnoreCase("css"))
					return "text/css";
			if ( 	s_fileExt.equalsIgnoreCase("svg"))
					return "image/svg+xml";
			if ( 	s_fileExt.equalsIgnoreCase("svgz"))
					return "image/svg+xml";
			if (	s_fileExt.equalsIgnoreCase("dcr"))
					return "application/x-director";
			if (	s_fileExt.equalsIgnoreCase("dir"))
					return "application/x-director";
			if (	s_fileExt.equalsIgnoreCase("dll"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("dms"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("doc"))
					return "application/msword";
			if (	s_fileExt.equalsIgnoreCase("dtd"))
					return "text/xml";
			if (	s_fileExt.equalsIgnoreCase("dvi"))
					return "application/x-dvi";
			if (	s_fileExt.equalsIgnoreCase("dwg"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("wax"))
					return "audio/x-ms-wax";
			if (	s_fileExt.equalsIgnoreCase("wma"))
					return "audio/x-ms-wma";
			if (	s_fileExt.equalsIgnoreCase("asf"))
					return "video/x-ms-asf";
			if (	s_fileExt.equalsIgnoreCase("asx"))
					return "video/x-ms-asf";
			if (	s_fileExt.equalsIgnoreCase("wmv"))
					return "video/x-ms-wmv";
			if (	s_fileExt.equalsIgnoreCase("wvx"))
					return "video/x-ms-wvx";
			if (	s_fileExt.equalsIgnoreCase("wm"))
					return "video/x-ms-wm";
			if (	s_fileExt.equalsIgnoreCase("wmx"))
					return "video/x-ms-wmx";
			if (	s_fileExt.equalsIgnoreCase("wmz"))
					return "application/x-ms-wmz";
			if (	s_fileExt.equalsIgnoreCase("wmd"))
					return "application/x-ms-wmd";
			if (	s_fileExt.equalsIgnoreCase("smi") ||
					s_fileExt.equalsIgnoreCase("smil"))
					return "application/smil";
			if (	s_fileExt.equalsIgnoreCase("rv"))
					return "audio/vnd.rn-realvideo";
			if (	s_fileExt.equalsIgnoreCase("dxr"))
					return "application/x-director";
			if (	s_fileExt.equalsIgnoreCase("eps"))
					return "application/postscript";
			if (	s_fileExt.equalsIgnoreCase("etx"))
					return "text/x-setext";
			if (	s_fileExt.equalsIgnoreCase("evy"))
					return "application/x-envoy";
			if (	s_fileExt.equalsIgnoreCase("fif"))
					return "application/fractals";
			if (	s_fileExt.equalsIgnoreCase("fli"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("gl"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("gtar"))
					return "application/x-gtar";
			if (	s_fileExt.equalsIgnoreCase("gz"))
					return "application/x-gzip";
			if (	s_fileExt.equalsIgnoreCase("hdf"))
					return "application/x-hdf";
			if (	s_fileExt.equalsIgnoreCase("hpx"))
					return "application/mac-binhex40";
			if (	s_fileExt.equalsIgnoreCase("hqx"))
					return "application/mac-binhex40";
			if (	s_fileExt.equalsIgnoreCase("ice"))
					return "x-conference/x-cooltalk";
			if (	s_fileExt.equalsIgnoreCase("ief"))
					return "image/ief";
			if (	s_fileExt.equalsIgnoreCase("iges"))
					return "model/iges";
			if (	s_fileExt.equalsIgnoreCase("igs"))
					return "model/iges";
			if (	s_fileExt.equalsIgnoreCase("isv"))
					return "bws-internal/intrasrv-urlencoded";
			if (	s_fileExt.equalsIgnoreCase("jfm"))
					return "bws-internal/intrasrv-form";
			if (	s_fileExt.equalsIgnoreCase("jrp"))
					return "bws-internal/intrasrv-report";
			if (	s_fileExt.equalsIgnoreCase("kar"))
					return "audio/midi";
			if (	s_fileExt.equalsIgnoreCase("latex"))
					return "application/x-latex";
			if (	s_fileExt.equalsIgnoreCase("lha"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("ls"))
					return "application/x-javascript";
			if (	s_fileExt.equalsIgnoreCase("lzh"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("man"))
					return "application/x-troff-man";
			if (	s_fileExt.equalsIgnoreCase("me"))
					return "application/x-troff-me";
			if (	s_fileExt.equalsIgnoreCase("mesh"))
					return "model/mesh";
			if (	s_fileExt.equalsIgnoreCase("mid"))
					return "audio/midi";
			if (	s_fileExt.equalsIgnoreCase("mif"))
					return "application/x-mif";
			if (	s_fileExt.equalsIgnoreCase("movie"))
					return "video/x-sgi-movie";
			if (	s_fileExt.equalsIgnoreCase("mocha"))
					return "application/x-javascript";
			if (	s_fileExt.equalsIgnoreCase("ms"))
					return "application/x-troff-ms";
			if (	s_fileExt.equalsIgnoreCase("msh"))
					return "model/mesh";
			if (	s_fileExt.equalsIgnoreCase("nc"))
					return "application/x-netcdf";
			if (	s_fileExt.equalsIgnoreCase("oda"))
					return "application/oda";
			if (	s_fileExt.equalsIgnoreCase("pac"))
					return "application/x-ns-proxy-autoconfig";
			if (	s_fileExt.equalsIgnoreCase("pbm"))
					return "image/x-portable-bitmap";
			if (	s_fileExt.equalsIgnoreCase("pdb"))
					return "chemical/x-pdb";
			if (	s_fileExt.equalsIgnoreCase("pgm"))
					return "image/x-portable-graymap";
			if (	s_fileExt.equalsIgnoreCase("pnm"))
					return "image/x-portable-anymap";
			if (	s_fileExt.equalsIgnoreCase("ppm"))
					return "image/x-portable-pixmap";
			if (	s_fileExt.equalsIgnoreCase("ppt"))
					return "application/powerpoint";
			if (	s_fileExt.equalsIgnoreCase("qt"))
					return "video/quicktime";
			if (	s_fileExt.equalsIgnoreCase("ras"))
					return "image/x-cmu-raster";
			if (	s_fileExt.equalsIgnoreCase("rgb"))
					return "image/x-rgb";
			if (	s_fileExt.equalsIgnoreCase("roff"))
					return "application/x-troff";
			if (	s_fileExt.equalsIgnoreCase("rpm"))
					return "audio/x-pn-realaudio-plugin";
			if (	s_fileExt.equalsIgnoreCase("rtf"))
					return "application/rtf";
			if (	s_fileExt.equalsIgnoreCase("rtx"))
					return "text/richtext";
			if (	s_fileExt.equalsIgnoreCase("scm"))
					return "application/octet-stream";
			if (	s_fileExt.equalsIgnoreCase("sgm"))
					return "text/x-sgml";
			if (	s_fileExt.equalsIgnoreCase("sgml"))
					return "text/x-sgml";
			if (	s_fileExt.equalsIgnoreCase("sh"))
					return "application/x-sh";
			if (	s_fileExt.equalsIgnoreCase("shar"))
					return "application/x-shar";
			if (	s_fileExt.equalsIgnoreCase("silo"))
					return "model/mesh";
			if (	s_fileExt.equalsIgnoreCase("sit"))
					return "application/stuffit";
			if (	s_fileExt.equalsIgnoreCase("sit"))
					return "application/x-stuffit";
			if (	s_fileExt.equalsIgnoreCase("skd"))
					return "application/x-koan";
			if (	s_fileExt.equalsIgnoreCase("skm"))
					return "application/x-koan";
			if (	s_fileExt.equalsIgnoreCase("skp"))
					return "application/x-koan";
			if (	s_fileExt.equalsIgnoreCase("skt"))
					return "application/x-koan";
			if (	s_fileExt.equalsIgnoreCase("snd"))
					return "audio/basic";
			if (	s_fileExt.equalsIgnoreCase("src"))
					return "application/x-wais-source";
			if (	s_fileExt.equalsIgnoreCase("sv4cpio"))
					return "application/x-sv4cpio";
			if (	s_fileExt.equalsIgnoreCase("sv4crc"))
					return "application/x-sv4crc";
			if (	s_fileExt.equalsIgnoreCase("t"))
					return "application/x-troff";
			if (	s_fileExt.equalsIgnoreCase("tcl"))
					return "application/x-tcl";
			if (	s_fileExt.equalsIgnoreCase("tex"))
					return "application/x-tex";
			if (	s_fileExt.equalsIgnoreCase("texi"))
					return "application/x-texinfo";
//			if (	s_fileExt.equalsIgnoreCase("texi"))
//					return "application/x-textinfo";
			if (	s_fileExt.equalsIgnoreCase("texinfo"))
					return "application/x-textinfo";
			if (	s_fileExt.equalsIgnoreCase("tif"))
					return "image/tiff";
			if (	s_fileExt.equalsIgnoreCase("tiff"))
					return "image/tiff";
			if (	s_fileExt.equalsIgnoreCase("tr"))
					return "application/x-troff";
			if (	s_fileExt.equalsIgnoreCase("tsp"))
					return "application/dsptype";
			if (	s_fileExt.equalsIgnoreCase("tsv"))
					return "text/tab-separated-values";
			if (	s_fileExt.equalsIgnoreCase("ustar"))
					return "application/x-ustar";
			if (	s_fileExt.equalsIgnoreCase("vcd"))
					return "application/x-cdlink";
			if (	s_fileExt.equalsIgnoreCase("vox"))
					return "audio/voxware";
			if (	s_fileExt.equalsIgnoreCase("vrml"))
					return "model/vrml";
			if (	s_fileExt.equalsIgnoreCase("wrl"))
					return "model/vrml";
			if (	s_fileExt.equalsIgnoreCase("xbm"))
					return "image/x-xbitmap";
			if (	s_fileExt.equalsIgnoreCase("xml"))
					return "text/xml";
			if (	s_fileExt.equalsIgnoreCase("xpm"))
					return "image/x-xpixmap";
			if (	s_fileExt.equalsIgnoreCase("xwd"))
					return "image/x-xwindowdump";
			if (	s_fileExt.equalsIgnoreCase("xyz"))
					return "chemical/x-pdb";
			if (	s_fileExt.equalsIgnoreCase("z"))
					return "application/x-compress";

			return "text/plain";	//Default
	}


/*
	private void exceptionOccured(Exception e)
	{
		System.out.println(b_isRunningScript+" <==> "+e);
		if (b_isRunningScript)
		{
			rs_process.killProcess();
		}
	}
*/


	//Testing...
	protected void finalize() throws Throwable
	{
		if (so_userConnection!=null)
		{
			//System.out.println("so_userConnection �r inte null.");
			try {
				if (so_userConnection.getOutputStream()!=null)
					so_userConnection.getOutputStream().flush();
			}
			catch (Exception e)
			{
				//System.out.println("so_userConnection.getOutputStream() kan inte flush:as.");
			}
			so_userConnection.close();
			so_userConnection=null;
		}
	}
}

