//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class represents an account containing what permissions he has, what aliases he has etc.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class UserData
{
	private final static boolean b_showErrors=false;
	private final static String s_userFolder=FTPServerController.s_userFolder;
	private final static String s_userDataExtension=FTPServerController.s_userDataExtension;
	private String s_aliasesFromFile;
	private String s_permissionsFromFile;
	private MyHashTableWithPaths MH_allPermissions;
	private String [] as_writePermissionDirs;
	private String [] as_readPermissionDirs;
	private String [] as_createPermissionDirs;
	private String [] as_listPermissionDirs;
	private String [] as_aliasesName;
	private String [] as_aliasesPath;
	private String s_username;
	private String s_password;
	private String s_root;

	public UserData(String argUsername) throws Exception
	{
		s_username=argUsername;
		updateData();
	}

	public String getPassword()
	{
		return s_password;
	}

	public String getUsername()
	{
		return s_username;
	}


	/**
	* Update the information stored in this class from file (in case the user data file has been changed).
	*/
	public void updateData() throws Exception
	{
		String tmpString;
		String [] as_TMPallPermissions, as_TMPallAliases;
		DatabaseFile DF_databaseFile=new DatabaseFile(s_userFolder+s_username+s_userDataExtension);

		//READ EVERYTHING FROM "USERNAME.DAT"

		if ((tmpString=DF_databaseFile.getValue("PASSWORD"))!=null)
			s_password=tmpString;
			else
			s_password="";

		if ((tmpString=DF_databaseFile.getValue("ROOT"))!=null)
			s_root=tmpString;
		else
			s_root="";

		if ((s_permissionsFromFile=DF_databaseFile.getValue("PERMISSIONS"))!=null)
		{
			MH_allPermissions=new MyHashTableWithPaths(s_permissionsFromFile/*MyString.searchAndReplace(s_permissionsFromFile,"*;",";")*/, ",", ";");	//Make sure that "c:\a\*" becomes "c:\a\"
			as_TMPallPermissions=MyString.makeArrayOfString(s_permissionsFromFile,",");
		}
		else
		{
			MH_allPermissions=new MyHashTableWithPaths("", ",", ";");
			as_TMPallPermissions=MyString.makeArrayOfString("",",");
		}

		if ((s_aliasesFromFile=DF_databaseFile.getValue("ALIASES"))!=null)
			as_TMPallAliases=MyString.makeArrayOfString(s_aliasesFromFile,",");
		else
			as_TMPallAliases=MyString.makeArrayOfString("",",");


		DF_databaseFile.destroy();
		DF_databaseFile=null;

		//FIX VARS
		fixPermissionVars(as_TMPallPermissions);
		fixAliasVars(as_TMPallAliases);
	}

	private void fixPermissionVars(String [] as_allPermissions)
	{
		//ALL THESE ARE TEMPORARY VARIABLES (NO GLOBAL VARIABLES)
		int i_lengthAllPermissions=as_allPermissions.length;
		String [] tmpWritePermissionDirs=new String[i_lengthAllPermissions];
		String [] tmpReadPermissionDirs=new String[i_lengthAllPermissions];
		String [] tmpCreatePermissionDirs=new String[i_lengthAllPermissions];
		String [] tmpListPermissionDirs=new String[i_lengthAllPermissions];
		String attribute, path, tmpLine;
		int i_countWrite=0, i_countRead=0, i_countCreate=0, i_countList=0;
		int separatorIndexOf;


		//GET THE LENGTH OF as_XXXPermissionDirs AND SAVE THE PATHS IN tmpXXXPermissionDirs
		for (int i=0; i<i_lengthAllPermissions; i++)
		{
			tmpLine=as_allPermissions[i];
			separatorIndexOf=tmpLine.lastIndexOf(';');
			path=tmpLine.substring(0,separatorIndexOf);
			attribute=tmpLine.substring(separatorIndexOf+1);

			if (attribute.indexOf('w')!=-1)
			{
				i_countWrite++;
				tmpWritePermissionDirs[i]=path;
			}
			if (attribute.indexOf('r')!=-1)
			{
				i_countRead++;
				tmpReadPermissionDirs[i]=path;
			}
			if (attribute.indexOf('c')!=-1)
			{
				i_countCreate++;
				tmpCreatePermissionDirs[i]=path;
			}
			if (attribute.indexOf('l')!=-1)
			{
				i_countList++;
				tmpListPermissionDirs[i]=path;
			}
		}

		//NOW WE KNOW THE SIZE OF THESE VARIABLES (as_XXXPermissionDirs)
		as_writePermissionDirs=new String[i_countWrite];
		as_readPermissionDirs=new String[i_countRead];
		as_createPermissionDirs=new String[i_countCreate];
		as_listPermissionDirs=new String[i_countList];

		//CREATE as_XXXPermissionDirs NOW (AND DESTROY VALUES OF i_countXXX, BUT WE DON'T NEED THEM ANYMORE)
		for (int i=0; i<i_lengthAllPermissions; i++)
		{
			if (tmpWritePermissionDirs[i]!=null)
				as_writePermissionDirs[--i_countWrite]=tmpWritePermissionDirs[i];
			if (tmpReadPermissionDirs[i]!=null)
				as_readPermissionDirs[--i_countRead]=tmpReadPermissionDirs[i];
			if (tmpCreatePermissionDirs[i]!=null)
				as_createPermissionDirs[--i_countCreate]=tmpCreatePermissionDirs[i];
			if (tmpListPermissionDirs[i]!=null)
				as_listPermissionDirs[--i_countList]=tmpListPermissionDirs[i];
		}
	}



	private void fixAliasVars(String [] as_allAliases)
	{
		as_aliasesName=new String[as_allAliases.length];
		as_aliasesPath=new String[as_allAliases.length];

		String tmpLine;
		int separatorIndexOf;
		for (int i=0; i<as_allAliases.length; i++)
		{
			tmpLine=as_allAliases[i];
			separatorIndexOf=tmpLine.indexOf('=');	//Note we will get an error if the database has wrong format. If each alias-entry does not have an "=" like "alias=c:\" we will return -1 here which will give an error on the following line (in substring)
			as_aliasesName[i]=tmpLine.substring(0,separatorIndexOf);
			as_aliasesPath[i]=tmpLine.substring(separatorIndexOf+1);
		}
	}

	/**
	* Returns a MyHashTable with all folders and permissions.
	* Note that all * has been removed from the folders name in the MyHashTable returned.
	*/
	public MyHashTableWithPaths getAllPermissionDirs()
	{
		return MH_allPermissions;
	}

	public String [] getWritePermissionDirs()
	{
		return as_writePermissionDirs;
	}

	public String [] getReadPermissionDirs()
	{
		return as_readPermissionDirs;
	}

	public String [] getCreatePermissionDirs()
	{
		return as_createPermissionDirs;
	}

	public String [] getListPermissionDirs()
	{
		return as_listPermissionDirs;
	}

	public String [] getAliasesName()
	{
		return as_aliasesName;
	}

	public String [] getAliasesPath()
	{
		return as_aliasesPath;
	}

	public String getRoot()
	{
		return s_root;
	}

	public String getAliasString()
	{
		return s_aliasesFromFile;
	}

	public String getPermissionsString()
	{
		return s_permissionsFromFile;
	}

	public int hashCode()
	{
		return s_username.hashCode();
	}

	public boolean equals(Object obj)
	{
		try {
			UserData userdata=(UserData)obj;
			return userdata.getUsername().equals(s_username);
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ equals: "+e);
		}
		return false;
	}
}


