//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################

package common;
import webserver.*;
import ftp_server.*;




/**
 *
 * <B>How to use:</B>
 * <BR>
 *<CODE>MyHashTable MHT=new MyHashTable(String s);</CODE>
 * <BR>
 *<CODE>MyHashTable MHT=new MyHashTable(String s, String separator1, String separator2);</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * Creates something that looks like a hash table.
 * <BR>
 * You give an key (<CODE>String</CODE>) and receive an value (<CODE>String</CODE>) (the key is case insensitive).
 * <BR>
 * You can't add/remove Strings to your <CODE>MyHashTable</CODE>.
 * <BR>
 * When you once have created it, it remains constant.
 * <BR>
 * NOTE: The <I>key</I>s and the <I>value</I>s must not contain <I>separator1</I>.
 * <BR>
 * The <I>key</I>s must not contain <I>separator2</I>.
 * <BR>
 * <BR>
 *
 * Example:
 * <BR>
 * s = "key1=value1,key2=value2,key3=value3"
 * <BR>
 * or
 * <BR>
 * s = "key1=value1,key2=value=2,key3=v=a=l=u=e=3"
 * <BR>
 *
 * <BR>
 * <BR>
 *
 * If you use the constructor with only one argument, <I>separator1</I> and <I>separator2</I> are defined as:
 * <BR>
 * separator1=",";
 * <BR>
 * separator2="=";
 *
 * <BR>
 * <BR>
 *
 * Note: "<I>key1=value1,keyNoEqualSignValue,key3=value3</I>" will generate these pairs:
 * <BR>
 * key1="value1"
 * <BR>
 * keyNoEqualSignValue=""
 * <BR>
 * key3="value3"
 *
 *
 *
 *
 * <BR>
 * <BR>
 * For example: s="php=php,php3=php,php4=php,pl=perl,cgi=perl"
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


//Note: To make MyHashTable CaSe SeNsItIvE, change all "equalsIgnoreCase" to "equals"
final public class MyHashTable
{
	private String [] sa_keys;
	private String [] sa_values;
	//private String s_wholeString;
	private int i_sizeOfArray;


	/**
	* Creates a hash table with <CODE>separator1=","</CODE> and <CODE>separator2="="</CODE>
	* @param txtToMakeHashWith "key1=value1,key2=value2,key3=value3"
	*/
	public MyHashTable(String txtToMakeHashWith)
	{
		this(txtToMakeHashWith, ",", "=");
	}


	/**
	* @param txtToMakeHashWith = "key1=value1,key2=value2,key3=value3"
	* @param separator1 by default <CODE>==','</CODE>;
	* @param separator2 by default <CODE>=='='</CODE>;
	*/
	public MyHashTable(String txtToMakeHashWith, String separator1, String separator2)
	{
		String s_wholeString=txtToMakeHashWith;	//Previously this was a global variable
		String [] sa_nyckelVardePar=MyString.makeArrayOfString(txtToMakeHashWith, separator1);
		i_sizeOfArray=sa_nyckelVardePar.length;
		sa_keys=new String[i_sizeOfArray];
		sa_values=new String[i_sizeOfArray];

		for (int i=0; i<i_sizeOfArray; i++)
		{
			if (sa_nyckelVardePar[i].indexOf(separator2)!=-1)
			{
				sa_keys[i]=sa_nyckelVardePar[i].substring(0,sa_nyckelVardePar[i].indexOf(separator2));
				sa_values[i]=sa_nyckelVardePar[i].substring(sa_nyckelVardePar[i].indexOf(separator2)+separator2.length());
			}
			else
			{
				sa_keys[i]=sa_nyckelVardePar[i];
				sa_values[i]="";
			}
		}
	}


	/**
	* This will unescape (<CODE>Mystring.unescape(java.lang.String)</CODE>) all values stored in this HashTable.
	*/
	public void unescapeAllValues()
	{
		for (int i=0; i<i_sizeOfArray; i++)
		{
			sa_values[i]=MyString.unescape(sa_values[i]);
		}
	}


	/**
	* All values in this HashTable will be unescaped and all plus signes (+) will be converted into spaces ( ) (<CODE>Mystring.unescapeMakePlusesIntoSpaces(java.lang.String)</CODE>).
	*/
	public void unescapeMakePlusesIntoSpacesAllValues()
	{
		for (int i=0; i<i_sizeOfArray; i++)
		{
			sa_values[i]=MyString.unescapeMakePlusesIntoSpaces(sa_values[i]);
		}
	}

	/**
	* Give the value at "index" <CODE>key</CODE>.
	* @return Returns null if key doesn't exist.
	*/
	public String giveValueByIndex(String key)
	{
/*
		//not necessery, but makes this method faster (is this really faster?)
		if (s_wholeString.indexOf(key)==-1)
			return null;
*/

		for (int i=0; i<i_sizeOfArray; i++)
			if (key.equalsIgnoreCase(sa_keys[i]))
				return sa_values[i];

		return null;
	}



	/**
	* Give the unescaped value at "index" <CODE>key</CODE>.
	* @return Returns null if key doesn't exist.
	*/
	public String giveUnescapedValueByIndex(String key)
	{
/*
		//not necessery, but makes this method faster (is this really faster?)
		if (s_wholeString.indexOf(key)==-1)
			return null;
*/

		for (int i=0; i<i_sizeOfArray; i++)
			if (key.equalsIgnoreCase(sa_keys[i]))
				return MyString.unescape(sa_values[i]);

		return null;
	}

	/**
	* If the <CODE>bigKey</CODE> is "aaabcd" and there is an index "aaa" and an index "aa", then "aaa".lenth() (=3) is returned (<CODE>bigKey</CODE> shall be longer than the real index).
	* @return Returns -1 if key doesn't exist
	*/
	public int giveBiggestKeySize(String bigKey)
	{
		if (bigKey==null)
			return -1;

		int largestCurrentKey=-1;
		for (int i=0; i<i_sizeOfArray; i++)
		{
			if (bigKey.length()>=sa_keys[i].length())
				if (sa_keys[i].equalsIgnoreCase(bigKey.substring(0,sa_keys[i].length())))
					if (sa_keys[i].length()>largestCurrentKey)
						largestCurrentKey=sa_keys[i].length();
		}

		return largestCurrentKey;
	}
}
