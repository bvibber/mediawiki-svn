// StartXerver.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <malloc.h>



int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

	int i_bufferSize = 100000;

    ZeroMemory( &si, sizeof(si) );
    si.cb = sizeof(si);
    ZeroMemory( &pi, sizeof(pi) );


	//MessageBox(NULL, "Message in windows test", "Window title", MB_OK);


	LPTSTR commandText;

	commandText = (LPTSTR) malloc(i_bufferSize*sizeof(TCHAR));
	strcpy_s(commandText,i_bufferSize,"javaw ");
	addEnvVarToBuffer(commandText, "systemroot");	//Environment variables must be written with small letters
	addEnvVarToBuffer(commandText, "windir");	//Environment variables must be written with small letters
	addEnvVarToBuffer(commandText, "pathext");	//Environment variables must be written with small letters
	addEnvVarToBuffer(commandText, "comspec");	//Environment variables must be written with small letters
	strcat_s(commandText,i_bufferSize," -jar xerver.jar");


	//javaw -Dsystemroot=%SYSTEMROOT% -Dwindir=%WINDIR% -Dpathext=%PATHEXT% -Dcomspec=%COMSPEC% -jar xerver.jar
	//MessageBox(NULL, commandText, "Command that is executed", MB_ICONERROR);

	//LPTSTR commandText=;
    // Start the child process.
    if( !CreateProcess( NULL,   // No module name (use command line).
        commandText, // Command line.
        NULL,             // Process handle not inheritable.
        NULL,             // Thread handle not inheritable.
        FALSE,            // Set handle inheritance to FALSE.
        0,                // No creation flags.
        NULL,             // Use parent's environment block.
        NULL,             // Use parent's starting directory.
        &si,              // Pointer to STARTUPINFO structure.
        &pi )             // Pointer to PROCESS_INFORMATION structure.
    )
    {
		//char tmpBuf[1000];
		//sprintf(tmpBuf,"Xerver could not start since you don't have Java installed on your computer\nPlease download the latest version of Sun Java from:\nhttp://java.com/en/download/\n\nXerver can not run without Java installed on your computer.\n\n%d",GetLastError());
		//MessageBox(NULL, tmpBuf, "Java not found", MB_OK);
		MessageBox(NULL, "Xerver could not start since you don't have Java installed on your computer\nPlease download the latest version of Sun Java from:\nhttp://java.com/en/download/\n\nXerver can not run without Java installed on your computer.\n\nThe technical reason for this error is that javaw.exe\nwas not found when searching through your PATH environment variable.", "Java not found", MB_ICONERROR);

        //printf( "CreateProcess failed (%d).\n", GetLastError() );
        return 0;
    }

    // Wait until child process exits.
    WaitForSingleObject( pi.hProcess, INFINITE );

    // Close process and thread handles.
    CloseHandle( pi.hProcess );
    CloseHandle( pi.hThread );

	return 0;
}


