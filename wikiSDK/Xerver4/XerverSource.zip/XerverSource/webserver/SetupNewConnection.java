//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat
import java.awt.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * Every time a connection is established to Xervers setup program, a <CODE>SetupNewConnection</CODE> is created.
 * <CODE>SetupNewConnection</CODE> is a <CODE>Thread</CODE> and reads what the user requested and gives the user an appropriate response to his/her request.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


//No run-method ==> only one request can be made at once ==> no problem will occur when reading/writing to the config-file
final public class SetupNewConnection extends Thread
{
	private String hiddenFolder="data"+File.separator;
	private String errorFilesFolder="errorHTML"+File.separator;
	private final boolean b_showErrors=false;
	private Date d_dateToday;
	private DateFormat df_dateFormat;
	private String s_allData, s_requestedFolderLocation, s_errorStatus, s_requestMethod, s_requestDocument;
	private Socket so_userConnection;
	private String s_portNr;
	private String s_indexNames;
	private String s_sharedPaths;
	private String s_fileExtensions;
	private String s_rootPath;
	private String s_runnableExtensions;
	private String s_aliasNames;
	private String s_protectedFolders;
	private String s_allowFolderListing;
	private String s_allowTheseFileExtensions;
	private String s_shareHiddenFiles;
	private String s_startupWindowMode;
	private String s_allowCGIScript;
	private String s_logFile;
	private String s_configFile=hiddenFolder+"Xerver2.cfg";
	private SetupXerverKernel mySetupXerverKernel;
	private MyHashTable MyHT_allDataFromQuery;
	private DataOutputStream theOutput;	//Everything written to this will be sent to the browser
	private boolean b_environmentHasBeenSetUp=false;
	private BufferedReader br_theInputWeGetFromBrowser;	//Read the browsers header from this
	private String s_encryptedPasswordGiven;			//This is set during the setup when the user want create a password protected folder
	private final int maxNumbersOfENVAccepted=200;	//Maximum number of environment variables the *browser can tell us* to create. (Note: We might have more than 200 environment variables; because we don't only create environment variables that the browser tell us to create).	  If a browser gives more than 200 environment variables, we just ignore the last variables.
	private int i_valueOfHttpContentLength=0;		//This variable is currently not in use, getEnvironmentVariablesGivenByBrowser uses it to read the POST-data (which might be needed later)
	private String s_stdinDataForPOSTRequests=null;	//This variable is currently not in use, getEnvironmentVariablesGivenByBrowser uses it to read the POST-data (which might be needed later)		//Must be null by default, which means that no POST-data has been read.


	public SetupNewConnection(Socket agrUserConnection, SetupXerverKernel serverSetup)// throws IOException
	{
try {
		mySetupXerverKernel=serverSetup;
		so_userConnection=agrUserConnection;
		d_dateToday = new Date();
		df_dateFormat=DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
		s_errorStatus="200 OK";

		getRequestInformation();
		createVariables();

		theOutput = new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));	//I "java.io.*"

		if (MyHT_allDataFromQuery.giveValueByIndex("save")!=null)	//If there is anything to save...
		{
			if (MyHT_allDataFromQuery.giveValueByIndex("portNr")!=null)
				s_portNr=MyHT_allDataFromQuery.giveValueByIndex("portNr");
			if (MyHT_allDataFromQuery.giveValueByIndex("indexNames")!=null)
				s_indexNames=MyHT_allDataFromQuery.giveValueByIndex("indexNames");
			if (MyHT_allDataFromQuery.giveValueByIndex("sharedPaths")!=null)
				s_sharedPaths=MyHT_allDataFromQuery.giveValueByIndex("sharedPaths");
			if (MyHT_allDataFromQuery.giveValueByIndex("fileExtensions")!=null)
				s_fileExtensions=MyHT_allDataFromQuery.giveValueByIndex("fileExtensions");
			if (MyHT_allDataFromQuery.giveValueByIndex("rootPath")!=null)
				s_rootPath=MyHT_allDataFromQuery.giveValueByIndex("rootPath");
			if (MyHT_allDataFromQuery.giveValueByIndex("runnableExtensions")!=null)
				s_runnableExtensions=MyHT_allDataFromQuery.giveValueByIndex("runnableExtensions");
			if (MyHT_allDataFromQuery.giveValueByIndex("aliasNames")!=null)
				s_aliasNames=MyHT_allDataFromQuery.giveValueByIndex("aliasNames");
			if (MyHT_allDataFromQuery.giveValueByIndex("protectedFolders")!=null)
				s_protectedFolders=MyHT_allDataFromQuery.giveValueByIndex("protectedFolders");
			if (MyHT_allDataFromQuery.giveValueByIndex("allowFolderListing")!=null)
				s_allowFolderListing=MyHT_allDataFromQuery.giveValueByIndex("allowFolderListing");
			if (MyHT_allDataFromQuery.giveValueByIndex("allowTheseFileExtensions")!=null)
				s_allowTheseFileExtensions=MyHT_allDataFromQuery.giveValueByIndex("allowTheseFileExtensions");
			if (MyHT_allDataFromQuery.giveValueByIndex("shareHiddenFiles")!=null)
				s_shareHiddenFiles=MyHT_allDataFromQuery.giveValueByIndex("shareHiddenFiles");
			if (MyHT_allDataFromQuery.giveValueByIndex("startupWindowMode")!=null)
				s_startupWindowMode=MyHT_allDataFromQuery.giveValueByIndex("startupWindowMode");
			if (MyHT_allDataFromQuery.giveValueByIndex("allowCGIScript")!=null)
				s_allowCGIScript=MyHT_allDataFromQuery.giveValueByIndex("allowCGIScript");
			if (MyHT_allDataFromQuery.giveValueByIndex("logFile")!=null)
				s_logFile=MyHT_allDataFromQuery.giveValueByIndex("logFile");


			saveInformationToFile();
		}

		if (MyHT_allDataFromQuery.giveValueByIndex("action")!=null)	//If there is an action given (there shall always be an action given, but not if you visit the "setup root" (="http://localhost:32123/")...
		{
			if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardGeneralSettings"))
			{
				returnThisPage(hiddenFolder+"WizGeneralSettings.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardMenu"))
			{
				returnThisPage(hiddenFolder+"WizMenu.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardFrames"))
			{
				returnThisPage(hiddenFolder+"WizFrames.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("setupDone"))
			{
				showHeaderData("text/html");
				ShowSetupPages.setupDone(theOutput);
				mySetupXerverKernel.setupIsDone(true);	//Let the kernel (mySetupXerverKernel) know that the settings have been changed
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("chooseDirectory"))
			{
				showHeaderData("text/html");
				ShowSetupPages.showChooseDirectory(theOutput,MyHT_allDataFromQuery.giveValueByIndex("currentPath"));	//Note: "MyHT_allDataFromQuery.giveValueByIndex("currentPath")" might be null. If it's null it means the root shall be showed.
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep1"))
			{
				returnThisPage(hiddenFolder+"WizStep1.html", "text/html");
				ShowSetupPages.showSetupWizStep1(theOutput, s_portNr, s_allowFolderListing, s_shareHiddenFiles, s_allowCGIScript, s_logFile);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep2"))
			{
				returnThisPage(hiddenFolder+"WizStep2.html", "text/html");
				ShowSetupPages.showSetupWizStep2(theOutput, s_sharedPaths);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep3"))
			{
				returnThisPage(hiddenFolder+"WizStep3.html", "text/html");
				ShowSetupPages.showSetupWizStep3(theOutput, s_sharedPaths, s_rootPath);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep4"))
			{
				returnThisPage(hiddenFolder+"WizStep4.html", "text/html");
				ShowSetupPages.showSetupWizStep4(theOutput, s_sharedPaths, s_aliasNames);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep5"))
			{
				if (s_allowCGIScript.equals("1") || MyHT_allDataFromQuery.giveValueByIndex("direction")==null)	//IF [CGI-scripts can be run] OR [not coming from the next- or back-button (but from the menu)]....
				{
					returnThisPage(hiddenFolder+"WizStep5.html", "text/html");
					ShowSetupPages.showSetupWizStep5(theOutput, s_runnableExtensions);
				}
				else	//CGI-scripts can't be run.... (Don't ask which file extensions shall be considered runnable files)
				{
					if (MyHT_allDataFromQuery.giveValueByIndex("direction").equals("back")) //If we are pressing the "back" button from Step6
					{
						returnThisPage(hiddenFolder+"WizStep4.html", "text/html");
				ShowSetupPages.showSetupWizStep4(theOutput, s_sharedPaths, s_aliasNames);
					}
					else	//If we are pressing the "next" button from Step4
					{
						returnThisPage(hiddenFolder+"WizStep6.html", "text/html");
						ShowSetupPages.showSetupWizStep6(theOutput, s_indexNames);
					}
				}
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep6"))
			{
					returnThisPage(hiddenFolder+"WizStep6.html", "text/html");
					ShowSetupPages.showSetupWizStep6(theOutput, s_indexNames);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep7"))
			{
					returnThisPage(hiddenFolder+"WizStep7.html", "text/html");
					ShowSetupPages.showSetupWizStep7(theOutput, s_fileExtensions, s_allowTheseFileExtensions);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep8"))
			{
					returnThisPage(hiddenFolder+"WizStep8.html", "text/html");
					ShowSetupPages.showSetupWizStep8(theOutput, s_sharedPaths, s_protectedFolders);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("wizardStep9"))
			{
					returnThisPage(hiddenFolder+"WizStep9.html", "text/html");
					ShowSetupPages.showSetupWizStep9(theOutput, s_startupWindowMode);
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showLogo"))
			{
				returnThisPage(hiddenFolder+"imagelogo.gif", "image/gif");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showBigWizard"))
			{
				returnThisPage(hiddenFolder+"imagewizardbig.gif", "image/gif");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showSmallWizard"))
			{
				returnThisPage(hiddenFolder+"imagewizardsmall.gif", "image/gif");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showWizardHelp"))
			{
				returnThisPage(hiddenFolder+"WizardHelp.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddDirSetup"))
			{
				returnThisPage(hiddenFolder+"AddDirSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddAliasSetup"))
			{
				returnThisPage(hiddenFolder+"AddAliasSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddScriptExtSetup"))
			{
				returnThisPage(hiddenFolder+"AddScriptExtSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddIndSetup"))
			{
				returnThisPage(hiddenFolder+"AddIndSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddExtSetup"))
			{
				returnThisPage(hiddenFolder+"AddExtSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddProtFrameSetup"))
			{
				returnThisPage(hiddenFolder+"AddProtFrameSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddProtSetup"))
			{
				returnThisPage(hiddenFolder+"AddProtSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddProtDirSetup"))
			{
				returnThisPage(hiddenFolder+"AddProtDirSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showAddProtUserSetup"))
			{
				returnThisPage(hiddenFolder+"AddProtUserSetup.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("showEmptyPage"))
			{
				returnThisPage(hiddenFolder+"empty.html", "text/html");
			}
			else if (MyHT_allDataFromQuery.giveValueByIndex("action").equals("promptForPassword"))
			{
				createEnvironmentVariables();
//System.out.println(mySetupXerverKernel.b_show401NotAuthorized);
				if (mySetupXerverKernel.b_show401NotAuthorized || s_encryptedPasswordGiven==null)	//If "s_encryptedPasswordGiven" is null ==> Show 401-message.
				{
					ShowSetupPages.show401NotAuthorizedIsNotAccepted(theOutput, s_encryptedPasswordGiven, df_dateFormat);
					mySetupXerverKernel.b_show401NotAuthorized=false;	//don't give 401-message next time
				}
				else
				{
					ShowSetupPages.show401NotAuthorizedIsAccepted(theOutput, s_encryptedPasswordGiven, df_dateFormat);
					mySetupXerverKernel.b_show401NotAuthorized=true;	//give 401-message next time
				}
			}
			else
			{
				returnThisPage(hiddenFolder+"IndexPage.html", "text/html");	//An invalid "action" has been set
			}
		}
		else
		{
			returnThisPage(hiddenFolder+"IndexPage.html", "text/html");	//No "action" has been set
		}

		yield();
		sleep(125);	//Be safe, don't close before all data has been sent

		theOutput.flush();
		theOutput.close();

} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ SetupNewConnection:\n"+e.getMessage());}
	}



	void getRequestInformation()// throws IOException
	{
try {
		String [] firstLineIndata;

		br_theInputWeGetFromBrowser = new BufferedReader(new InputStreamReader(so_userConnection.getInputStream()));
		firstLineIndata=MyString.makeArrayOfString(br_theInputWeGetFromBrowser.readLine()," ");	//Opera:	"GET /mapp/fil.txt HTTP/1.1"
		s_requestMethod=firstLineIndata[0];	//"GET" eller "GET/"

		s_requestDocument=MyString.unescape(firstLineIndata[1]);	//"kopia%20(2)%20av%20wwwboard.pl" ==> "kopia (2) av wwwboard.pl"

		if (s_requestDocument.startsWith("/?"))
			s_allData=s_requestDocument.substring(2);	//Ignore the first /?, but get everything else
		else
			s_allData=s_requestDocument.substring(1);	//Ignore the first /, but get everything else

} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getRequestInformation:\n"+e.getMessage());}
	}


//From Opera:
//GET /?y4errewfdpp HTTP/1.1
//User-Agent: Mozilla/4.0 (compatible; MSIE 5.0; Windows XP) Opera 6.0  [sv]
//Host: localhost:12345
//Accept: text/html, image/png, image/jpeg, image/gif, image/x-xbitmap, */*
//Accept-Language: sv
//Accept-Charset: windows-1252;q=1.0, utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1
//Accept-Encoding: deflate, gzip, x-gzip, identity, *;q=0
//Cache-Control: no-cache
//Connection: Keep-Alive, TE
//TE: deflate, gzip, chunked, identity, trailers


	private void createVariables()	//Returns true if everything went OK
	{
		MyHT_allDataFromQuery=new MyHashTable(s_allData, "&", "=");
		getSettingsFromFile();
/*
		if (allDataArray.length==13)
		{
			s_portNr=allDataArray[0];
			s_indexNames=allDataArray[1];
			s_sharedPaths=allDataArray[2];
			s_fileExtensions=allDataArray[3];
			s_rootPath=allDataArray[4];
			s_runnableExtensions=allDataArray[5];
			s_aliasNames=allDataArray[6];
			s_protectedFolders=allDataArray[7];
			s_allowFolderListing=allDataArray[8];
			s_allowTheseFileExtensions=allDataArray[9];
			s_shareHiddenFiles=allDataArray[10];
			s_startupWindowMode=allDataArray[11];
			s_allowCGIScript=allDataArray[12];
			s_logFile=allDataArray[13];
			return true;
		}
		else
		{
			System.out.println("ERROR: Felaktig indata!");
			return false;	//Invalid input to this script
		}
*/
	}

	private void saveInformationToFile()
	{
		try
		{
			PrintStream myPrintStream;
			File theFile=new File(s_configFile);
			FileOutputStream fileStreamed=new FileOutputStream(theFile);
			myPrintStream = new PrintStream( fileStreamed );
			myPrintStream.println(s_portNr);
			myPrintStream.println(s_indexNames);
			myPrintStream.println(s_sharedPaths);
			myPrintStream.println(s_fileExtensions);
			myPrintStream.println(s_rootPath);
			myPrintStream.println(s_runnableExtensions);
			myPrintStream.println(s_aliasNames);
			myPrintStream.println(s_protectedFolders);
			myPrintStream.println(s_allowFolderListing);
			myPrintStream.println(s_allowTheseFileExtensions);
			myPrintStream.println(s_shareHiddenFiles);
			myPrintStream.println(s_startupWindowMode);
			myPrintStream.println(s_allowCGIScript);
			myPrintStream.print(s_logFile);		//Last one is print, not println
			yield();
			sleep(50);	//Be safe, don't close before all data has been sent
			myPrintStream.close();
			fileStreamed.close();

			mySetupXerverKernel.setupIsDone(false);	//Let the kernel (mySetupXerverKernel) know that the settings have been changed
		}
		catch (Exception e)
		{
//			if (b_showErrors)
				System.out.println("Could not write to "+s_configFile+".\nMake sure the file is among the other files and that Xerver has write permissions to it.:"+e);
		}
	}


	private void showHeaderData(String contentType)
	{
		try
		{
			theOutput.writeBytes("HTTP/1.1 "+s_errorStatus+" \r\nDate: "+df_dateFormat.format(d_dateToday)+" \r\n"+
               "Server: "+XerverKernel.getXerverName()+" \r\nConnection: close \r\n"+
               "Pragma: no-cache \r\nCache-Control: no-cache \r\n"+
               "Location: / \r\n"+
               "Content-Type: "+contentType+" \r\n\r\n");
		}	catch (Exception e) { if (b_showErrors)System.out.println("An error occured @ showHeaderData:\n"+e.getMessage());}
	}


	private void returnThisPage(String documentToReturn, String contentType)// throws IOException
	{
		FileInputStream fileStreamed=null;

		try
		{
//		DataOutputStream theOutput =new DataOutputStream(so_userConnection.getOutputStream());	//I "java.io.*"
		showHeaderData(contentType);
		File theFile=new File(documentToReturn);
		fileStreamed=new FileInputStream(theFile);

		byte [] myBuffer = new byte[8192];
		int n;
		while ((n=fileStreamed.read(myBuffer))!=-1)
			theOutput.write(myBuffer,0,n);

		yield();
		sleep(125);	//Be safe, don't close before all data has been sent

		//fileStreamed.close();
		}	catch (Exception e) { if (b_showErrors)System.out.println("An error occured @ returnThisPage:\n"+e.getMessage());}

		try
		{
			if (fileStreamed!=null)	//If fileStreamed "holds" a file
			{
				fileStreamed.close();	//Important: This must be reached no matter what! Even if an exception occurs in the try block, whis must be reached. Otherwise the file will be locked by Xerver (locked by Java.exe) until the garbage collector is runned (and you don't know when it will run) and detects that the file (the object "fileStreamed") is no longer referenced from anywhere else and it release the file by automatic. Until this happenes, no other application can write to or rename this file (however, this problem is solved with this line).
			}
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}
	}


	private void getSettingsFromFile()
	{
		try
		{
			BufferedReader f_setupFileData = new BufferedReader(new FileReader(s_configFile));

			s_portNr					=f_setupFileData.readLine();
			s_indexNames				=f_setupFileData.readLine();
			s_sharedPaths				=f_setupFileData.readLine();
			s_fileExtensions			=f_setupFileData.readLine();
			s_rootPath					=f_setupFileData.readLine();
			s_runnableExtensions		=f_setupFileData.readLine();
			s_aliasNames				=f_setupFileData.readLine();
			s_protectedFolders			=f_setupFileData.readLine();
			s_allowFolderListing		=f_setupFileData.readLine();
			s_allowTheseFileExtensions	=f_setupFileData.readLine();
			s_shareHiddenFiles			=f_setupFileData.readLine();
			s_startupWindowMode			=f_setupFileData.readLine();
			s_allowCGIScript			=f_setupFileData.readLine();
			s_logFile					=f_setupFileData.readLine();

			yield();
			sleep(50);	//Be safe, don't close before all data has been sent

			f_setupFileData.close();
		}
		catch (Exception e){if (b_showErrors)System.out.println("An error occured @ getSettingsFromFile:\n"+e.getMessage());}
	}



	private void createEnvironmentVariables()
	{
		if (!b_environmentHasBeenSetUp)
		{
			b_environmentHasBeenSetUp=true;
			getEnvironmentVariablesGivenByBrowser(br_theInputWeGetFromBrowser);
		}
	}




	private String [] getEnvironmentVariablesGivenByBrowser(BufferedReader theInput)
	{
		String [] allENVVariablesTMP=new String[maxNumbersOfENVAccepted], allENVVariables=new String[0];
try {
		String tmp;
		int numberOfENVGivenByBrowser=0;	//This is the number of ENV-variables we set after we have read what the browser has given us. For example both CONTENT_TYPE and HTTP_CONTENT_TYPE are set when we have read "CONTENT_TYPE". The number of lines given to us from the browser is not necessey (and probably not) ==numberOfENVGivenByBrowser

		String tmpStr="_";	//Set this to any none-empty string (!="") (don't set it to null)
		while (theInput.ready() && numberOfENVGivenByBrowser<maxNumbersOfENVAccepted-1)	//(assume: maxNumbersOfENVAccepted=200) less than 199 because it is possible to run "numberOfENVGivenByBrowser++" twice in this loop. (If we start the loop with 199 and run "numberOfENVGivenByBrowser++" twice we will try to write to index 200 (no, not 201; reason: we don't have "++numberOfENVGivenByBrowser"), but the last index of the array is 199 ==> exception is thrown!!!).
		{
			//First I only had the "tmpStr=br_theInputWeGetFromBrowser.readLine();" line here, and it worked OK. But after a while I saw I sometimes got problems: "tmpStr=br_theInputWeGetFromBrowser.readLine();" did never quit, the Thread had stopped here. I don't know for sure, but the reason might be that the browser never sends a "\n" or "\r" at the end of the line, so it never becomes a "line" (is the definition of a line "whatsoever\n"??; I don't know...). However, now we instead read "i_valueOfHttpContentLength" from the stream after we have read one empty line (==""). This seems to work without any problems.	//(BTW: the problem occured after I had implemented the "401 Not Authorized"-support (so the browser sends a "AUTHORIZATION=Basic enctyptedPass" line now). Is it possible this has anything to do with that the browser doesn't send an \n after the POST-data? (Did the browser send a \n after the POST-data before this?) I don't know... :/ )
			if (!tmpStr.equals(""))		//This is NOT the empty line before the POST-line
				tmpStr=theInput.readLine();
			else if (i_valueOfHttpContentLength!=0)	//This is the empty line before the POST-line (there are no other empty lines)
			{
				if (i_valueOfHttpContentLength>500)	//We are actually not using POST during the setup-connection, but we have implemented this anyway, in case we want to use it later.
					i_valueOfHttpContentLength=500;	//Don't allow i_valueOfHttpContentLength to be greater than 500, or a "hacker" would be able to create crash Xerver by creating very large byte-arrays...

				char[] cbuf=new char[i_valueOfHttpContentLength];
				theInput.read( cbuf, 0, i_valueOfHttpContentLength);
				s_stdinDataForPOSTRequests=new String(cbuf);
				break;	//We have read everything we want to read
			}
			else	//This happenes if there is no "CONTENT_LENGTH"-line in the browser request. So this won't happen with a valid browser...
				break;	//We have read everything we want to read

			if (tmpStr!=null)
			{
				if (tmpStr.indexOf(":")!=-1)	//If this really is a line such as "HTTP_Connection: Keep-Alive". Otherwise we have come to the empty line before the POST-line.
				{
					//"tmpStr" is using this format: "CONTENT_LENGTH=65" (after the line below has been run)
					tmpStr=tmpStr.substring(0,tmpStr.indexOf(":")).toUpperCase().replace('-','_')+"="+tmpStr.substring(tmpStr.indexOf(": ")+2);
					allENVVariablesTMP[numberOfENVGivenByBrowser++]="HTTP_"+tmpStr;

					if (tmpStr.startsWith("CONTENT_LENGTH"))
					{
						allENVVariablesTMP[numberOfENVGivenByBrowser++]=tmpStr;
						i_valueOfHttpContentLength=Integer.parseInt(tmpStr.substring(tmpStr.indexOf("=")+1));	//Save how long the POST-line shall be
					}
					else if (tmpStr.startsWith("CONTENT_TYPE"))
					{
						allENVVariablesTMP[numberOfENVGivenByBrowser++]=tmpStr;
					}
					else if (tmpStr.startsWith("AUTHORIZATION"))
					{
						s_encryptedPasswordGiven=tmpStr.substring(tmpStr.indexOf("=Basic ")+("=Basic ".length()));	//Format: "encryptedPassword" (actually, it is "user:pass" encrypted)
					}
//					else if (tmpStr.startsWith("COOKIE="))
//						s_cookiesFromBrowser=tmpStr.substring("COOKIE=".length());	//We don't need this
				}
				else if (s_requestMethod.equals("POST") && !tmpStr.equals(""))	//If, and only if, a POST-reques has been made, then there is more information that shall be read... (if tmpStr is a empty string we are at the empty line before the POST-data line)
				{
					s_stdinDataForPOSTRequests=tmpStr.substring(0,i_valueOfHttpContentLength);	//Guaranty that "s_stdinDataForPOSTRequests" doesn't contain more than "i_valueOfHttpContentLength" bytes

					break;	//With a correct request, this is not necessey, as the POST-lien data is the last one
				}
			}
		}

		allENVVariables=new String[numberOfENVGivenByBrowser];
		for (int i=0; i<numberOfENVGivenByBrowser; i++)
			allENVVariables[i]=allENVVariablesTMP[i];


//for (int i=0; i<numberOfENVGivenByBrowser; i++)
//	System.out.println("data  "+allENVVariables[i]);


//From Opera:
//GET /?y4errewfdpp HTTP/1.1
//User-Agent: Mozilla/4.0 (compatible; MSIE 5.0; Windows XP) Opera 6.0  [sv]
//Host: localhost:12345
//Accept: text/html, image/png, image/jpeg, image/gif, image/x-xbitmap, */*
//Accept-Language: sv
//Accept-Charset: windows-1252;q=1.0, utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1
//Accept-Encoding: deflate, gzip, x-gzip, identity, *;q=0
//Cache-Control: no-cache
//Connection: Keep-Alive, TE
//TE: deflate, gzip, chunked, identity, trailers

} 	catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getEnvironmentVariablesGivenByBrowser:\n"+e.getMessage());}
	return allENVVariables;
	}
}








