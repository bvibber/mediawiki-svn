//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class is equivalent to <CODE>ExtractZipFiles</CODE>, but it does never replace the "Xerver2.cfg" while unzipping a zip file (if "Xerver2.cfg" already exists, it won't be owerwritten).
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class ExtractZipFileInstall extends ExtractZipFile
{
	public ExtractZipFileInstall(String s, boolean argOverwriteFiles)
	{
		super(s,argOverwriteFiles);
	}

	public ExtractZipFileInstall(File zipFile, boolean argOverwriteFiles)
	{
		super(zipFile,argOverwriteFiles);
	}

	public ExtractZipFileInstall(String s, boolean argOverwriteFiles, String s_defaultPath)
	{
		super(s,argOverwriteFiles,s_defaultPath);
	}

	public ExtractZipFileInstall(File zipFile, boolean argOverwriteFiles, String s_defaultPath)
	{
		super(zipFile,argOverwriteFiles,s_defaultPath);
	}

	boolean overWriteFile(ZipEntry myZipEntry)
	{
		if (myZipEntry.getName().toLowerCase().endsWith("xerver2.cfg"))
			return false;	//Never replace "xerver2.cfg" if "xerver2.cfg" exists...

		return b_overwriteFiles;
	}
}