//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;




/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class contains only static methods used to validate the data sent to Xerver via the web based setup.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */




final public class ValidateInput
{
	/**
	* Returns true iff username is not null, not empty and only contains a-z, 0-9 and underscore (_).
	*/
	public static boolean isValidUserName(String username)
	{
		if (username==null)
			return false;

		if (username.equals(""))
			return false;

		byte [] buffer=username.getBytes();
		for (int i=0; i<buffer.length; i++)
		{
			char ch=(char)buffer[i];
			if (!Character.isLetterOrDigit(ch) && ch!='_')
			{
				return false;
			}
		}
		return true;
	}

	/**
	* Returns true iff alias is not null, not empty and only contains a-z, 0-9 and underscore (_).
	*/
	public static boolean isValidAliasName(String alias)
	{
		return isValidUserName(alias);
	}

	/**
	* Returns true iff path is not null.
	*/
	public static boolean isValidPath(String path)
	{
		if (path==null)
			return false;

		//NOTE: If we have this, we can't share a path that is temporary unavailable, for example an empty CD drive.
		//File file=new File(path);
		//return file.exists();
		return true;	//So far we accept all paths...
	}


	/**
	* Returns null if path is not a valid directory, otherwise returns path (with a slash in the end if necessary).
	*/
	public static String makeValidPath(String path)
	{
		if (path==null)
			return null;

		path=path.trim();

		File file=new File(path);

		if (!file.isAbsolute())	//The path is not an absolute path... (if we remove this, the user can enter "data" and we change it to "c:\path\to\Xerver\data\", but I think we better not do this as if he enter "dummyFolder" we don't the script to present "c:\path\to\Xerver\dummyFolder\" to the user, as we for now make no check whatever the folder really exists or not).
		{
			return null;
		}

		path=file.getAbsolutePath();

		if (!path.endsWith(File.separator))
		{
			path=path+File.separator;
		}

		//NOTE: If we have this, we can't share a path that is temporary unavailable, for example an empty CD drive.
		//if (file.isDirectory())
		//	return path;
		//else
		//	return null;
		return path;	//So far we make no check at all that the directory really exists.
	}
}


