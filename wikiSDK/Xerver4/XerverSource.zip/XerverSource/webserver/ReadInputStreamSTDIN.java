//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class reads the POST data and sends it as STDIN to the script.
 * <BR>
 * <BR>
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>(new ReadInputStreamSTDIN(DataInputStreamWithReadLine argDiswr, OutputStream argOs)).start();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * <CODE>argDiswr</CODE> = this is the <CODE>DataInputStreamWithReadLine</CODE> containing the data the browser has sent us and that we still have not read (=only the POST data is left in this stream)
 * <BR>
 * <CODE>argOs</CODE> = Everything written to this will be sent to the script (as STDIN).
 * <BR>
 * <BR>
 *
 * <B>IMPORTANT:</B> <CODE>argOs</CODE> is closed ("<CODE>argOs.close()</CODE>") by <CODE>ReadInputStreamSTDIN</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class ReadInputStreamSTDIN extends ReadInputStream
{
	private DataInputStreamWithReadLine diswr;
	private BufferedOutputStream bos;
	RunScript rs_theRunScript;

	/**
	* About the sleep time (TIME_TO_SLEEP):
	* We want this to be short since this is the minimum time the script has to
	* wait until it gets new data. However, if it is too short this will be like
	* a while(true){}-loop which will eat 100% CPU.
	* So we balance these two factors against each other.
	*/
	private final static int TIME_TO_SLEEP = 50;			//See comments below
	private final static int MAXIMUM_SLEEPS_IN_A_ROW = 100;	//See comments below



	public ReadInputStreamSTDIN()	//now we can Extend ReadInputStreamSTDIN without problem
	{
	}

	public ReadInputStreamSTDIN(DataInputStreamWithReadLine argDiswr, OutputStream argOs, RunScript argTheRunScript)
	{
		currentMode=INPUT_MODE;
		diswr=argDiswr;
		bos=new BufferedOutputStream(argOs);
		rs_theRunScript=argTheRunScript;
	}

	public void sendDataInputMode()
	{
			try
			{
				/**
				* About the algortihm:
				* We see if we have data to read from "diswr".
				* If we have then we read that and send to script.
				* If we don't have any data we wait for TIME_TO_SLEEP milliseconds and
				* look for new data.
				* However, if we never receive any new data (maybe all data has been sent or
				* there is a long network problem) then we only repeat the procedure
				* MAXIMUM_SLEEPS_IN_A_ROW times. After this we just close the data stream.
				*
				* However, everytime we get new data we reset the counter (i_timesWeHaveSleept) so that we after this once
				* again go one sleeping a maximum of MAXIMUM_SLEEPS_IN_A_ROW times.
				* So the total number of sleeps (Thread.sleep()) can actually be inifinty (which is what we want).
				* This would occur if we had: get data, sleep, get data, sleep etc. for ever.
				*/
				int n;
				byte [] buffer=new byte [8192];	//I think 8192 is the largest buffer one of the XXXInputStreamXXX classes uses, so *maybe* it works faster if we read 8192 bytes each time. The value 8192 is showed when you for example check the value of ".available()" and you have more than 8192 bytes in the stream. ".available()" will still return 8192. (You can, however, still read more than 8192 bytes with for example "write(buffer,0,10240)"). Also, 8192 is 10'0000'0000'0000 binary and is the value of some constants, for example: java.util.prefs.Preference.MAX_VALUE_LENGTH, which is the "Maximum length of string allowed as a value".
				int i_timesWeHaveSleept=0;
				while (i_timesWeHaveSleept<MAXIMUM_SLEEPS_IN_A_ROW)
				{
					while (diswr.available()>0 && (n=diswr.read(buffer, 0, 8192))!=-1)//(br.ready() && (n=br.read(buffer))!=-1)
					{
						bos.write(buffer,0,n);
						i_timesWeHaveSleept=0;	//Everytime we have got new data we reset the counter so that we after this once again go one waiting for a long time. Hence, as long as we once in a while get new data the time we wait (Thread.sleep()) can actually be inifinty. (hence: get data, sleep, get data, sleep etc. for ever; however, each sleep period is of course finite long)
					}

					i_timesWeHaveSleept++;
					Thread.sleep(TIME_TO_SLEEP);
				}

				bos.flush();
				bos.close();

			} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendDataInputMode:\n"+e.getMessage());}
	}



	private void exceptionOccured(Exception e)
	{
		rs_theRunScript.killProcess();
	}
}

