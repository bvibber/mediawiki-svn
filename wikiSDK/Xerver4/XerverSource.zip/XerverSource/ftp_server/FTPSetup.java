//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.net.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * Run this file when you want to start Xerver FTP setup.
 * <BR>
 * Note that you can pass arguments to this file when you run its main method.
 *
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class FTPSetup extends Thread
{
	private static final boolean b_showErrors=false;
	public final static int i_portNr=32124;
	private ServerSocket myServerSocket;
	private static boolean FTPSetupHasStarted=false;
	private boolean b_portError=false;
	private boolean b_portInUse=false;
	public static boolean b_printOutput=false;


	public static void main(String [] s)
	{
		FTPSetup setup=null;
		boolean b_startRemote=false;
		boolean b_startServer=true;
		int port=i_portNr;
		b_printOutput=true;

		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].startsWith("-p"))
				{
					try
					{
						port=Integer.parseInt(s[i].substring(2));
					}
					catch (Exception e)
					{
						b_startServer=false;
						showOutput("Invalid port.");
						showOutput("The flag given should be \"-pXX\" where XX is a port number.");
					}
				}
				else if (s[i].equals("-remote") || s[i].equals("-r"))
				{
					b_startRemote=true;
				}
				else //if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startServer=false;
					showOutput("Flags:");
					showOutput("-h or -help = Show this help text.");
					showOutput("-pXX = Start setup on port XX, not "+i_portNr+" which is default.");
					showOutput("-r or -remote = Allow all IP-addresses to change settings in setup.");
				}
			}
		}

		if (b_startServer)
		{
			setup=new FTPSetup(port);

			if (!setup.getPortError())
			{
				String s_IP=HostInfo.getOuterIPOrLocalhost();
				showOutput("FTPSetup is now running, please visit:");
				showOutput("http://"+s_IP+":"+port+"/");
			}
			else
			{
				if (setup.isPortInUse())
					showOutput("Port "+port+" is already in use.\nXerver FTP Setup is probably already running.");
				else
					showOutput("Port "+port+" is an invalid port number.\nPlease choose another port number.");
			}
		}

		if (b_startRemote && b_startServer)
		{
			//This inside the other if-statement because here we are 100% sure "setup!=null"... (unnecessary?)
			if (!setup.getPortError())
			{
				showOutput("Remote setup has been started.");
				setup.startFTPSetup();
			}
		}

		if (b_startServer)
			setup.start();
	}


	public FTPSetup()
	{
		this(i_portNr);
	}

	public FTPSetup(int port)
	{
		listenToPort(port);
	}

	private void listenToPort(int port)
	{
		try
		{
			try
			{
				myServerSocket = new ServerSocket(port);
			}
			catch (BindException be)	//port is in use
			{
				b_portError=true;
				b_portInUse=true;
			}
			catch (IllegalArgumentException iae)	//port number is invalid, for example if port=999999
			{
				b_portError=true;
			}
		}
		catch (Exception e)
		{
			showError(e);
		}
	}

	public void run()
	{
		try {
			Socket so_userConnection;
			if (!b_portInUse && !b_portError)	//If [port is not in use] and [port is valid (not like port 999999)]
			{
				while (true)	//IMPORTANT!!! make sure this loop won't go around too many times without doing anything or java will use up to 100% CPU. Instead let the loop be halted by for example an accept call which will wait for a network connection to be established...
				{
					try
					{
	//					System.out.println("V�ntar p� connection...");
						try
						{
							so_userConnection=myServerSocket.accept();	//Wait until a request is sent to the server (with "myServerSocket.setSoTimeout()" we can limit the time we wait for "accept")
							so_userConnection.setSoTimeout(5000);
						}
						catch (Exception e)	//If the port is already in use... (However, we should never be able to get in here, but just to be safe)
						{
							stopFTPSetup();
							break;
						}

						if (FTPSetupHasStarted || so_userConnection.getLocalAddress().equals(so_userConnection.getInetAddress()))
						{
							(new FTPSetupConnection(so_userConnection)).start();
						}
						else
						{
							so_userConnection.close();
						}
					}
					catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ run\n"+e);}
				}
			}
		} catch (Exception e) {showError(e);}
	}



	private void showError(Exception e)
	{
		if (b_showErrors)
		{
			System.out.println("Error: " + e);
			e.printStackTrace();
		}
	}

	private static void showOutput(String txt)
	{
		if (b_printOutput)
			System.out.println(txt);
	}


	public void startFTPSetup()
	{
		FTPSetupHasStarted=true;
	}

	public void stopFTPSetup()
	{
		FTPSetupHasStarted=false;
	}

	public static int getPort()
	{
		return i_portNr;
	}

	public boolean isPortInUse()
	{
		return b_portInUse;
	}

	public boolean getPortError()
	{
		return b_portError;
	}
}