//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This represents the settings for Xerver FTP server (read from "FTP2.cfg").
 * <BR>
 * You can't write to the settings file with this class, only read the settings.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class FTPSettings
{
	private final static String s_initFile=FTPServerController.s_initFile;

	public static int i_portNr;
	public static int i_howToShowAlias;
	public static boolean b_guestAccountExists;
	public static int i_maxTimeToIdle;
	public static int i_maxNumberOfNOOP;
	public static int i_dataPortNr;
	public static int [] ai_portRange = null;
	public static String s_localIP = null;
	public static String s_outerIP = null;
	public static String s_logFile = null;


	public FTPSettings() throws Exception
	{
		updateData();
	}

	public void updateData() throws Exception
	{
		BufferedReader br_userFile = new BufferedReader(new FileReader(s_initFile));

		String tmpLine;
		while ((tmpLine=br_userFile.readLine())!=null)
		{
			tmpLine=tmpLine.trim();
			if (tmpLine.length()>0)
			{
				if (tmpLine.charAt(0)!=';')
				{
					String varName, varValue;
					int indexOfValue=tmpLine.indexOf("=");
					varName=tmpLine.substring(0,indexOfValue);
					varValue=tmpLine.substring(indexOfValue+1);
					varName=varName.trim();
					varValue=varValue.trim();

					setValue(varName,varValue);
				}
			}
		}

		br_userFile.close();
	}

	private void setValue(String varName, String varValue)
	{
//		System.out.println(varName+"  "+varValue);
		if (varName.equalsIgnoreCase("PORT_NR"))
			i_portNr=Integer.parseInt(varValue);
		else if (varName.equalsIgnoreCase("SHOW_ALIAS"))
			i_howToShowAlias=Integer.parseInt(varValue);
		else if (varName.equalsIgnoreCase("LOG_FILE"))
			s_logFile=varValue;
		else if (varName.equalsIgnoreCase("MAX_IDLE_TIME"))
			i_maxTimeToIdle=1000*Integer.parseInt(varValue);
		else if (varName.equalsIgnoreCase("MAX_NOOP_ALLOWED"))
			i_maxNumberOfNOOP=Integer.parseInt(varValue);
		else if (varName.equalsIgnoreCase("DATA_PORT_NR"))
			i_dataPortNr=Integer.parseInt(varValue);
		else if (varName.equalsIgnoreCase("LOCAL_IP"))
			s_localIP=varValue;
		else if (varName.equalsIgnoreCase("OUTER_IP"))
			s_outerIP=varValue;
		else if (varName.equalsIgnoreCase("PASSIVE_PORT_RANGE"))
		{
			int i_firstComma = varValue.indexOf(",");
			if (i_firstComma != -1)
			{
			    ai_portRange = new int[2];
			    ai_portRange[0] = Integer.parseInt(varValue.substring(0,i_firstComma));
			    ai_portRange[1] = Integer.parseInt(varValue.substring(i_firstComma+1));
			}
		}
		else if (varName.equalsIgnoreCase("GUEST_ACCOUNT"))
		{
			int i_guestAccountExists=Integer.parseInt(varValue);
			if (i_guestAccountExists==0)
				b_guestAccountExists=false;
			else
				b_guestAccountExists=true;
		}
	}
}