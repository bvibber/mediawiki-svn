//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package webserver;
import common.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>MyFile</CODE> is like <CODE>File</CODE> but has an modified toString() method and a boolean which
 * decides if a file shall be represented as ".." when toString() is called.
 * <BR>
 * With a normal <CODE>File</CODE> you will get "getPath()" when you call "toString()".
 * With this class you will get ".." if b_isUpOneDir==true (if isUpOneDir() has been called).
 * Otherwise you will get getName().
 * However, if "getName()" returns "", then "getPath()" is returned
 * (This happenes as far as I know only when <CODE>MyFile</CODE> represents a root, such as c:\, d:\ or / ).
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */
final public class MyFile extends File
{
/**
 * toString() will return ".." iff b_isUpOneDir==true (if isUpOneDir() has been called).
 */
	private boolean b_isUpOneDir=false;

	MyFile(File parent, String child)
	{
		super(parent, child);
	}
	MyFile(String pathname)
	{
		super(pathname);
	}
	MyFile(String parent, String child)
	{
		super(parent, child);
	}
	MyFile(File f)
	{
		this(f.getPath());
	}


/**
 * If isUpOneDir() is called toString() will always return "..".
 */
	public void isUpOneDir()
	{
		b_isUpOneDir=true;
	}

/**
 * Set the b_isUpOneDir variable with this method.
 * setIsUpOneDir(true) is equivalent to isUpOneDir().
 */
	public void setIsUpOneDir(boolean isUpOneDir)
	{
		b_isUpOneDir=isUpOneDir;
	}


/**
 * With a normal <CODE>File</CODE> you will get "<CODE>getPath()</CODE>" when you call "toString()".
 * With this class you will get ".." if b_isUpOneDir==true (if <CODE>isUpOneDir()</CODE> has been called).
 * Otherwise you will get <CODE>getName()</CODE>.
 * However, if "<CODE>getName()</CODE>" returns "", then "<CODE>getPath()</CODE>" is returned
 * (This happenes as far as I know only when <CODE>MyFile</CODE> represents a root, such as c:\, d:\ or / ).
 */
	public String toString()
	{
		if (b_isUpOneDir)
			return "..";
		else
			if (!getName().equals(""))
				return getName();
			else
				return getPath();	//If it's a root such as "c:\" or "/".
	}
}

