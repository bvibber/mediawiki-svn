// stdafx.cpp : source file that includes just the standard includes
//	StartXerver.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include <malloc.h>



// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

/**
* This function will add " -Denvvar=blabla" to the end of buffer
* if environment variable exists (otherwise nothing is added).
* Remember to write "envvar" with small letters
* (due to that I use small letters in Java code ("System.getProperty("systemroot")")).
*/
void addEnvVarToBuffer(LPTSTR buffer, LPTSTR varName)
{
	DWORD BUFSIZE = 2000;
	DWORD dwRet, dwErr;
	LPTSTR pszEnvVarValue;

	pszEnvVarValue = (LPTSTR) malloc(BUFSIZE*sizeof(TCHAR));
	if(NULL == pszEnvVarValue)	//Out of memory
	{
		//printf("Out of memory\n");
		//return FALSE;
	}

	dwRet = GetEnvironmentVariable(TEXT(varName), pszEnvVarValue, BUFSIZE);


	if(0 == dwRet)	//Error occured
	{
		dwErr = GetLastError();
		if( ERROR_ENVVAR_NOT_FOUND == dwErr )	//Variable does not exists
		{
			//printf("Environment variable varname does not exist.\n");
			//fExist=FALSE;
		}
	}
	else if(BUFSIZE < dwRet)	//Our buffer was too small, it should have been "dwRet" big
	{
		pszEnvVarValue = (LPTSTR) realloc( pszEnvVarValue, dwRet*sizeof(TCHAR) );	
		if(NULL == pszEnvVarValue)	//Not enough memory
		{
			//printf("Out of memory\n");
			//return FALSE;
		}
		dwRet = GetEnvironmentVariable(TEXT(varName), pszEnvVarValue, dwRet);
		if(!dwRet)	//Could not get env variable...
		{
			//printf("GetEnvironmentVariabled failed (%d)\n", GetLastError());
			//return FALSE;
		}
		//else fExist=TRUE;
	}
	//else fExist=TRUE;


	strcat_s(buffer,BUFSIZE," -D");
	strcat_s(buffer,BUFSIZE,TEXT(varName));
	strcat_s(buffer,BUFSIZE,"=");
	strcat_s(buffer,BUFSIZE,pszEnvVarValue);
}