//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package common;
import ftp_server.*;
import webserver.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * The difference between <CODE>DataInputStreamWithReadLine</CODE> and <CODE>DataInputStream</CODE> is that <CODE>DataInputStreamWithReadLine</CODE>
 * has a method called "<CODE>String myReadLine(int maxLineSize)</CODE>".
 *
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class DataInputStreamWithReadLine extends DataInputStream
{
	private final int i_bufferLength=128;	//Note: as myReadLine is recrusive, you can make this value as big/small as you want (performance might however be better/worse with other values). The value of this DOES NOT set the maximum length of the line read!!! Arbitrary long lines can be read anyway!
	private char c_lastLineBreakRead=' ';	//Enter anything but '\r' and '\n' here and it will work fine!!

	public DataInputStreamWithReadLine(InputStream in)	//now we can Extend ReadInputStreamSTDIN without problem
	{
		super(in);
	}


    /**
     * Reads a line of bytes from the stream.
     * <BR>
     * The String returned does not contain \r or \n.
     * <BR>
     * If a \r or \n is found as the very first byte in the stream it will be removed from the stream. If there are additional \r or \n in the stream these might, or might not, be removed!!
     * <BR>
     * However, this method does guaranty that when you call it for the first time, it will ignore the 3 first \r and \n in the very beginning of the stream (if there are 3 (or less) \r or \n, that is) and then read one line and then return it. For each and every time you call this method later (without reading from the stream with another method) it will successfully read one line and return it.
     * <BR>
     * You have to guaranty that the lines are using one of these formats (example with 6 lines, including one empty line):
     * <BR>
     * "line1\nline2\nline3\n\nline5\nline6"
     * <BR>
     * "line1\rline2\rline3\r\rline5\rline6"
     * <BR>
     * "line1\r\nline2\r\nline3\r\n\r\nline5\r\nline6"
     * <P>
     * Other formats might, or might not, work with this method.
     * <BR>
     * <BR>
     * This method does not use the reset() or mark() methods.
     * @param i_maxSizeToRead the maximum length of a line. If there is no \n or \r within the first i_maxSizeToRead bytes, the bytes read are converted into a String which is returned (with length i_maxSizeToRead)
     */
	//i_maxSizeToRead = the maximum length of a line. If there is no \n or \r within the first i_maxSizeToRead bytes, the bytes read are converted into a String which is returned (with length i_maxSizeToRead)
	public String myReadLine(int i_maxSizeToRead)	//IMPORTANT: as the line is buffered before it is returned i_maxSizeToRead is used so no one shall be able to send a very long line without any \r or \n to eat all memory. THIS IS A IMPORTANT SECURITY ISSUE!!!
	{
		return myReadLineWithInitialNewLineCharacters(i_maxSizeToRead, true);
	}

	/**
	 * <CODE>String myReadLine(int i_maxSizeToRead)</CODE> actually calls this method
	 * with <CODE>myReadLineWithInitialNewLineCharacters(i_maxSizeToRead, true)</CODE>.
	 *
     * <BR>
     * <BR>
     * This method does not use the reset() or mark() methods.
     * @param i_maxSizeToRead the maximum length of a line. If there is no \n or \r within the first i_maxSizeToRead bytes, the bytes read are converted into a String which is returned (with length i_maxSizeToRead)
     * @param b_ignoreInitialNewLineCharacters If this is true then we will ignore the initial new line characters ("\n" and "\r")
     */
	private String myReadLineWithInitialNewLineCharacters(int i_maxSizeToRead, boolean b_ignoreInitialNewLineCharacters)	//IMPORTANT: as the line is buffered before it is returned i_maxSizeToRead is used so no one shall be able to send a very long line without any \r or \n to eat all memory. THIS IS A IMPORTANT SECURITY ISSUE!!!
	{

		byte [] buffer=new byte [i_bufferLength];
		byte b;
		char c;
		int i=0;
		int n=0;	//Number of buffered bytes

		try {
		int i_numberOfLineBreakRead=0;
		boolean b_isFirstLoop=true;
		for (; i<i_bufferLength && i_maxSizeToRead>0; i++)
		{
			b=readByte();
			c=(char)b;
			if (c=='\n' || c=='\r')
			{
				//If [we are not ignoring the first \r or \n] and [we are at the first character of the stream]...
				if (!b_ignoreInitialNewLineCharacters && b_isFirstLoop)
				{
					//Then break here and return "".
					//This is necessary for this reason: if we have a buffer length of 3 and a stream such as "abc\ndef" then we don't want the readLine to return the string "abcdef", but only "abc". To avoid this bug we have this check.
					return "";
				}

				i_numberOfLineBreakRead++;
				//IF [this is NOT the very first line read (reason: DO NOT return "" BEFORE line2: "line1\r\nline2\r\n\r\nline3\r\n")]
				//OR [we have read 3 line breaks (in normal case: this will be "\n\r\n") (reason: return "" after line2: "line1\r\nline2\r\n\r\nline3\r\n")]
				//OR [the first charcter we find now is the same as the last line break character read last time this method was called (reason: return "" after line2: "line1\nline2\n\nline3\n")]

				if (!b_isFirstLoop || i_numberOfLineBreakRead==3 || (c_lastLineBreakRead==c && i_numberOfLineBreakRead==1))	//If [the first byte was a \r or \n] OR [we have read the \r or \n after our line (or, it's a real empty line, such as "\n\n" in this example: "line1\nline2\n\nline3\nline4\n". Note that the example line given, or the one below, both will work well with this "read-line-algorithm": "line1\r\nline2\r\nline3\r\n\r\nline4\r\nLine5")]
				{
					c_lastLineBreakRead=c;
					if (n>0)
						return new String(buffer,0,n);
					else
						return "";
				}
			}
			else
			{
				i_maxSizeToRead--;
				buffer[n++]=b;
				b_isFirstLoop=false;
			}
		}
		}catch(Exception e){}

		c_lastLineBreakRead=' ';	//We have gone out of the loop the "normal way" (we did not run "return XXX" in the loop.)

		//IMPORTANT: If we get an Exception above, it's possible to come here with the values n=0 and i_maxSizeToRead="the value given as the argument". If we then recursively call this function again with the same value to i_maxSizeToRead and the error is a kind of error that does always come (for me it was EOFException) we will loop recursively forever without changing the value of n and i_maxSizeToRead!!! AVOID THIS! We avoid this by returing "" if n=0 (which will make this function to work good and as Expected).
		if (n==0)
			return "";
		else if (i==i_bufferLength)	//If [\r or \n has not been found within the first "i_bufferLength" bytes]...
			return new String(buffer,0,n)+myReadLineWithInitialNewLineCharacters(i_maxSizeToRead, false);	//We have false so that we shall not ignore the initial \r or \n in the remaining of the input stream. (if our for example is 3 characters long and the stream contains "abc\ndef", then this prevents the \n to be ignored (and hence the entire string abcdef is read as one single line))
		else
			return new String(buffer,0,n);
	}
}

