//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import webserver.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * A very useful class if you want an application with a settings file
 * which can easily be edited, both by a human and by this class.
 * <BR>
 * This class can both write to and read from the database (the file).
 * <BR>
 * This class can also make basic file operations such as
 * deleting, copying and renameing the file.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class DatabaseFile
{
	private File f_file;
	private String s_filePath;
    /**
     * Lines starting with this character are comments.
     */
	private char commentChar=';';
    /**
     * This is the separator between a name and its value.
     * <BR>
     * Example: Name=John Smith
     */
	private char assignChar='=';


	public DatabaseFile(String argFile) throws Exception
	{
		this(new File(argFile));
	}

	public DatabaseFile(File argFile) throws Exception
	{
//		if (argFile.exists())
//		{
			f_file=argFile;
			s_filePath=f_file.getPath();
//		}
//		else
//		{
//			new Exception("File does not exists when creating a new DatabaseFile!");
//		}
	}

    /**
     * Sets <CODE>assignChar</CODE> (see <CODE>assignChar</CODE> documentation).
     */
	synchronized public void setAssignChar(char argAssign)
	{
		assignChar=argAssign;
	}

    /**
     * Sets <CODE>commentChar</CODE> (see <CODE>commentChar</CODE> documentation).
     */
	synchronized public void setCommentChar(char argComment)
	{
		commentChar=argComment;
	}

    /**
     * Removes a value from the database.
     */
	synchronized public boolean removeValue(String name) throws Exception
	{
		return updateValue(name, null);
	}



	/**
	* Updates the value of this variable.
	* <BR>
	* IMPORTANT: If "<CODE>value</CODE>" is <CODE>null</CODE>, then it means that we shall REMOVE "<CODE>name</CODE>" from the file!
	* @return Returns true iff "name" exists in file and the value has been replaced with "value".
	* Returns false iff "name" does not exists in file.
	*/
	synchronized public boolean updateValue(String name, String value) throws Exception
	{
		boolean retValue=false;
		File f_tmpFile=File.createTempFile("Xerver",".tmp");

		BufferedReader br_userFile = new BufferedReader(new FileReader(f_file));
		PrintWriter bw_newFile = new PrintWriter(new BufferedWriter(new FileWriter(f_tmpFile)));

		String lineNotModified, tmpLine;
		while ((lineNotModified=tmpLine=br_userFile.readLine())!=null)
		{
			tmpLine=tmpLine.trim();
			if (tmpLine.length()>0)
			{
				if (tmpLine.charAt(0)!=commentChar)
				{
					String varName, varValue;
					int indexOfValue=tmpLine.indexOf(assignChar);
					varName=tmpLine.substring(0,indexOfValue);
					varValue=tmpLine.substring(indexOfValue+1);
					varName=varName.trim();
					varValue=varValue.trim();

					if (name.equalsIgnoreCase(varName))
					{
						retValue=true;
						if (value!=null)	//If we have a value for "name", we shall UPDATE name (otherwise remove name)
							bw_newFile.println(varName+" "+assignChar+" "+value);
						//else	//Otherwise we don't do anything here, resulting that we REMOVE "name" from the file!

						continue;	//Don't write "lineNotModified" to file
					}
				}
			}

			bw_newFile.println(lineNotModified);
		}

		//Close everything so file won't be locked by JVM to long
		br_userFile.close();
		bw_newFile.flush();
		bw_newFile.close();
		bw_newFile=null;
		br_userFile=null;

		if (f_file.delete())
		{
			if (!f_tmpFile.renameTo(f_file))	//On Solaris File.renameTo() cannot move a file from one file system to another...
			{
				FileWithCopy.copyFile(f_tmpFile, f_file);
			}
		}
		f_file=new File(s_filePath); //Renew "f_file" for next run...
		return retValue;
	}

	/**
	* Add a new empty line to the file.
	*/
	synchronized public void addNewLine() throws Exception
	{
		PrintWriter bw_newFile = new PrintWriter(new BufferedWriter(new FileWriter(f_file.getAbsolutePath(), true)));	//Append data...	Note: we need ".getAbsolutePath()") becuase "FileWriter(File,boolean)" only exists on Java 1.4 and above. (Without this, users with older Java versions would get an error during runtime).
		bw_newFile.println();
		bw_newFile.close();
		bw_newFile=null;
	}

	/**
	* This adds a new <CODE>name</CODE>/<CODE>value</CODE> couple at the end of the file.
	*
	* <B>IMPORTANT:</B> If "name" already exists, a new name will be added anyway, resulting in having two (or more) "variables" with possibly different values!!!
	* <BR>
	* This member shall be used with CARE!!
	* <BR>
	* Also, if you use this member, make sure the file's last line ends with a newline-character!!
	* <BR>
	* Use setValue or updateValue instead to avoid these problems.
	* (or just call addNewLine() once before you call this method the very first time and you will be safe).
	*/
	synchronized public void addNewValue(String name, String value) throws Exception
	{
		PrintWriter bw_newFile = new PrintWriter(new BufferedWriter(new FileWriter(f_file.getAbsolutePath(), true)));	//Append data...	Note: we need ".getAbsolutePath()") becuase "FileWriter(File,boolean)" only exists on Java 1.4 and above. (Without this, users with older Java versions would get an error during runtime).
		bw_newFile.println(name+" "+assignChar+" "+value);
		bw_newFile.close();
		bw_newFile=null;
	}


	/**
	* Add a comment to the end of this file.
	* <BR>
	* <B>IMPORTANT:</B> If you use this member, make sure the file's last line ends with a newline-character. (or just call addNewLine() once before you call this method the very first time and you will be safe).
	*/
	synchronized public void addNewComment(String comment) throws Exception
	{
		PrintWriter bw_newFile = new PrintWriter(new BufferedWriter(new FileWriter(f_file.getAbsolutePath(), true)));	//Append data...	Note: we need ".getAbsolutePath()") becuase "FileWriter(File,boolean)" only exists on Java 1.4 and above. (Without this, users with older Java versions would get an error during runtime).
		bw_newFile.println(commentChar+comment);
		bw_newFile.close();
		bw_newFile=null;
	}

	/**
	* If <CODE>name</CODE> already exists, update its value-
	* <BR>
	* If <CODE>name</CODE> doesn't exists, creates a new "variable" with this name/value.
	*/
	synchronized public void setValue(String name, String value) throws Exception
	{
		//First we try to update the value, if not possible, we add the new value
		if (!updateValue(name, value))
		{
			addNewLine();//Add a new line to avoid problems if file does not end with a newline-character in the end of the last line in the file.
			addNewValue(name, value);
		}
	}

	/**
	* Returns the value from the variable "name".
	* <BR>
	* This means searching the file for a line containing "name=value" and returning "value".
	*/
	synchronized public String getValue(String name) throws Exception
	{
		BufferedReader br_userFile = new BufferedReader(new FileReader(f_file));

		String retValue=null;
		String tmpLine;
		while ((tmpLine=br_userFile.readLine())!=null)
		{
			tmpLine=tmpLine.trim();
			if (tmpLine.length()>0)
			{
				if (tmpLine.charAt(0)!=commentChar)
				{
					String varName, varValue;
					int indexOfValue=tmpLine.indexOf(assignChar);
					varName=tmpLine.substring(0,indexOfValue);
					varValue=tmpLine.substring(indexOfValue+1);
					varName=varName.trim();
					varValue=varValue.trim();

					if (name.equalsIgnoreCase(varName))
					{
						retValue=varValue;
						break;
					}
				}
			}
		}

		br_userFile.close();
		br_userFile=null;

		return retValue;	//Value not found
	}

	/**
	* Renames the database file.
	* <BR>
	* @return Returns true iff renaming file was successful.
	*/
	synchronized public boolean renameFile(String newPath)
	{
		boolean retValue=f_file.renameTo(new File(newPath));
		if (retValue)
		{
			s_filePath=f_file.getPath();
		}
		return retValue;
	}

	/**
	* Creates a copy of this database file.
	* <BR>
	* @return Returns true iff copying file was successful.
	*/
	synchronized public boolean copyFile(String newPath)
	{
		File newFile=new File(newPath);
		if (newFile.exists())
			return false;	//We choose that this method shall not overwrite the destination file in case it already exists

		return FileWithCopy.copyFile(f_file,newFile);
	}

	/**
	* Deletes the database file.
	* <BR>
	* @return Returns true iff deleting file was successful.
	*/
	synchronized public boolean deleteFile()
	{
		return f_file.delete();
	}

	/**
	* @return Returns true iff file exists.
	*/
	synchronized public boolean fileExists()
	{
		return f_file.exists() && !f_file.isDirectory();
	}

	/**
	* Creates this database file.
	* <BR>
	* @return Returns true iff creating file was successful.
	*/
	synchronized public boolean createNewFile()
	{
		try
		{
			return f_file.createNewFile();
		}
		catch (Exception e)
		{
			return false;	//Don't throw back exception, just return false... (For example when file already exists)
		}
	}

	/**
	* Run this when you are finished with reading/writing to the database.
	* In case the JVM has locked the database file, it will be released after this.
	*/
	public void destroy()
	{
		f_file=null;
		s_filePath=null;
		System.gc();	//If this is not runned the file might be locked by JVM until the Garbage Collector (gc) is run. To make sure the file is released we must force JVM to run gc. However, it might take time to run garbage collector, so this is a priority issue.
	}
}


