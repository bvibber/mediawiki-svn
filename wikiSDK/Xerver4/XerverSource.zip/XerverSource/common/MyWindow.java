//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################

package common;
import ftp_server.*;
import webserver.*;
import java.awt.*;
import java.awt.event.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>MyString</CODE> is a very useful class.
 * <BR>
 * It's used to open a simple window allowing you to paint on it as you prefer.
 * <BR>
 * Several help members are included.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MyWindow extends Frame
{
//###########################################################################
//############################### VARIABLER #################################
//###########################################################################
	public boolean mouseButtonDown;					//Is the mouse button down?
	public boolean killProgramAtShutdown=true;	//Close window ==> Kill whole program
	public boolean windowHasBeenShutDown=false;	//Has the user closed this window?
	public boolean automaticRepaint=true;		//Call "repaint()" automatically after each painting?
	public long timeWhenWindowWasCreated;
	public Point mousePosition=new Point();		//The mouse position (x,y)
	private Image paintArea;
	private int winWidth, winHeight;
	private FontMetrics myFontMetrics;
	private Color myColor=Color.red;
	private Font myFont=new Font("Times", Font.BOLD, 12);
	private Insets theInsets;
	private Graphics graphicsArea;


//###########################################################################
//################################## MAIN ###################################
//###########################################################################
	public static void main(String [] s)
	{
		MyWindow MW=new MyWindow(400,300,"Untitled Window");
	}


//###########################################################################
//############################## KONSTRUERARE ###############################
//###########################################################################
	public MyWindow()
	{
		new MyWindow(400,300,"Untitled Window");
	}


	public MyWindow(int width, int height, String rubrik)
	{
		timeWhenWindowWasCreated=System.currentTimeMillis();
		setVisible(true);

	//	super.setFont(myFont);
		paintArea = createImage(width, height);
		graphicsArea = paintArea.getGraphics();	//run "setVisible(true);" before this line
		graphicsArea.setFont(myFont);
		graphicsArea.setColor(myColor);
		winWidth = width;
		winHeight = height;
		myFontMetrics = graphicsArea.getFontMetrics();
		addMouseListener(MyMouseListener);
		addMouseMotionListener(MyMouseMotionListener);
		addWindowListener(MyWindowListener);
		setTitle(rubrik);
		theInsets = getInsets();
		super.setSize(width+theInsets.left+theInsets.right,height+theInsets.top+theInsets.bottom);
		setBackground(Color.white);
		repaint();
	}



//###########################################################################
//###################### PUBLICA DIVERSE FUNKTIONER #########################
//###########################################################################
	public void pauseWindow(int milliSek)	//Pause this window in "milliSek" milliseconds
	{
		long tidVidStart=System.currentTimeMillis();
		while (tidVidStart+milliSek>System.currentTimeMillis());
	}

	public static long getWindowLifeTime(MyWindow theWindow)	//Number of millis since window was created
	{
		return (System.currentTimeMillis()-theWindow.timeWhenWindowWasCreated);
	}

	public void setColor(Color newColor)
	{
		if (graphicsArea != null)
			graphicsArea.setColor(newColor);
		myColor = newColor;
	}

	public void setFont(Font newFont)
	{
		if (graphicsArea != null)
			graphicsArea.setFont(newFont);
	}

	public void setBackground(Color newBackgroundColor)
	{
		super.setBackground(newBackgroundColor);
		if (graphicsArea!=null)
		{
			graphicsArea.setColor(newBackgroundColor);
			graphicsArea.fillRect(0,0,winWidth,winHeight);
			graphicsArea.setColor(myColor);
		}
		if (automaticRepaint) repaint();
	}

	public boolean buttonDown()
	{
		return mouseButtonDown;
	}

	public Point getMouse()
	{
		return mousePosition;
	}

	public String toString()
	{
		return getTitle();
	}

//###########################################################################
//########################## PUBLIC DRAW MEMTHODS ###########################
//###########################################################################

	public void clearRect(int x, int y, int width, int height)
	{
		graphicsArea.clearRect(x,y,width,height);
		if (automaticRepaint) repaint();
	}
	public void draw3DRect(int x,int y, int width,int height, boolean raised)
	{
		graphicsArea.draw3DRect(x,y,width,height,raised);
		if (automaticRepaint) repaint();
	}
	public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle)
	{
		graphicsArea.drawArc(x,y,width,height,startAngle,arcAngle);
		if (automaticRepaint) repaint();
	}
	public void drawLine(int x0,int y0, int x1,int y1)
	{
		graphicsArea.drawLine(x0,y0,x1,y1);
		if (automaticRepaint) repaint();
	}
	public void drawOval(int x, int y, int width, int height)
	{
		graphicsArea.drawOval(x,y,width,height);
		if (automaticRepaint) repaint();
	}
	public void drawPolygon(int[] xPoints, int[] yPoints,int nPoints)
	{
		graphicsArea.drawPolygon(xPoints,yPoints,nPoints);
		if (automaticRepaint) repaint();
	}
	public void drawPolygon(Polygon p)
	{
		graphicsArea.drawPolygon(p);
		if (automaticRepaint) repaint();
	}
	public void drawPolyline(int[] xPoints, int[] yPoints,int nPoints)
	{
		graphicsArea.drawPolyline(xPoints,yPoints,nPoints);
		if (automaticRepaint) repaint();
	}
	public void drawRect(int x, int y, int width, int height)
	{
		graphicsArea.drawRect(x, y, width, height);
		if (automaticRepaint) repaint();
	}
	public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight)
	{
		graphicsArea.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
		if (automaticRepaint) repaint();
	}
	public void drawString(String str, int x, int y)
	{
		graphicsArea.drawString(str, x, y);
		if (automaticRepaint) repaint();
	}
	public void fill3DRect(int x,int y, int width,int height, boolean raised)
	{
		graphicsArea.fill3DRect(x,y,width,height,raised);
		if (automaticRepaint) repaint();
	}
	public void fillArc(int x, int y, int width, int height,int startAngle, int arcAngle)
	{
		graphicsArea.fillArc(x,y,width,height,startAngle,arcAngle);
		if (automaticRepaint) repaint();
	}
	public void fillOval(int x, int y, int width, int height)
	{
		graphicsArea.fillOval(x, y, width, height);
		if (automaticRepaint) repaint();
	}
	public void fillPolygon(int[] xPoints, int[] yPoints,int nPoints)
	{
		graphicsArea.fillPolygon(xPoints, yPoints, nPoints);
		if (automaticRepaint) repaint();
	}
	public void fillPolygon(Polygon p)
	{
		graphicsArea.fillPolygon(p);
		if (automaticRepaint) repaint();
	}
	public void fillRect(int x, int y, int width, int height)
	{
		graphicsArea.fillRect(x, y, width, height);
		if (automaticRepaint) repaint();
	}
	public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight)
	{
		graphicsArea.fillRoundRect(x, y, width, height, arcWidth, arcHeight);
		if (automaticRepaint) repaint();
	}


//###########################################################################
//########################## "SYSTEM FUNCTIONS" #############################
//###########################################################################
	public void paint(Graphics g)
	{
		if (paintArea!=null)	//Without these error might occur
			if (theInsets!=null)
				g.drawImage(paintArea,theInsets.left,theInsets.top,this);
	}


//###########################################################################
//################################ EVENTS //#################################
//###########################################################################
	private WindowAdapter MyWindowListener = new WindowAdapter()
	{
		public void windowClosing(WindowEvent e)	//Window is closed
		{
			windowHasBeenShutDown=true;
			dispose();
			if (killProgramAtShutdown)
				System.exit(0);
		}
	};

	private MouseListener MyMouseListener = new MouseAdapter()
	{
		public void mousePressed(MouseEvent e)	//Mouse is pressed down
		{
			mouseButtonDown = true;
			mousePosition=e.getPoint();
			mousePosition.y-=theInsets.top;	//Removes the size of the blue list in windows (test with winXP gave: 21)
			mousePosition.x-=theInsets.left;	//Removes the size of the window border (test with winXP gave: 4)
		}
		public void mouseReleased(MouseEvent e)	//Mouse button is going up
		{
			mouseButtonDown = false;
		}
	};

	private MouseMotionListener MyMouseMotionListener = new MouseMotionAdapter()
	{
		public void mouseDragged(MouseEvent e)	//Mouse is keept down and is draged
		{
			mousePosition=e.getPoint();
			mousePosition.y-=theInsets.top;	//Removes the size of the blue list in windows (test with winXP gave: 21)
			mousePosition.x-=theInsets.left;	//Removes the size of the window border (test with winXP gave: 4)
		}
	};
}