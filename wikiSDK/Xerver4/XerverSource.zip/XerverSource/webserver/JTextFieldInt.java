//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * <B>About this class:</B>
 * <BR>
 * A <CODE>JTextField</CODE> that only supports integers >= 0 (the "-" might not appear in the field).
 * <BR>
 * The field can be empty.
 * <BR>
 * Nothing but numbers 0-9 can be in this field.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


public class JTextFieldInt extends JTextField implements KeyListener
{
	public JTextFieldInt()
	{
		super();
		addKeyListener(this);
	}

	public JTextFieldInt(int nrCols)
	{
		super(nrCols);
		addKeyListener(this);
	}

	public JTextFieldInt(int value, int nrCols)
	{
		super(Integer.toString(value), nrCols);
		addKeyListener(this);
	}

	public JTextFieldInt(String value, int nrCols)
	{
		super(value, nrCols);
		addKeyListener(this);
	}


  // implementation of KeyListener
  public void keyPressed(KeyEvent e)  {}
  public void keyReleased(KeyEvent e)  {}

  public void keyTyped(KeyEvent e)
  {
     char c = e.getKeyChar();

     if ( Character.isDigit(c)
          || c == KeyEvent.VK_BACK_SPACE
          || c == KeyEvent.VK_DELETE
          || c == KeyEvent.VK_ENTER
          || c == KeyEvent.VK_TAB )
      {
         // everythig is fine
      }
      else
      {
         // consume the event => NumericField will not get an invalid char
         e.consume();
      }// end if
   }

}
