//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################




package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class is not intended to be very general, instead it contains methods that are being used
 * in other classes Xerver uses. However, the class is in no way written just for Xerver,
 * but is general enough to be used in other applications as well.
 * <BR>
 * Given a path, such as "c:\blabla\bla\" you can with this constructor get information about
 * if the path is valid, get a list of all files in this directory or get a list with all folders
 * with read permission in this directory.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */
final public class PathInfo
{
	/* Note, general information: when you make a ".isDirectory()" on a drive without a disk inserted, such as A:\ without a floppy disk, ".isDirectory()" will return false! */
	private File f_currentFolder;	//This is NOT null iff "s_path" given to the constructor is a valid AND readable directory (A: without a floppy disk is for example under no circumstances readable). Otherwise this is null.
	private File [] af_allFiles;		//This contains all roots unless a valid AND readable directory is given as "s_path". Otherwise this contains all directories in "s_path".
	private boolean directoryIsValid;	//This is true iff "s_path" is [a valid AND readable directory] OR [null] OR [""].
	private String s_path;

	/**
	* Creates a <CODE>PathInfo</CODE> with the path given as <CODE>argPath</CODE> (equivalent to <CODE>s_path</CODE>).
	* If <CODE>argPath</CODE> is null a <CODE>PathInfo</CODE> with all roots are created.
	*/
	public PathInfo(String argPath)
	{
		s_path=argPath;
		directoryIsValid=true;	//By default it's correct...  //directoryIsValid is false "for example" (actually I _think_ it should be "iff") when s_path is [s_path is an invalid path, but not null or ""] OR [when the path is unreadable, such as when you have no floppy disk in drive A:]
		if (s_path==null)		//start with root
		{
			f_currentFolder=null;
			af_allFiles=File.listRoots();
		}
		else
		{
			if (s_path.equals(""))
			{
				f_currentFolder=null;
				af_allFiles=File.listRoots();
			}
			else
			{
				f_currentFolder=new File(s_path);
				if (f_currentFolder.isDirectory() && f_currentFolder.canRead())
					af_allFiles=f_currentFolder.listFiles();
				else	//Invalid path-name
				{
					directoryIsValid=false;	//s_path is an invalid path, but not null or "". Or the drive might just be unreadable, such as A: without a floppy disk.
					f_currentFolder=null;
					af_allFiles=File.listRoots();
				}
			}
		}
	}


	/**
	* This returns all directories (which you have read permission to) in <CODE>s_path</CODE>.
	* If <CODE>s_path</CODE> is not null (not listing roots),
	* then this also returns one "Up One Level" directory, which can be uesful when listing directories.
	*/
	public MyFile [] getAllDirsWithReadAccess()
	{
		Vector vec=new Vector();
		for (int i=0 , allFilesLength=af_allFiles.length; i<allFilesLength; i++)
		{
			File tmpFile=af_allFiles[i];
			if (tmpFile.isDirectory() && tmpFile.canRead())
			{
				vec.addElement(new MyFile(tmpFile));
			}
		}

		MyFile [] returnArray;
		if (f_currentFolder!=null) //readable and valid path
		{
			if (f_currentFolder.getParentFile()!=null)//If you can go up one level
				returnArray=new MyFile [vec.size()+1];
			else
				returnArray=new MyFile [vec.size()];
		}
		else //invalid or unreadable path/drive
			returnArray=new MyFile [vec.size()];

		int vecSize=vec.size();
		for (int i=0; i<vecSize; i++)
		{
			returnArray[i]=(MyFile)vec.remove(0);
		}
		if (f_currentFolder!=null) //readable and valid path
		{
			File tmpParentFile=f_currentFolder.getParentFile();	//Optimization...
			if (tmpParentFile!=null)//If you can go up one level
			{
				int index=returnArray.length-1;	//Optimization...
				returnArray[index]=new MyFile(tmpParentFile);
				returnArray[index].isUpOneDir();
			}
		}

		Arrays.sort(returnArray);
		return returnArray;
	}


	/**
	* Returns "new File(s_path)".
	* Does NOT return null iff "s_path" given to the constructor is a valid AND readable directory
	* (A: without a floppy disk is for example under no circumstances readable).
	* Otherwise this returns null.
	*/
	public File getCurrentFolder()
	{
		return f_currentFolder;
	}

	/**
	* Returns <CODE>af_allFiles</CODE>
	* (af_allFiles contains all roots unless a valid AND readable directory is given as "s_path".
	* Otherwise af_allFiles contains all directories in "s_path".).
	*/
	public File [] getAllFiles()
	{
		return af_allFiles;
	}

	/**
	* Returns <CODE>af_allFiles[index]</CODE> (af_allFiles contains all roots unless a valid AND readable directory is given as "s_path". Otherwise af_allFiles contains all directories in "s_path".).
	*/
	public File getAllFiles(int index)
	{
		return af_allFiles[index];
	}

	/**
	* Returns true iff "<CODE>s_path</CODE>" is [a valid AND readable directory] OR [null] OR [""].
	*/
	public boolean getDirectoryIsValid()
	{
		return directoryIsValid;
	}

	/**
	* Returns <CODE>s_path</CODE>, which is equivalent to <CODE>argPath</CODE> given to the constructor.
	*/
	public String toString()
	{
		return s_path;
	}
}