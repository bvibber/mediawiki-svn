//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;

/**
 *
 * <B>About this class:</B>
 * <BR>
 * Run this file when you want to start Xerver FTP server.
 * <BR>
 * Note that you can pass arguments to this file when you run its main method.
 *
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class FTPServer extends Thread
{
	private static final boolean b_showErrors=false;
	private static FTPSettings FTPS_settings=null;
	private static FTPServer FTPS_server=null;
	private ServerSocket myServerSocket;
	public static boolean isAlive=false;
	private int i_portNr;
	private boolean b_portError=false;
	private boolean b_portInUse=false;
	private static boolean b_printOutput=false;


	public static void main(String [] s)
	{
		FTPServer server=null;
		boolean b_startRemote=false;
		boolean b_startServer=true;
		int port=-1;
		b_printOutput=true;

		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].startsWith("-p"))
				{
					try
					{
						port=Integer.parseInt(s[i].substring(2));
						if (port<=0)
							throw new Exception("Please use a positive integer when you set port.");
					}
					catch (Exception e)
					{
						b_startServer=false;
						showOutput("Invalid port.");
						showOutput("The flag given should be \"-pXX\" where XX is a port number.");
					}
				}
				else// if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startServer=false;
					showOutput("Flags:");
					showOutput("-c or -commands = Print all requests and responses to output.");
					showOutput("-pXX = Start FTP server on port XX.");
				}
			}
		}

		if (b_startServer)
		{
			server=new FTPServer(port);
			server.startFTPServer();
			if (!server.getPortError())
			{
				String s_IP=HostInfo.getOuterIPOrLocalhost();
				showOutput("FTPServer is now running.");
				showOutput("Host: "+s_IP);
				showOutput("Port: "+server.i_portNr);

				server.start();
			}
			else
			{
				if (server.b_portInUse)
					showOutput("Port "+server.i_portNr+" is already in use.\nPlease use setup to choose another port.");
				else
					showOutput("Port "+server.i_portNr+" is an invalid port number.\nPlease use setup to choose another port number.");
			}
		}

	}

	public FTPServer()
	{
			this(-1);
	}

	public FTPServer(int i_argPort)
	{
		try
		{
			FTPS_server=this;
			FTPS_settings=getFTPSettings();

			initSettings();


			if (i_argPort!=-1)	//If we have started with "-pXX" then use this port
				i_portNr=i_argPort;

			FTPNewConnection.s_serverOuterIP=HostInfo.getIP().replace('.',',');
			FTPNewConnection.s_serverLocalIP=HostInfo.getLocalIP().replace('.',',');

			listenForConnections();
		}
		catch (Exception e)
		{
			showError(e);
		}
	}


	public void listenForConnections()
	{
		b_portError=false;
		b_portInUse=false;
		try
		{
			try
			{
				if (myServerSocket != null)
				{
					if (myServerSocket.getLocalPort() != i_portNr)	//The user has changed what port we shall use, so create a new ServerSocket
					{
						myServerSocket.close();		//Stop listen to the old port. Closing the old ServerSocket will result in that the old thread will die (due to the exception that is thrown in ".run()"), so we need to run ".start()" (".run()") again so that we again start listen to the new port
						myServerSocket = new ServerSocket(i_portNr);
					}
				}
				else
				{
					myServerSocket = new ServerSocket(i_portNr);	//This is the first time we create a ServerSocket at startup
				}
			}
			catch (BindException be)	//port is in use
			{
				b_portError=true;
				b_portInUse=true;
			}
			catch (IllegalArgumentException iae)	//port number is invalid, for example if port=999999
			{
				b_portError=true;
			}
		}
		catch (Exception e)
		{
			showError(e);
		}
	}



	public void initSettings()
	{
		FTPNewConnection.b_guestAccountExists = FTPS_settings.b_guestAccountExists;
		FTPNewConnection.i_howToShowAlias = FTPS_settings.i_howToShowAlias;
		FTPNewConnection.i_maxTimeToIdle = FTPS_settings.i_maxTimeToIdle;
		FTPNewConnection.i_maxNumberOfNOOP = FTPS_settings.i_maxNumberOfNOOP;
		FTPNewConnection.l_logFile = new Log(FTPS_settings.s_logFile);
		FTPDataConnection.i_dataPortNr = FTPS_settings.i_dataPortNr;
		FTPDataConnection.ai_portRange = FTPS_settings.ai_portRange;
		HostInfo.setLocalIP(FTPS_settings.s_localIP);
		HostInfo.setOuterIP(FTPS_settings.s_outerIP);


		i_portNr=FTPS_settings.i_portNr;	//This is here so that if we change port in setup we will start use the new port immediately, no matter if we have used "-pXX" as a flag.
	}

	public void run()
	{
		Socket so_userConnection;
		if (!b_portInUse && !b_portError)	//If [port is not in use] and [port is valid (not like port 999999)]
		{
			while (true)	//IMPORTANT!!! make sure this loop won't go around too many times without doing anything or java will use up to 100% CPU. Instead let the loop be halted by for example an accept call which will wait for a network connection to be established...
			{
				try
				{
					try
					{
						so_userConnection=myServerSocket.accept();	//Wait until a request is sent to the server (with "myServerSocket.setSoTimeout()" we can limit the time we wait for "accept")
					}
					catch (Exception e)	//If the port is already in use... (However, we should never be able to get in here, but just to be safe)
					{
						//We come here for example if the port is already in use or when we for example
						//have changed settings and want the server to listen to another port.
						Thread.sleep(100);
						continue;
					}

					if (so_userConnection!=null)
					{
						if (isAlive)	//Server is indeed running
						{
							so_userConnection.setSoTimeout(FTPNewConnection.i_maxTimeToIdle+1);	// "+1" to make sure that MAX_IDLE_TIME seconds really has passed... (this might make that we disconnect the user after approximately MAX_IDLE_TIME+1 seconds, but that's better than disconnecting the user after approximately MAX_IDLE_TIME*2 seconds.
							(new FTPNewConnection(so_userConnection)).start();
						}
						else	//We have stopped the server, so don't accept the connection
						{
							so_userConnection.close();
						}
					}
				} catch (Exception e) {showError(e);}
			}
		}
	}


	private void showError(Exception e)
	{
		if (b_showErrors)
		{
			System.out.println("Error: " + e);
			e.printStackTrace();
		}
	}


	private static void showOutput(String txt)
	{
		if (b_printOutput)
			System.out.println(txt);
	}


	public void startFTPServer()
	{
		isAlive=true;
	}

	public void stopFTPServer()
	{
		isAlive=false;
	}

	public int getPort()
	{
		return i_portNr;
	}

	public boolean isPortInUse()
	{
		return b_portInUse;
	}

	public boolean getPortError()
	{
		return b_portError;
	}

	public static FTPSettings getFTPSettings() throws Exception
	{
		if (FTPS_settings==null)
			FTPS_settings=new FTPSettings();
		return FTPS_settings;
	}

	public static FTPServer getFTPServer()
	{
		return FTPS_server;
	}
}


