//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is the graphical layout of Xerver.
 * However, to start an advanced graphical layout requires system resources.
 * That's why you actually don't need this if you want to run the pure Xerver web server.
 * If you want to run the pure web server, use setup and choose to run Xerver with now window and then start Start.class.
 * <BR>
 * Start Xerver in one of these ways:
 * <BR>
 * <CODE>(new Thread(new XerverKernel(true,null))).start();	//no window</CODE>
 * <BR>
 * <CODE>(new Thread(new XerverKernel(false,null))).start();	//awt-window</CODE>
 * <BR>
 * <CODE>new ProgramWindow();	//swing-window</CODE>
 * <BR>
 * <BR>
 * One of the lines above are executed when you run "Start.class".
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */



final public class ProgramWindow extends JFrame implements ActionListener
{
	public final static int STARTUP_MODE=0;
	public final static int STATS_MODE=1;
	public final static int SETUP_MODE=2;
	public final static int SETUPSAVED_MODE=3;
	public final static int UPDATE_MODE=4;
	public final static int SETUPTURNEDON_MODE=5;
	public final static int SETUPTURNEDOFF_MODE=6;
	public final static int HELP_MODE=7;
	public final static int ABOUT_MODE=8;
	public final static Font defaultFont=GUIMethods.defaultFont;
	public final static JLabel EMPTY_JLABEL=new JLabel(" ");	//Optimization...
	private final static Font f_defaultStatusFont=new Font("arial", Font.ITALIC, 11);
	public final static JButton aboutOuterIPButton=new JButton("?");;	//So that actionPerformed can recognize this button
	public final static JButton aboutLocalIPButton=new JButton("?");;	//So that actionPerformed can recognize this button
	private final static JButton turnOffButton=new JButton(new ImageIcon("data"+File.separator+"imagestopbutton.gif"));;	//So that actionPerformed can recognize this button
	private final static JButton turnOnButton=new JButton(new ImageIcon("data"+File.separator+"imagestartbutton.gif"));;	//So that actionPerformed can recognize this button
	private final static JButton turnOnSetupButton=new JButton(new ImageIcon("data"+File.separator+"imagestartsetupbutton.gif"));	//So that actionPerformed can recognize this button
	private final static JButton turnOffSetupButton=new JButton(new ImageIcon("data"+File.separator+"imagestopsetupbutton.gif"));	//So that actionPerformed can recognize this button
	private final static String turnOnFTPText="Start FTP Server";
	private final static String turnOffFTPText="Stop FTP Server";
	private final static String turnOnFTPSetupText="Start FTP Remote Setup";
	private       static String turnOffFTPSetupText="Stop FTP Local Setup";
	private final static JMenuItem turnOnFTPRadio=new JMenuItem(turnOnFTPText);
	private final static JMenuItem turnOffFTPRadio=new JMenuItem(turnOffFTPText);
	private final static JMenuItem turnOnFTPRemoteSetupRadio=new JMenuItem(turnOnFTPSetupText);
	private       static JMenuItem turnOnFTPLocalSetupRadio=new JMenuItem(turnOffFTPSetupText);
//	private final static JButton turnOffFTPSetupRadio=new JButton("Stop FTP Setup",true);


	private Container CP;			//The whole layout (including the menu)
	private Container CPlarge;		//Everything except the menu
	private Container CPintoCPlarge;	//Everything except the menu and the bottom Container (statusbar, buttons etc.)
	private Container bottomCP;		//Buttons and statusbar
	private JMenuBar theMenu;
	private MenuOptions myOptions;
	private final static String statusBarText="Welcome to Xerver [Xerver is not running. To start Xerver, press the \"Start Xerver\" button]";
	private int currentMode=STARTUP_MODE;
	private JLabel JL_statusBar;


	public static void main(String [] s)
	{
		new ProgramWindow();
	}

	public ProgramWindow(boolean gotoMinimizedMode)	//By default gotoMinimizedMode is false, that is we don't start with a minimized mode
	{
		myOptions=new MenuOptions(this);
		CP=getContentPane();

		initComponents();
		setIsRunningButton();
		setSetupIsRunningButton();

		addWindowListener(MyWindowListener);
		CPintoCPlarge=GUIMethods.showAsNorthBorderLayout(giveStartupContainer());
		showAsMainFrame(CPintoCPlarge);

		try {
		if (XerverKernel.getThisVersion() < MenuOptions.getLatestVersion())	//If a new version is available...
			showAsMainFrame(myOptions.checkForUpdates());	//Let the user know...
		} catch (Exception e){/* No internetconnection might be the reason. */};

		setTitle("Xerver");
		setSize(530,440);
		setIconImage((new ImageIcon("data"+File.separator+"imagexervericon.gif")).getImage());

		if (gotoMinimizedMode)
		{
			goToMinimizedMode();	//Minimize...
			myOptions.runXerver();	//Start Xerver automatically...
		}
		else
		{
			setVisible(true);
			toFront();
		}
	}

	public void initComponents()
	{
		//These lines at the very top, as the methods that are called later on requires these to have been set
		//turnOffButton=new JButton(new ImageIcon("data"+File.separator+"imagestopbutton.gif"));
		aboutOuterIPButton.addActionListener(this);
		aboutLocalIPButton.addActionListener(this);
		turnOffButton.addActionListener(this);
//		turnOffButton.setBackground(Color.white);
		turnOffButton.setOpaque(true);
		turnOnButton.addActionListener(this);
//		turnOnButton.setBackground(Color.white);
		turnOnButton.setOpaque(true);
		turnOffSetupButton.addActionListener(this);
//		turnOffSetupButton.setBackground(Color.white);
		turnOffSetupButton.setOpaque(true);
		turnOnSetupButton.addActionListener(this);
// 		turnOnSetupButton.setBackground(Color.white);
		turnOnSetupButton.setOpaque(true);


		turnOffFTPRadio.setEnabled(false);
		turnOnFTPLocalSetupRadio.setEnabled(false);

		theMenu=giveTheMenu();

		JL_statusBar=new JLabel(statusBarText);
		JL_statusBar.setFont(f_defaultStatusFont);
		JL_statusBar.setForeground(Color.black);

		bottomCP=new Container();
		bottomCP.setLayout(new BorderLayout());
		bottomCP.add(JL_statusBar,BorderLayout.SOUTH);

		CPlarge=new Container();
		CPlarge.setLayout(new BorderLayout());
		CPlarge.add(bottomCP,BorderLayout.SOUTH);

		CP.add(theMenu,BorderLayout.NORTH);
		CP.add(CPlarge,BorderLayout.CENTER);
	}



	public ProgramWindow()
	{
		this(false);//By default don't use minimized mode
	}

	private Container giveStartupContainer()
	{
		Container Cont=new Container();
		Cont.setLayout(new BorderLayout());
		Cont.add(new JLabel(new ImageIcon("data"+File.separator+"imagelogo.gif")),BorderLayout.NORTH);

		JTextField addressInfo;
		JTextField addressInfo2;
		JLabel txtAboveIP;
		JLabel txtAboveIP2;


		Container theFields=new Container();
		theFields.setLayout(new BoxLayout(theFields, BoxLayout.Y_AXIS));


		txtAboveIP=new JLabel("Your server's outer IP is:");
		String s_outerIP = HostInfo.getOuterIP();	//Returns null if not detected
		if (s_outerIP != null)
		{
			if (myOptions.i_portNr==80)
				addressInfo=new JTextField("http://"+s_outerIP+"/",17);
			else
				addressInfo=new JTextField("http://"+s_outerIP+":"+myOptions.i_portNr+"/",17);
		}
		else
		{
				addressInfo=new JTextField("IP could not be detected!",17);
		}

		txtAboveIP2=new JLabel("Your server's local IP is:  ");

		if (myOptions.i_portNr==80)
			addressInfo2=new JTextField("http://"+HostInfo.getLocalIP()+"/",17);
		else
			addressInfo2=new JTextField("http://"+HostInfo.getLocalIP()+":"+myOptions.i_portNr+"/",17);

		addressInfo.setEditable(false);
		addressInfo.setFont(defaultFont);
		addressInfo.setForeground(Color.black);
		addressInfo.setBackground(Color.white);
		txtAboveIP.setFont(defaultFont);
		txtAboveIP.setForeground(Color.black);

		addressInfo2.setEditable(false);
		addressInfo2.setFont(defaultFont);
		addressInfo2.setForeground(Color.black);
		addressInfo2.setBackground(Color.white);
		txtAboveIP2.setFont(defaultFont);
		txtAboveIP2.setForeground(Color.black);

		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP,MenuOptions.make2ContainersTo1ContainerBeside(addressInfo,aboutOuterIPButton)),EMPTY_JLABEL));
		theFields.add(new JLabel(" "));
		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP2,MenuOptions.make2ContainersTo1ContainerBeside(addressInfo2,aboutLocalIPButton)),EMPTY_JLABEL));

		Cont.add(MenuOptions.make2ContainersTo1ContainerAbove(MenuOptions.make2ContainersTo1ContainerBeside(theFields,EMPTY_JLABEL),EMPTY_JLABEL),BorderLayout.CENTER);
		//Cont.add(MenuOptions.make2ContainersTo1ContainerAbove(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP,addressInfo),EMPTY_JLABEL),EMPTY_JLABEL),BorderLayout.CENTER);
		//Cont.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP2,addressInfo2),EMPTY_JLABEL),BorderLayout.SOUTH);
		return Cont;
	}


	private void goToMinimizedMode()
	{
		new MinimizedMode(this);
		setVisible(false);
		/*
			JDialog JD=new JDialog(this,"Minimized");
			Container newCP=getContentPane();
			newCP
			JD.setContentPane(getContentPane());
			JD.setSize(getSize());
			JD.setTitle(getTitle());
			dispose();
			JD.setVisible(true);
			//setState(Frame.ICONIFIED);
		*/
	}

	private JMenuBar giveTheMenu()
	{
		//###################################################################
		//############################ MENUBAR ##############################
		//###################################################################
		JMenuBar theMenuBar=new JMenuBar();
		JMenu [] a_menuNr=new JMenu[4];
		JMenuItem [] a_optionNr1=new JMenuItem[2];
		JMenuItem [] a_optionNr2=new JMenuItem[2];
		JMenuItem [] a_optionNr3=new JMenuItem[4];
		JMenuItem [] a_optionNr4=new JMenuItem[3];

		a_menuNr[0]=new JMenu("File");
		a_menuNr[0].setFont(defaultFont);
		a_menuNr[0].setMnemonic('f');
		a_optionNr1[0]=new JMenuItem("Minimize",'M');
		a_optionNr1[0].setFont(defaultFont);
		a_optionNr1[0].addActionListener(this);
		//a_optionNr1[0].setMnemonic('M');
		a_optionNr1[1]=new JMenuItem("Exit",'x');
		a_optionNr1[1].setFont(defaultFont);
		a_optionNr1[1].addActionListener(this);

		a_menuNr[1]=new JMenu("View");
		a_menuNr[1].setFont(defaultFont);
		a_menuNr[1].setMnemonic('V');
		a_optionNr2[0]=new JMenuItem("Statistic",'S');
		a_optionNr2[0].setFont(defaultFont);
		a_optionNr2[0].addActionListener(this);
		a_optionNr2[1]=new JMenuItem("Settings",'t');
		a_optionNr2[1].setFont(defaultFont);
		a_optionNr2[1].addActionListener(this);

		a_menuNr[2]=new JMenu("FTP");
		a_menuNr[2].setFont(defaultFont);
		a_menuNr[2].setMnemonic('T');
		a_optionNr3[0]=turnOnFTPRadio;
		a_optionNr3[0].setFont(defaultFont);
		a_optionNr3[0].addActionListener(this);
		a_optionNr3[1]=turnOffFTPRadio;
		a_optionNr3[1].setFont(defaultFont);
		a_optionNr3[1].addActionListener(this);
		a_optionNr3[2]=turnOnFTPLocalSetupRadio;
		a_optionNr3[2].setFont(defaultFont);
		a_optionNr3[2].addActionListener(this);
		a_optionNr3[3]=turnOnFTPRemoteSetupRadio;
		a_optionNr3[3].setFont(defaultFont);
		a_optionNr3[3].addActionListener(this);
//		a_optionNr3[4]=turnOffFTPSetupRadio;
//		a_optionNr3[4].setFont(defaultFont);
//		a_optionNr3[4].addActionListener(this);


		a_menuNr[3]=new JMenu("Help");
		a_menuNr[3].setFont(defaultFont);
		a_menuNr[3].setMnemonic('H');
		a_optionNr4[0]=new JMenuItem("About",'A');
		a_optionNr4[0].setFont(defaultFont);
		a_optionNr4[0].addActionListener(this);
		a_optionNr4[1]=new JMenuItem("Check for Updates",'U');
		a_optionNr4[1].setFont(defaultFont);
		a_optionNr4[1].addActionListener(this);
		a_optionNr4[2]=new JMenuItem("Help",'H');
		a_optionNr4[2].setFont(defaultFont);
		a_optionNr4[2].addActionListener(this);

		theMenuBar.add(a_menuNr[0]);
						a_menuNr[0].add(a_optionNr1[0]);
						a_menuNr[0].addSeparator();
						a_menuNr[0].add(a_optionNr1[1]);
		theMenuBar.add(a_menuNr[1]);
						a_menuNr[1].add(a_optionNr2[0]);
						a_menuNr[1].add(a_optionNr2[1]);
		theMenuBar.add(a_menuNr[2]);
						a_menuNr[2].add(a_optionNr3[0]);
						a_menuNr[2].add(a_optionNr3[1]);
						a_menuNr[2].addSeparator();
						a_menuNr[2].add(a_optionNr3[2]);
						a_menuNr[2].add(a_optionNr3[3]);
//						a_menuNr[2].add(a_optionNr3[4]);
		theMenuBar.add(a_menuNr[3]);
						a_menuNr[3].add(a_optionNr4[0]);
						a_menuNr[3].add(a_optionNr4[1]);
						a_menuNr[3].add(a_optionNr4[2]);
		return theMenuBar;
	}

	public void updateContainers()	//For example, if you want change text in the statusbar
	{
			showAsMainFrame(CPintoCPlarge);
	}

	public void actionPerformed( ActionEvent event )
	{
		//The four first if's are for the buttons, to turn on/off xerver/xerver setup.
		if(event.getSource() == aboutOuterIPButton)
		{
			JOptionPane.showMessageDialog(this, "This IP shall be used by other Internet users.\n\nIf you are directly connected to Internet then this is most likely your computer's IP, but it could also be the IP of your ISP's gateway.\nIf it is your computers IP you are done and people should be able to use this IP to access Xerver unless you have a firewall preventing people to access Xerver.\n\nIf your computer is connected to a router, this is most likely the IP of your router.\nIf you have a router and want to use a webserver you must make sure to configure the router so it redirects incoming connections to this server.\nHow this is done depends on what router you have, but most routers have an option called 'Port Forwarding', 'Virtual Servers' or something similar.\nYou must use this option to forward the desired port (for example 80) on the router to a port\non your server computer (this can be the same or an other port number, for example 80 or 5080).\nYour visitors would then use this IP to 'visit' your router, which in turn forwards the connection to this computer (to Xerver).\n\nRemember that a computer network can have many different settings.\nWe have only discussed the most common ones here.\n\nFor more complex networks or for more general help, please visit Xerver Online Help or take a look at the local\nXerver help that is located in the 'Help'-directory in the directory where Xerver is installed.");
		}
		else if(event.getSource() == aboutLocalIPButton)
		{
			JOptionPane.showMessageDialog(this, "This IP shall be used by yourself or other computers in your LAN.\nThis IP can't be used by other Internet users to reach your website.");
		}
		else if(event.getSource() == turnOnButton)
		{
			myOptions.runXerver();
			setIsRunningButton();
		}
		else if(event.getSource() == turnOffButton)
		{
			myOptions.stopXerver();
			setIsRunningButton();
		}
		else if(event.getSource() == turnOnSetupButton)
		{
			myOptions.runXerverSetup();
			showAsMainFrame(GUIMethods.showAsNorthBorderLayout(myOptions.showTurnOnSetup()));
			setSetupIsRunningButton();
		}
		else if(event.getSource() == turnOffSetupButton)
		{
			myOptions.stopXerverSetup();
			showAsMainFrame(GUIMethods.showAsNorthBorderLayout(myOptions.showTurnOffSetup()));
			setSetupIsRunningButton();
		}
		else
		{
			if(event.getActionCommand().equals("Check for Updates"))
			{
				showAsMainFrame(myOptions.checkForUpdates());
			}
			else if(event.getActionCommand().equals("Minimize"))
			{
				goToMinimizedMode();
			}
			else if(event.getActionCommand().equals(turnOnFTPText))
			{
//				turnOnFTPRadio.setSelected(true);
//				turnOffFTPRadio.setSelected(false);
				turnOnFTPRadio.setEnabled(false);
				turnOffFTPRadio.setEnabled(true);
				FTPServerController.startFTPServer();
				if (FTPServerController.isPortInUseServer())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SERVER_PORT_IN_USE)));
				}
				else if (FTPServerController.getPortErrorServer())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SERVER_PORT_ERROR)));
				}
				else
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.START_FTP)));
				}
			}
			else if(event.getActionCommand().equals(turnOffFTPText))
			{
//				turnOnFTPRadio.setSelected(false);
//				turnOffFTPRadio.setSelected(true);
				turnOnFTPRadio.setEnabled(true);
				turnOffFTPRadio.setEnabled(false);
				FTPServerController.stopFTPServer();
				showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.STOP_FTP)));
			}
			else if(event.getActionCommand().equals(turnOnFTPSetupText))
			{
				turnOffFTPSetupText="Stop FTP Remote Setup";
				turnOnFTPLocalSetupRadio.setText(turnOffFTPSetupText);

//				turnOnFTPRemoteSetupRadio.setSelected(true);
//				turnOnFTPLocalSetupRadio.setSelected(false);
				//turnOnFTPLocalSetupRadio.setText("Stop FTP Remote Setup");
				turnOnFTPRemoteSetupRadio.setEnabled(false);
				turnOnFTPLocalSetupRadio.setEnabled(true);
				FTPServerController.startFTPRemoteSetup();
				if (FTPServerController.isPortInUseSetup())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SETUP_PORT_IN_USE)));
				}
				else if (FTPServerController.getPortErrorSetup())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SETUP_PORT_ERROR)));
				}
				else
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.START_FTP_SETUP)));
				}
			}
			else if(event.getActionCommand().equals(turnOffFTPSetupText))
			{
//				turnOnFTPRemoteSetupRadio.setSelected(false);
//				turnOnFTPLocalSetupRadio.setSelected(true);
				turnOnFTPRemoteSetupRadio.setEnabled(true);
				turnOnFTPLocalSetupRadio.setEnabled(false);
				FTPServerController.startFTPLocalSetup();
				if (FTPServerController.isPortInUseSetup())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SETUP_PORT_IN_USE)));
				}
				else if (FTPServerController.getPortErrorSetup())
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.SETUP_PORT_ERROR)));
				}
				else
				{
					showAsMainFrame(GUIMethods.showAsNorthBorderLayout(FTPMessages.getContainer(FTPMessages.STOP_FTP_SETUP)));
				}
			}
/*			else if(event.getActionCommand().equals("Stop FTP Setup"))
			{
				turnOnFTPRemoteSetupRadio.setSelected(false);
				turnOnFTPLocalSetupRadio.setSelected(false);
				turnOffFTPSetupRadio.setSelected(true);
				FTPServerController.stopFTPSetup();
			}
*/
			else if(event.getActionCommand().equals("Statistic"))
			{
				showAsMainFrame(myOptions.showStats());
			}
			else if(event.getActionCommand().equals("Help"))
			{
				showAsMainFrame(GUIMethods.showAsNorthBorderLayout(myOptions.showHelp()));
			}
			else if(event.getActionCommand().equals("About"))
			{
				showAsMainFrame(GUIMethods.showAsNorthBorderLayout(myOptions.showAbout()));
			}
			else if(event.getActionCommand().equals("Settings"))
			{
				showAsMainFrame(GUIMethods.showAsNorthBorderLayout(myOptions.showXerverSetupInfo()));
			}
			else if(event.getActionCommand().equals("Exit"))
				exitXerver();

			setSetupIsRunningButton();
		}

		bottomCP.repaint();	//Makes sure that the Turn Off Remote Setup button disappears when we choose something in the menu
	}


	public void setCurrentMode(int n)
	{
		currentMode=n;
	}

	public int getCurrentMode()
	{
		return currentMode;
	}

	public void updateStatsContainer()
	{
		CP.validate();
	}

	public void showAsMainFrame(Container nyCP)
	{
		CPlarge.remove(CPintoCPlarge);
		CPintoCPlarge=nyCP;
		CPlarge.add(CPintoCPlarge,BorderLayout.CENTER);
		CPlarge.validate();
	}


	public void setStatusText(String txt)
	{
		JL_statusBar.setText(txt);
//		CP.validate();
//		updateStatusText();
	}

	//Public because "MinimizedMode" shall be able to call "setIsRunningButton()".
	public void setIsRunningButton()
	{
		if (myOptions.xerverIsRunning)
		{
			bottomCP.remove(turnOnButton);
			bottomCP.add(turnOffButton,BorderLayout.WEST);
			turnOffButton.repaint();
		}
		else
		{
			bottomCP.remove(turnOffButton);
			bottomCP.add(turnOnButton,BorderLayout.WEST);
			turnOnButton.repaint();
		}
		bottomCP.validate();
	}

	private void setSetupIsRunningButton()
	{
		//Add the button if we are supposed to show a button...
		if (currentMode==SETUP_MODE || currentMode==SETUPTURNEDOFF_MODE || currentMode==SETUPTURNEDON_MODE || myOptions.xerverSetupIsRunning)	//If [we are in setup mode] or [the setup is running], then...
		{
			if (myOptions.xerverSetupIsRunning)
			{
				bottomCP.remove(turnOnSetupButton);
				bottomCP.add(turnOffSetupButton,BorderLayout.EAST);
				turnOffSetupButton.repaint();
			}
			else
			{
				bottomCP.remove(turnOffSetupButton);
				bottomCP.add(turnOnSetupButton,BorderLayout.EAST);
				turnOnSetupButton.repaint();
			}
 		}
		else
		{
			bottomCP.remove(turnOnSetupButton);
			bottomCP.remove(turnOffSetupButton);
			bottomCP.add(EMPTY_JLABEL,BorderLayout.EAST);
			turnOnSetupButton.repaint();
			turnOffSetupButton.repaint();
		}

		bottomCP.validate();
	}

	private void exitXerver()
	{
		if (JOptionPane.YES_OPTION==JOptionPane.showConfirmDialog(null, "Really exit Xerver?", "Exit Xerver", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE))
			System.exit(0);
	}

	private WindowAdapter MyWindowListener = new WindowAdapter()
	{
		public void windowClosing(WindowEvent e)	//Window is closeing
		{
			System.exit(0);
		}
	};
}


















