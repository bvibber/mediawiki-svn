//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat



/**
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>(new RunScript(String command, OutputStream argFos, String [] environmentVariablesString, DataInputStreamWithReadLine DISWR_POSTData, String s_scriptLocation, NewConnection NC_theNewConnection)).start();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * This class gets a command and runs it. STDOUT and STDERR from the script is sent to an <CODE>argFos</CODE>.
 * <BR>
 * <BR>
 *
 * <CODE>command</CODE> = a command (IMPORTANT: a command in java is NOT a command you give in the prompt, but it's a runnable program. For example: [Wrong: "script.pl"; Correct: "perl script.pl"] (it doesn't matter that you in a prompt only have to write "script.pl"))
 * <BR>
 * <CODE>argFos</CODE> = the output will be written to this
 * <BR>
 * <CODE>environmentVariablesString</CODE> = an array of <CODE>String</CODE>s: "envVar=envValue"
 * <BR>
 * <CODE>DISWR_POSTData</CODE> = this will be sent to standard input (if this is <CODE>==null</CODE>, nothing will be sent to STDIN).
 * <BR>
 * <CODE>argScriptLocation</CODE> = Location of script as browser path ("http://server.com/dir1/dir2/file.pl" ==> "/dir1/dir2/")
 * <BR>
 * <CODE>NC_theNewConnection</CODE> = this shall be the <CODE>NewConnection</CODE> that belongs to the specific request that started RunScript. We need this to change the value off <CODE>s_errorStatus</CODE> to "500 Internal Server Error" and to run <CODE>addThisHitToLog()</CODE>.

 * <BR>
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class RunScript extends Thread
{
	private final static boolean b_showErrors=false;
	private BufferedInputStream bis;	//Get data from script from this (STDOUT)
	private BufferedInputStream bes;	//Get errors from script from this (STDERR)
	private BufferedOutputStream bos;	//Send data to script with this (for example when POST-data has been sent)
	MyInteger whoShallRespond=new MyInteger(ReadInputStream.RESPOND_UNDEFINED);
	private int i_timeToKillScript = 60*60*1000;	//One hour before we kill process



	private Process proc;
	//private static int i_numberRunScriptsRunning=0;
	//private static int i_numberRunScriptsNotFinalized=0;


	public RunScript(String command, OutputStream argFos, String [] environmentVariablesString, DataInputStreamWithReadLine DISWR_POSTData, String s_scriptLocation, String s_documentToReturn, NewConnection NC_theNewConnection)
	{
		//i_numberRunScriptsRunning++;
		//i_numberRunScriptsNotFinalized++;

		try {
			Runtime run;
			DataOutputStream fos;	//FileOutputStream
			run = Runtime.getRuntime();
			proc = run.exec(command, environmentVariablesString, new File(s_documentToReturn).getParentFile());	//Make sure the script is running with PWD to the correct directory
			fos=new DataOutputStream(argFos);

			bis=new BufferedInputStream(proc.getInputStream());
			bes=new BufferedInputStream(proc.getErrorStream());
			bos=new BufferedOutputStream(proc.getOutputStream());

			ReadInputStreamSTDERR stdErrThread;
			(stdErrThread=new ReadInputStreamSTDERR(bes, fos, s_scriptLocation, NC_theNewConnection, whoShallRespond, this)).start();	//Don't write Location and Content-Type
			(new ReadInputStreamSTDOUT(bis, fos, s_scriptLocation, NC_theNewConnection, stdErrThread, whoShallRespond, this)).start();	//Don't write Location and Content-Type

			if (DISWR_POSTData!=null)
			{
				(new ReadInputStreamSTDIN(DISWR_POSTData, bos, this)).start();
			}

			RunKiller rk_killer = new RunKiller(proc, fos, i_timeToKillScript);
			rk_killer.start();	//Kill process after 5*60 seconds

			proc.waitFor();


		} catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ RunScript:\n"+e.getMessage());}

		//i_numberRunScriptsRunning--;

		//System.out.println("RunScript running: "+i_numberRunScriptsRunning);
		//System.out.println("RunScript running (finalized): "+i_numberRunScriptsNotFinalized);
	}


	public void killProcess()
	{
		if (proc!=null)
		{
			proc.destroy();
			proc=null;
		}
	}





	//Testing...
	protected void finalize() throws Throwable
	{
		//i_numberRunScriptsNotFinalized--;

		if (bos!=null)
		{
			bos.flush();
			bos.close();
			bos=null;
		}
		if (bes!=null)
		{
			bes.close();
			bes=null;
		}
		if (bis!=null)
		{
			bis.close();
			bis=null;
		}
		if (proc!=null)
		{
			proc.destroy();
			proc=null;
		}
	}
}
