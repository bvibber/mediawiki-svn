//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import ftp_server.*;
import webserver.*;
import java.awt.*;
import javax.swing.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class contains only static methods that can be useful when creating a Java application using Swing. The methods are not very advanced but might still be useful.
 * <BR>
 * One way of using this class is to extend it to some class of yours.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */



public class GUIMethods
{
	public static final Font defaultFont=new Font("Arial", Font.PLAIN, 12);


	/**
	* Gets two <CODE>Container</CODE>s and puts them side by side.
	* <BR>
	* The lefy <CODE>Container</CODE> (<CODE>c1</CODE>) will be as small as possible.
	*/
	public static Container make2ContainersTo1ContainerBeside(Container c1, Container c2)
	{
		Container thisCP=new Container();
		thisCP.setLayout(new BorderLayout());
		thisCP.add(c1, BorderLayout.WEST);
		thisCP.add(c2, BorderLayout.CENTER);
		return thisCP;
	}


	/**
	* Gets two <CODE>Container</CODE>s and puts them on top of each other.
	* <BR>
	* The top <CODE>Container</CODE> (<CODE>c1</CODE>) will be as small as possible.
	*/
	public static Container make2ContainersTo1ContainerAbove(Container c1, Container c2)
	{
		Container thisCP=new Container();
		thisCP.setLayout(new BorderLayout());
		thisCP.add(c1, BorderLayout.NORTH);
		thisCP.add(c2, BorderLayout.CENTER);
		return thisCP;
	}


	/**
	* Gets an array of <CODE>String</CODE>s and returns a <CODE>Container</CODE> with this text.
	* <BR>
	* Each <CODE>String</CODE> in the array will come on a separate line.
	*/
	public static Container giveContainerWithText(String [] texts)
	{
		int textsLength=texts.length;	//Optimization...
		Container CPWithFields=new Container();
		CPWithFields.setLayout(new GridLayout(textsLength,1));

		for (int i=0; i<textsLength; i++)	//Optimization...
		{
			JLabel tmpJLabel=new JLabel(texts[i]);
			tmpJLabel.setForeground(Color.black);
			tmpJLabel.setFont(defaultFont);
			CPWithFields.add(tmpJLabel);
		}

		return CPWithFields;
	}


	/**
	* Gets one <CODE>Container</CODE> (<CODE>con</CODE>) and returns a new <CODE>Container</CODE> containing only <CODE>con</CODE>,
	* but where <CODE>con</CODE> will get a height as small as possible.
	*/
	public static Container showAsNorthBorderLayout(Container con)
	{
		Container bigCP=new Container();
		bigCP.setLayout(new BorderLayout());
		bigCP.add(con, BorderLayout.NORTH);
		bigCP.add(new JLabel(""), BorderLayout.CENTER);
		return bigCP;
	}


	/**
	* Gets one <CODE>Container</CODE> (<CODE>con</CODE>) and returns a new <CODE>Container</CODE> containing only <CODE>con</CODE>,
	* but where <CODE>con</CODE> will get a width as small as possible.
	*/
	public static Container showAsWestBorderLayout(Container con)
	{
		Container bigCP=new Container();
		bigCP.setLayout(new BorderLayout());
		bigCP.add(con, BorderLayout.WEST);
		bigCP.add(new JLabel(""), BorderLayout.CENTER);
		return bigCP;
	}


	/**
	* Gets one <CODE>Container</CODE> (<CODE>con</CODE>) and returns a new <CODE>Container</CODE> containing only <CODE>con</CODE>,
	* but where <CODE>con</CODE> will get a width and height as small as possible.
	*/
	public static Container showAsNorthAndWestBorderLayout(Container con)
	{
		return showAsNorthBorderLayout(showAsWestBorderLayout(con));
	}
}