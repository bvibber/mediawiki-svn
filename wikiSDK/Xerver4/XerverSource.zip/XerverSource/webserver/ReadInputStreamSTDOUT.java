//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class reads the STDOUT from a script and sends it to the browser.
 * <BR>
 * <BR>
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>(new ReadInputStreamSTDOUT(InputStream argIs, OutputStream argOs, String argScriptLocation, NewConnection argTheNewConnection, ReadInputStreamSTDERR argStdErrThread)).start();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * <CODE>argIs</CODE> = STDERR from a script.
 * <BR>
 * <CODE>argOs</CODE> = Everything written to this will be sent to browser.
 * <BR>
 * <CODE>argScriptLocation</CODE> = Location of script as browser path ("http://server.com/dir1/dir2/file.pl" ==> "/dir1/dir2/")
 * <BR>
 * <CODE>argTheNewConnection</CODE> = this shall be the <CODE>NewConnection</CODE> that belongs to the specific request that started RunScript. We need this to change the value off <CODE>s_errorStatus</CODE> to "500 Internal Server Error" and to run <CODE>addThisHitToLog()</CODE>.
 * <BR>
 * <CODE>argStdErrThread</CODE> = this is the <CODE>ReadInputStreamSTDERR</CODE> thread which looks for error output in STDERR. If (and only if) there is STDERR from the script, <CODE>stdErrThread.b_hasSentData==true</CODE>. Otherwise <CODE>stdErrThread.b_hasSentData==false</CODE>. We use this information to make sure that <CODE>ReadInputStreamSTDOUT</CODE> doesn't close <CODE>argOs</CODE> while <CODE>ReadInputStreamSTDERR</CODE> is writing information to it. <CODE>ReadInputStreamSTDERR</CODE> will close <CODE>argOs</CODE> when all STDERR has been sent to browser.
 * <BR>
 * <BR>
 *
 * <B>IMPORTANT:</B> <CODE>argOs</CODE> is closed ("<CODE>argOs.close()</CODE>") by <CODE>ReadInputStreamSTDOUT</CODE> if (and only if) <CODE>ReadInputStreamSTDERR</CODE> doesn't write to <CODE>argOs</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class ReadInputStreamSTDOUT extends ReadInputStream
{
	private DataOutputStream os;
	private final DateFormat df_dateFormat=DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
	private String s_scriptLocation;
	private NewConnection NC_theNewConnection;
	private ReadInputStreamSTDERR stdErrThread;
	private MyInteger whoShallRespond;
	RunScript rs_theRunScript;

	public ReadInputStreamSTDOUT()	//now we can Extend ReadInputStream without problem
	{
	}

	public ReadInputStreamSTDOUT(InputStream argIs, OutputStream argOs, String argScriptLocation, NewConnection argTheNewConnection, ReadInputStreamSTDERR argStdErrThread, MyInteger argWhoShallRespond, RunScript argTheRunScript)
	{
		whoShallRespond=argWhoShallRespond;
		currentMode=INPUT_MODE;
		is=argIs;
		os=(DataOutputStream)argOs;
		s_scriptLocation=argScriptLocation;
		NC_theNewConnection=argTheNewConnection;
		stdErrThread=argStdErrThread;
		rs_theRunScript=argTheRunScript;
	}

	public void sendDataInputMode()
	{
			try
			{
				is=new BufferedInputStream(new DataInputStream(is));

				int n;
				boolean b_hasSentHeader=false;
				boolean b_searchForHeaders=true;
				boolean b_headersFound=false;
				byte [] buffer=new byte [8192];


			/*********** ALGORITHM TO READ STDOUT FROM A SCRIPT AND GET HEADERS IT SENDS ************
			What we are doing now is to read one large buffer (call it BUFFER)
			from the script output and then make a copy of this to a String (lets call it "STR").
			Our algoritm:
			1)	Read BUFFER. Create STR from BUFFER.
			2)	Remove all \r and \n  from the *beginning* of STR.
			3)	If no more \r's and no \n's are left in STR we are done!
				Send the BUFFER to browser and now send all other outputs from script to browser.
			4)	Create int FST, which contain the index of the first \r OR \n in STR.
				Choose \r OR \n so FST becomes as small as possible, but not -1.
			5)	Create a new string ONELINE. It contains everything from index 0 to FST in STR.
				Make STR shorter with ONELINE.length. (oldSTR=ONELINE+newSTR)
			6)	Go into the IF's and see if ONELINE starts with for example "Location:" or "content-type:".
				If it does, take actions and send BUFFER and other outputs.
				If not, go back to step 2.
			****************************************************************************************/

			//Note, when I run Perl-scripts one my Win XP all \n-outputs are converted to \r\n, which means that print "Content-type: text/html\r\n\r\n"; will be sent as "Content-type: text/html\r\r\n\r\r\n" by perl.exe. This is nothing we care about, but it might be good to know...

			String s_thisLine=null;
			boolean b_waitForData=true;	//We use this to be able to check for data in the InputStream twice. If we don't find anything the first time we check, we check another time a few milliseconds later
			while (b_waitForData)
			{
				b_waitForData=false;
				while ((n=is.read(buffer))!=-1)
				{
					b_waitForData=true;
					String s_firstPartOfData=new String(buffer,0,n);	//s_firstPartOfData might conatin data since last loop, add the new string to this.
					while (b_searchForHeaders)
					{
						while (s_firstPartOfData.startsWith("\n") || s_firstPartOfData.startsWith("\r"))
							s_firstPartOfData=s_firstPartOfData.substring(1);	//Lines staring with a \r or \n shall be removed, we don't care for \r and \n

						int   distForR=s_firstPartOfData.indexOf("\r"),
							distForN=s_firstPartOfData.indexOf("\n");
						int   minDistForNandR;

						if (distForN+distForR==-2)	//both are -1 ==> no \r or \n exists ==> we are done looking for headers...
						{
							b_searchForHeaders=false;
						}
						else	//Atleast one of distForN or distForR is != -1
						{
							//set minDistForNandR to the lowest value of distForN and distForR, but don't set it to -1
							if (distForR>distForN)
								if (distForN!=-1)
									minDistForNandR=distForN;
								else
									minDistForNandR=distForR;
							else
								if (distForR!=-1)
									minDistForNandR=distForR;
								else
									minDistForNandR=distForN;

							s_thisLine=s_firstPartOfData.substring(0,minDistForNandR);
							s_firstPartOfData=s_firstPartOfData.substring(minDistForNandR+1);
							s_thisLine=s_thisLine.toLowerCase();
							if (s_thisLine.startsWith("content-type:"))
							{
								//We don't take any special actions now, except that we stop searching for "Location:"
								b_searchForHeaders=false;
								b_headersFound = true;
							}
							else if (s_thisLine.startsWith("location:"))
							{
								//We change error code
								NC_theNewConnection.s_errorStatus="302 Found";
								b_searchForHeaders=false;
								b_headersFound = true;
							}
						}
					}

					if (!b_hasSentHeader)
					{
						b_hasSentHeader=true;
						sendHeaderInfo(b_headersFound);
					}

					if (whoShallRespond.getValue()!=RESPOND_STDERR)
					{
						NewConnection.totalNumberOfBytesDownloaded+=n;
						os.write(buffer,0,n);
					}
					else
					{
						break;	//If STDERR is being sent right now, then we stop here and don't send STDOUT
					}
					sleep(25);	//Don't remove: without this it might happen that we don't read the complete output (or any output) from the process.
				}

			yield();
			sleep(75);	//Don't remove: without this it might happen that we don't read the complete output (or any output) from the process.
			}

			yield();
			sleep(150);

				if (whoShallRespond.getValue()==RESPOND_STDOUT)	//Only add to log if we are sending STDOUT, otherwise ReadInputStreamSTDERR will add to log...
				{
					NC_theNewConnection.addThisHitToLog();	//Log this visitor
				}

				if (!stdErrThread.b_hasSentData)	//If ReadInputStreamSTDERR has found output in the STDERR, then we shall not close the stream, as ReadInputStreamSTDERR is writing to it.
				{
					yield();
					sleep(125);	//Be safe, don't close before all data has been sent

					os.flush();
 	   	 			os.close();
				}

			} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendDataInputMode:\n"+e.getMessage());}
	}

	private void sendHeaderInfo(boolean b_scriptOutputsHeaders)
	{
		try {
			if (whoShallRespond.getValue()!=RESPOND_STDERR)
			{
				whoShallRespond.setValue(RESPOND_STDOUT);	//This will make sure so no STDERR is sent to the browser (a reference of "B_hasGotAResponse" is also at ReadInputStreamSTDERR, which will "block" it from sending data now)
				os.writeBytes( ""
					+"HTTP/1.1 "+NC_theNewConnection.s_errorStatus+"\r\n"
					+"Date: "+df_dateFormat.format(new Date())+"\r\n"
					+"Server: "+XerverKernel.getXerverName()+"\r\n"
					+"Connection: close\r\n"
					//+((NC_theNewConnection.s_errorStatus.equals("302 Found"))?(""):("Location: "+s_scriptLocation+"\r\n"))	//If the script has an Location-line as output, don't send our own Location-line
					+((b_scriptOutputsHeaders) ? "" : "Content-Type: text/html\r\n\r\n")		//If script output headers it should also output the \r\n\r\n so that the browser knows where the headers end and the body starts. However, if the script does not output anything we recognized as a header we will assume it does not output any headers and we should output complete headers, incl. the \r\n\r\n.
						);
			}
		} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendHeaderInfo\n"+e);}
	}



	private void exceptionOccured(Exception e)
	{
		rs_theRunScript.killProcess();
	}
}

