//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat


/**
 *
 * <B>How to use (example):</B>
 * <BR>
 * <CODE>ShowSetupPages.showSetupWizStep5(theOutput, s_runnableExtensions);</CODE>
 * <BR>
 * <BR>
 * This class contains only static members.
 * <BR>
 * Members in this class are called from <CODE>SetupNewConnection</CODE>.
 * <BR>
 * After a HTML-setup page is read and showed a member in this class is called, which write a piece of JavaScript to the bottom of the HTML-page.
 * <BR>
 * The JavaScript shows which the current settings are (for example: when you load the setup page where you choose port number, a piece of JavaScript changes the value in the "port number"-field to the port number that is used (for example 5080)).
 * <BR>
 * This class also contains members that show the "Welcome to Xerver Setup"-page and similar pages.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */




final public class ShowSetupPages
{
	private static final boolean b_showErrors=false;


	static public void setupDone(DataOutputStream os)
	{
try {
		os.writeBytes("<HTML>");
		os.writeBytes("<HEAD>");
		os.writeBytes("<TITLE>Welcome to Xerver Setup!</TITLE>");
		os.writeBytes("</HEAD>");
		os.writeBytes("<BODY BGCOLOR=white TEXT=black>");
		os.writeBytes("<TABLE WIDTH='500' BORDER='0'>");
		os.writeBytes("<TR><TD>");
		os.writeBytes("<FONT FACE='arial,verdana' SIZE='-1'>");
		os.writeBytes("<P>");
		os.writeBytes("<CENTER>");
		os.writeBytes("<IMG SRC='?action=showLogo' BORDER=0>");
		os.writeBytes("<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0>");
		os.writeBytes("<TR><TD>");
		os.writeBytes("<B>");
		os.writeBytes("<FONT FACE='arial,verdana' SIZE='-1'>");
		os.writeBytes("The setup is now finished.<BR>");
		os.writeBytes("Please enjoy Xerver!<BR>");
		os.writeBytes("<BR>");
		os.writeBytes("Xerver is a free<BR>");
		os.writeBytes("open source software.<BR>");
		os.writeBytes("Free support is available at:<BR>");
		os.writeBytes("<A HREF=\"http://www.JavaScript.nu/xerver/\" TARGET=\"_blank\">http://www.JavaScript.nu/xerver/</A><BR>");
		os.writeBytes("<P>");
		os.writeBytes("<BR>");
		os.writeBytes("<FONT COLOR=red>If Xerver is not already running,<BR>");
		os.writeBytes("Xerver will be started now...</FONT>");
		os.writeBytes("<P>");

		if (File.separator.equals("\\"))	//Is using windows
		{
			os.writeBytes("Next time you want to start Xerver, <BR>");
			os.writeBytes("just run \"StartXerver.exe\". <BR>");
			os.writeBytes("(You can also start Xerver from a prompt with \"java Start\".)");
		}
		else
		{
			os.writeBytes("Next time you want to start Xerver, <BR>");
			os.writeBytes("just open a prompt, locate yourself in the Xerver-folder and enter \"java Start\".");
		}
		os.writeBytes("</FONT>");
		os.writeBytes("</B>");
		os.writeBytes("<BR><BR><BR><BR><BR>");
		os.writeBytes("</TD><TD>");
		os.writeBytes("<IMG SRC='?action=showBigWizard' BORDER=0>");
		os.writeBytes("</TD></TR>");
		os.writeBytes("</TABLE>");
		os.writeBytes("</CENTER>");
		os.writeBytes("</FONT>");
		os.writeBytes("</TD></TR>");
		os.writeBytes("</TABLE>");
		os.writeBytes("</BODY>");
		os.writeBytes("</HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ setupDone:\n"+e.getMessage());}
	}

	static public void showSetupWizStep1(DataOutputStream os, String portNr, String s_allowFolderListing, String s_shareHiddenFiles, String s_allowCGIScript, String s_logFile)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("document.myForm.portNr.value=\""+portNr+"\";");
		os.writeBytes("document.myForm.allowFolderListing.selectedIndex="+s_allowFolderListing+";");
		os.writeBytes("document.myForm.shareHiddenFiles.selectedIndex="+s_shareHiddenFiles+";");
		os.writeBytes("document.myForm.allowCGIScript.selectedIndex="+s_allowCGIScript+";");
		os.writeBytes("document.myForm.logFile.value=\""+makeJSFriendly(s_logFile,"\"")+"\";");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep1:\n"+e.getMessage());}
	}

	static public void showSetupWizStep2(DataOutputStream os, String s_sharedPaths)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createFolderList(\""+makeJSFriendly(s_sharedPaths,"\"")+"\");");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep2:\n"+e.getMessage());}
	}

	static public void showSetupWizStep3(DataOutputStream os, String s_sharedPaths, String s_rootPath)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		if (s_rootPath.equals(""))
			os.writeBytes("suggestRoot(\""+makeJSFriendly(s_sharedPaths,"\"")+"\");");
		else
			os.writeBytes("document.myForm.rootPath.value=\""+makeJSFriendly(s_rootPath,"\"")+"\";");
		os.writeBytes("");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep3:\n"+e.getMessage());}
	}

	static public void showSetupWizStep4(DataOutputStream os, String s_sharedPaths, String s_aliasNames)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createAliasList(\""+makeJSFriendly(s_sharedPaths,"\"")+"\",\""+makeJSFriendly(s_aliasNames,"\"")+"\");");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep4:\n"+e.getMessage());}
	}

	static public void showSetupWizStep5(DataOutputStream os, String s_runnableExtensions)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createRunnableExtList(\""+makeJSFriendly(s_runnableExtensions,"\"")+"\");");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep5:\n"+e.getMessage());}
	}

	static public void showSetupWizStep6(DataOutputStream os, String s_indexNames)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createIndexFileList(\""+makeJSFriendly(s_indexNames,"\"")+"\");");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep6:\n"+e.getMessage());}
	}

	static public void showSetupWizStep7(DataOutputStream os, String s_fileExtensions, String s_allowTheseFileExtensions)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createFileExtList(\""+makeJSFriendly(s_fileExtensions,"\"")+"\");");
		os.writeBytes("document.myForm.allowTheseFileExtensions.selectedIndex="+s_allowTheseFileExtensions+";");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep7:\n"+e.getMessage());}
	}

	static public void showSetupWizStep8(DataOutputStream os, String s_sharedPaths, String s_protectedFolders)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("createProtectedList(\""+makeJSFriendly(s_sharedPaths,"\"")+"\",\""+makeJSFriendly(s_protectedFolders,"\"")+"\");");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep8:\n"+e.getMessage());}
	}

	static public void showSetupWizStep9(DataOutputStream os, String s_startupWindowMode)
	{
try {
		os.writeBytes("<SCRIPT LANGUAGE=javascript>");
		os.writeBytes("selectCorrectRadio('"+s_startupWindowMode+"');");
		os.writeBytes("</SCRIPT>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showSetupWizStep9:\n"+e.getMessage());}
	}

	static public void show401NotAuthorizedIsNotAccepted(DataOutputStream os, String s_encryptedPasswordGiven, DateFormat df_dateFormat)
	{
try {
			os.writeBytes("HTTP/1.1 401 Not Authorized \r\nDate: "+df_dateFormat.format(new Date())+" \r\n"+
	               "WWW-Authenticate: Basic realm=\"X"+System.currentTimeMillis()+"X\" \r\n"+
	               "Server: "+XerverKernel.getXerverName()+" \r\nConnection: close \r\n"+
               "Pragma: no-cache \r\nCache-Control: no-cache \r\n"+
	               "Location: / \r\n"+
//	               "Set-Cookie: hej=12345;\r\n"+
	               "Content-Type: text/html \r\n\r\n");
			os.writeBytes("<HTML><HEAD><TITLE>Please reload this site...</TITLE></HEAD><BODY BGCOLOR=white TEXT=black>");
			os.writeBytes("Please reload this site and enter a username and a password...");
			os.writeBytes("</BODY></HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ show401NotAuthorizedIsNotAccepted:\n"+e.getMessage());}
	}

	static public void show401NotAuthorizedIsAccepted(DataOutputStream os, String s_encryptedPasswordGiven, DateFormat df_dateFormat)
	{
try {
			os.writeBytes("HTTP/1.1 200 OK \r\nDate: "+df_dateFormat.format(new Date())+" \r\n"+
               "Server: "+XerverKernel.getXerverName()+" \r\nConnection: close \r\n"+
               "Pragma: no-cache \r\nCache-Control: no-cache \r\n"+
     //          "Location: "+s_requestedFolderLocation+" \r\n"+
               "Content-Type: text/html \r\n\r\n");
			os.writeBytes("<HTML><HEAD><TITLE>Password Generated...</TITLE></HEAD><BODY BGCOLOR=white TEXT=black>");
			os.writeBytes("<SCRIPT LANGUAGE=javascript>");
			os.writeBytes("data=unescape(location.search);");
			os.writeBytes("passNr=data.substring(data.indexOf('passNr=')+'passNr='.length,data.indexOf('passNr=')+'passNr='.length+1);");
			os.writeBytes("if (passNr==1)");
			os.writeBytes("{");
			os.writeBytes("parent.content.document.addProtWinForm.pass1.value='"+s_encryptedPasswordGiven+"';");
			os.writeBytes("}");
			os.writeBytes("else");
			os.writeBytes("{");
			os.writeBytes("parent.content.document.addProtWinForm.pass2.value='"+s_encryptedPasswordGiven+"';");
			os.writeBytes("}");
			os.writeBytes("</SCRIPT>");
			os.writeBytes("</HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ show401NotAuthorizedIsAccepted:\n"+e.getMessage());}
	}

	static public void showChooseDirectory(DataOutputStream os, String argPath)
	{
try {
		String s_path=argPath;
		PathInfo PI_path=new PathInfo(s_path);
		File f_currentFolder		=PI_path.getCurrentFolder();	//This is null if "argPath" given to the constructor is (1) null, (2) "", (3) an invalid path or (4) an unreadable path, such as A: without a floppy disk.
		File [] af_allFiles		=PI_path.getAllFiles();
		boolean directoryIsValid=PI_path.getDirectoryIsValid();


		os.writeBytes("<HTML><HEAD>"+
					"<TITLE>Choose directory!</TITLE>"+
					"<SCRIPT LANGUAGE=javascript>"+
					"function chooseDir(path)"+
					"{"+
					"  if (opener==null || opener==\"undefined\")"+
					"  {"+
					"    alert(\"An error has occured: Please close the \\\"Choose a directory\\\" window and re-open again before you can choose a directory.\");"+
					"  }"+
					"  else"+
					"  {"+
					"    if (path.substring(path.length-1,path.length)!=\"/\" && path.substring(path.length-1,path.length)!=\"\\\\\")"+		 //Path is a normal folder, not a root... //If path is a root path already has an / (or \) in the end, but if path is just a normal folder there is no / (or \) in path
					"    {"+
					"      path+=\"\\"+File.separator+"\";"+			// Will result in: path+="\\";  or  path+="\/";
					"    }"+
					"    opener.dirChoosen(path);"+
					"    top.close();"+
					"  }"+
					"}"+
					"</SCRIPT>"+
					"</HEAD><BODY BGCOLOR=white TEXT=black>"+
					"<FONT FACE=\"tahoma, arial, verdana\">"+
					"<H2>Choose a directory");
		if (f_currentFolder!=null && directoryIsValid)
			os.writeBytes(" [ "+f_currentFolder.toString()+" ]");
		os.writeBytes("</H2>");

		if (!directoryIsValid)
		{
			os.writeBytes("Xerver had problems try to find or read <B>"+s_path+"</B>."+
						"<BR>"+
						"Listing your roots instead!"+
						"<P>");
		}
		os.writeBytes("Choose a directory by pressing the Choose-button."+
					"<BR>"+
					"Browse a directory by pressing the directory name."+
					"</FONT>"+
					"<P>"+
					"<PRE>");

		if (f_currentFolder!=null) //If [All roots are NOT being listed]...
		{
			os.writeBytes("<B>[<A HREF=\"javascript:chooseDir(\'"+makeJSFriendly(f_currentFolder.toString(),"'")+"\');\" STYLE=\"text-decoration: none;\">Choose this folder</A>]&nbsp;&nbsp;&nbsp;"+f_currentFolder.toString()+"</B>\r\n");
			os.writeBytes("\r\n");

			File f_oneLevelUp=f_currentFolder.getParentFile();
			/*
			if (File.separatorChar=='\\')//Windows...
			{
				s_oneLevelUp=s_oneLevelUp.substring(0,s_oneLevelUp.length()-1).substring(0,s_oneLevelUp.lastIndexOf('\\')+1);	//"c:\aaa\bbb\" ==> "c:\aaa\", or "c:\aaa\bbb" ==> "c:\aaa\").
			}
			else	//UNIX etc...
			{
				s_oneLevelUp=s_oneLevelUp.substring(0,s_oneLevelUp.length()-1).substring(0,s_oneLevelUp.lastIndexOf('/')+1);	//"c:\aaa\bbb\" ==> "c:\aaa\", or "c:\aaa\bbb" ==> "c:\aaa\").
			}
			*/
			if (f_oneLevelUp!=null)	//This is NOT root level, so show a ".." link
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF='/action=chooseDirectory&currentPath="+f_oneLevelUp.toString()+"' STYLE=\"text-decoration: none;\">../</A>\r\n");
			else //This is the root letter, press ".." to show all drives
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF='/action=chooseDirectory' STYLE=\"text-decoration: none;\">../</A>\r\n");
		}

		Arrays.sort(af_allFiles);
		boolean tmpFoldersShown=false;
		for (int i=0 , allFilesLength=af_allFiles.length; i<allFilesLength; i++)
		{
			File tmpFile=af_allFiles[i];
			if (f_currentFolder==null || tmpFile.isDirectory()) //If [it's a directory] OR [All roots are being listed]...
			{
				tmpFoldersShown=true;
				os.writeBytes("[<A HREF=\"javascript:chooseDir(\'"+makeJSFriendly(tmpFile.toString(),"'")+"\');\" STYLE=\"text-decoration: none;\">Choose</A>]&nbsp;&nbsp;&nbsp;<A HREF=\"/action=chooseDirectory&currentPath="+tmpFile.toString()+"\" STYLE=\"text-decoration: none;\">"+tmpFile+"</A>\r\n");
			}
		}
		if (!tmpFoldersShown)
		{
			os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No folders exists in\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>"+s_path+"</B>");
		}
		os.writeBytes("</PRE>");
		os.writeBytes("</BODY>");
		os.writeBytes("</HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showChooseDirectory:\n"+e.getMessage());}
	}

	//terminator shall be " or ' depending on if the JS-string is 'string' or "string"
	private static String makeJSFriendly(String s, String terminator)
	{
		s=MyString.searchAndReplace(s,"\\","\\\\");
		s=MyString.searchAndReplace(s,terminator,"\\"+terminator);
		return s;
	}
}