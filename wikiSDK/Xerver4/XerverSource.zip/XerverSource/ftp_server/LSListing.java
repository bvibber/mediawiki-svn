//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is doing a directory listing with the format used by DIR in MS-DOS.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class LSListing
{
	private static final String [] as_monthNames = new String [] { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" };
	private File f_folder;
	private String s_path;
	private boolean isValidDirectory=false;
	private long l_currentTimeInMillis;	//Use this to know if a file/folder is 6 months or older
	private FileAccess fa_fileAccess;
	private boolean b_readPermissionForFolder;
	private boolean b_writePermissionForFolder;
	boolean b_isDataTransfer;

	private final static boolean b_showErrors=false;

	public LSListing(String argPath, FileAccess fileAccess, boolean isDataTransfer)
	{
		b_isDataTransfer = isDataTransfer;
		fa_fileAccess = fileAccess;
		l_currentTimeInMillis = System.currentTimeMillis();	//To avoid calling this once for each loop over all files/folders, we load and store it in a variable
		s_path=argPath;

		b_readPermissionForFolder = fa_fileAccess.readPermissionOK(s_path);
		b_writePermissionForFolder = fa_fileAccess.writePermissionOK(s_path);

		f_folder=new File(s_path);
		if (f_folder.isDirectory())
			isValidDirectory=true;
	}

	public boolean isValidDirectory()
	{
		return isValidDirectory;
	}



	/**
	* Send the line that is related to this file when we do a normal folder listing.
	*/
	public void sendFileInfo(DataOutputStream bos) throws Exception
	{
		if (isValidDirectory)
		{
			sendDirectoryListing(bos);	//If the argument gave a folder, list the content of the folder
		}
		else
		{
			if (b_isDataTransfer)
				bos.writeBytes(getLSFormat(s_path)+"\r\n");	//Only output this file
			else
				bos.writeBytes(" "+getLSFormat(s_path)+"\r\n");	//Only output this file

		}
	}


	/**
	* Send the directory listing to bos.
	*/
	public void sendDirectoryListing(DataOutputStream bos) throws Exception
	{
		String [] as_allFilesAndFolders;
		int i_numberOfFiles;
		as_allFilesAndFolders=f_folder.list();
		if (as_allFilesAndFolders != null)
		{
			i_numberOfFiles=as_allFilesAndFolders.length;
		}
		else
		{
			throw new Exception("Could not get directory listing. The folder might not exist.");
		}

		File tmpFile;
		String s_pathWithSlashAtEnd = MyPathFunctions.makeSlashAtEnd(s_path);	//Add slash if it does not exist
		for (int i=0; i<i_numberOfFiles; i++)
		{
			if (b_isDataTransfer)
				bos.writeBytes(getLSFormat(s_pathWithSlashAtEnd+as_allFilesAndFolders[i])+"\r\n");
			else
				bos.writeBytes(" "+getLSFormat(s_pathWithSlashAtEnd+as_allFilesAndFolders[i])+"\r\n");
		}

		bos.flush();
	}


	/**
	* Send a alias listing as if the aliases where directories.
	*/
	public void sendAliasListing(DataOutputStream bos, String [] as_aliasesName, String [] as_aliasesPath) throws Exception
	{
		for (int i=0; i<as_aliasesName.length; i++)
		{
			if (b_isDataTransfer)
				bos.writeBytes(getLSFormat(as_aliasesPath[i],as_aliasesName[i])+"\r\n");
			else
				bos.writeBytes(" "+getLSFormat(as_aliasesPath[i],as_aliasesName[i])+"\r\n");
		}
		bos.flush();
	}




	/**
	* Should print out this file as a row in a /bin/ls file listing.
	* "-rw-r--r-- 1 owner group           213 Aug 26 16:31 README"
	* "-rw-r--r-- 1 owner group          1383 Apr 10  1997 ip.c"
	*/
	private String getLSFormat(String s_path)
	{
		File f_file = new File(s_path);
		return getLSFormat(s_path, f_file.getName());
	}

	/**
	* See "getLSFormat(String s_path)".
	* The "s_filename" should normally be the name of the file/folder,
	* but if the File is an alias then it should be the alias name.
	*/
	private String getLSFormat(String s_filePath, String s_filename)
	{
		boolean b_readPermission;
		boolean b_writePermission;
		File f_file = new File(s_filePath);
		StringBuilder sb = new StringBuilder();

		if (f_file.isDirectory())	//If [this is a directory], then...
		{
			//...check what permission it has and don't just use the permission for this folder
			String s_filePathWithSlashAtEnd = MyPathFunctions.makeSlashAtEnd(s_filePath);
			b_readPermission = fa_fileAccess.readPermissionOK(s_filePathWithSlashAtEnd);
			b_writePermission = fa_fileAccess.writePermissionOK(s_filePathWithSlashAtEnd);
		}
		else	//Else [this is a regular file], so...
		{
			//Use the permission we have for the file...
			b_readPermission = b_readPermissionForFolder;
			b_writePermission = b_writePermissionForFolder;
		}

		char c_dirChar = (f_file.isDirectory()) ? 'd' : '-';
		char c_executeChar = (f_file.isDirectory()) ? 'x' : '-';
		char c_readChar = (b_readPermission) ? 'r' : '-';
		char c_writeChar = (b_writePermission) ? 'w' : '-';

		char [] ac_tenChars = new char [] { c_dirChar,
											c_readChar, c_writeChar, c_executeChar,
											c_readChar, c_writeChar, c_executeChar,
											c_readChar, c_writeChar, c_executeChar
											};

		/*
		* Prints "-rw-r--r-- 1 owner group"
		*/

		sb.append(ac_tenChars);
		sb.append(" 1 owner group ");


		/*
		* Prints the file size (or spaces for directories)
		*/
		if (f_file.isDirectory())
		{
			sb.append("            0");
		}
		else
		{
			String s_size = String.valueOf(f_file.length());

			sb.append("             ".substring(s_size.length()));
			sb.append(s_size);
		}

		MyGregorianCalendar gc_lastModified = new MyGregorianCalendar();
		long l_timeInMillis = gc_lastModified.getTimeInMillis();

		/*
		* Prints "Aug 26 16:31" (or "Apr 10  1997" if file is over 6 months old)
		*/
		sb.append(" ");
		sb.append(as_monthNames[gc_lastModified.get(Calendar.MONTH)]);
		sb.append(" ");
		sb.append(gc_lastModified.get(Calendar.DAY_OF_MONTH));

		if (l_timeInMillis > l_currentTimeInMillis - 6 * 30 * 24 * 3600)	//If [file was modified within last 6 months], then...
		{
			sb.append(" ");
			sb.append(gc_lastModified.get(Calendar.HOUR_OF_DAY));
			sb.append(":");
			sb.append(gc_lastModified.get(Calendar.MINUTE));
		}
		else	//Else, file was modified more than 6 months ago...
		{
			sb.append("  ");
			sb.append(gc_lastModified.get(Calendar.YEAR));

		}


		/*
		* Print the file name. (unless this is an alias, this should be the same as "f_file.getName()")
		*/
		sb.append(" ");
		sb.append(s_filename);

		return sb.toString();
	}





	/**
	* Send a HTML-page where you can choose a folder located at <CODE>argPath</CODE>.
	*/
	static public void showChooseDirectory(DataOutputStream os, String argPath)
	{
try {
		String s_path=argPath;
		PathInfo PI_path=new PathInfo(s_path);
		File f_currentFolder		=PI_path.getCurrentFolder();	//This is null if "argPath" given to the constructor is (1) null, (2) "", (3) an invalid path or (4) an unreadable path, such as A: without a floppy disk.
		File [] af_allFiles		=PI_path.getAllFiles();
		boolean directoryIsValid=PI_path.getDirectoryIsValid();


		os.writeBytes("<HTML><HEAD>"+
					"<TITLE>Choose directory!</TITLE>"+
					"<SCRIPT LANGUAGE=javascript>"+
					"function chooseDir(path)"+
					"{"+
					"  if (opener==null || opener==\"undefined\")"+
					"  {"+
					"    alert(\"An error has occured: Please close the \\\"Choose a directory\\\" window and re-open again before you can choose a directory.\");"+
					"  }"+
					"  else"+
					"  {"+
					"    if (path.substring(path.length-1,path.length)!=\"/\" && path.substring(path.length-1,path.length)!=\"\\\\\")"+		 //Path is a normal folder, not a root... //If path is a root path already has an / (or \) in the end, but if path is just a normal folder there is no / (or \) in path
					"    {"+
					"      path+=\"\\"+File.separator+"\";"+			// Will result in: path+="\\";  or  path+="\/";
					"    }"+
					"    opener.dirChoosen(path);"+
					"    top.close();"+
					"  }"+
					"}"+
					""+
					""+
					"function replace(str,oldChar,newChar)"+
					"{"+
					"	for (i=0;i<str.length; i++)"+
					"	{"+
					"		if (str.substring(i,i+1)==oldChar)"+
					"			str=str.substring(0,i)+newChar+str.substring(i+1,str.length);"+
					"	}"+
					""+
					"	return str;"+
					"}"+
					""+
					"</SCRIPT>"+
					"</HEAD><BODY>"+
					"<FONT FACE=\"tahoma, arial, verdana\">"+
					"<H2>Choose a directory");
		if (f_currentFolder!=null && directoryIsValid)
			os.writeBytes(" [ "+f_currentFolder.toString()+" ]");
		os.writeBytes("</H2>");

		if (!directoryIsValid)
		{
			os.writeBytes("Xerver had problems try to find or read <B>"+s_path+"</B>."+
						"<BR>"+
						"Listing your roots instead!"+
						"<P>");
		}
		os.writeBytes("Choose a directory by pressing the Choose-button."+
					"<BR>"+
					"Browse a directory by pressing the directory name."+
					"</FONT>"+
					"<P>"+
					"<PRE>");

		if (f_currentFolder!=null) //If [All roots are NOT being listed]...
		{
			os.writeBytes("<B>[<A HREF=\"javascript:chooseDir(\'"+MyString.searchAndReplace(MyString.searchAndReplace(f_currentFolder.toString(),"\\","\\\\"),"'","\\'")+"\');\" STYLE=\"text-decoration: none;\">Choose this folder</A>]&nbsp;&nbsp;&nbsp;"+f_currentFolder.toString()+"</B>\r\n");
			os.writeBytes("\r\n");

			File f_oneLevelUp=f_currentFolder.getParentFile();

			if (f_oneLevelUp!=null)	//This is NOT root level, so show a ".." link
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"#\" onClick=\"location='/?action=chooseDirectory&currentPath='+replace(escape('"+MyString.searchAndReplace(MyString.searchAndReplace(f_oneLevelUp.toString(),"\\","\\\\"),"'","\\'")+"'),'+','%2B')\" STYLE=\"text-decoration: none;\">../</A>\r\n");
			else //This is the root letter, press ".." to show all drives
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF='/?action=chooseDirectory' STYLE=\"text-decoration: none;\">../</A>\r\n");
		}

		Arrays.sort(af_allFiles);
		boolean tmpFoldersShown=false;
		for (int i=0 , allFilesLength=af_allFiles.length; i<allFilesLength; i++)
		{
			File tmpFile=af_allFiles[i];
			if (f_currentFolder==null || tmpFile.isDirectory()) //If [it's a directory] OR [All roots are being listed]...
			{
				tmpFoldersShown=true;
				os.writeBytes("[<A HREF=\"javascript:chooseDir(\'"+MyString.searchAndReplace(MyString.searchAndReplace(tmpFile.toString(),"\\","\\\\"),"'","\\'")+"\');\" STYLE=\"text-decoration: none;\">Choose</A>]&nbsp;&nbsp;&nbsp;<A HREF=\"#\" onClick=\"location='/?action=chooseDirectory&currentPath='+replace(escape('"+MyString.searchAndReplace(MyString.searchAndReplace(tmpFile.toString(),"\\","\\\\"),"'","\\'")+"'),'+','%2B')\" STYLE=\"text-decoration: none;\">"+tmpFile+"</A>\r\n");
			}
		}
		if (!tmpFoldersShown)
		{
			os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No folders exists in\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>"+s_path+"</B>");
		}
		os.writeBytes("</PRE>");
		os.writeBytes("</BODY>");
		os.writeBytes("</HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showChooseDirectory:\n"+e);}
	}
}



