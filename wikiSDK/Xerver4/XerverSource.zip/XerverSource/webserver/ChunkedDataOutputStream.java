//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>ChunkedDataOutputStream</CODE> is similar to a <CODE>DataOutputStream</CODE>,
 * but a new "writeBytes(String str, boolean bufferData)" method has been created.
 * <BR>
 * <CODE>ChunkedDataOutputStream</CODE> has an internal buffer and it waits until
 * the buffer is large enough (how large is defined in <CODE>i_maxBufferSize</CODE>) before it sends the data.
 * Note that this sends the data "chunked", as it is defined in HTTP/1.1,
 * which means that it won't send only the data given as argument <CODE>str</CODE>,
 * but also send some "\r\n" and the buffer size.
 * This is useful when we don't have the Content-Length of the data we want to send,
 * for example during a directory listing.
 * <BR>
 * Note: If the constructor gets <CODE>argUseChunkedFeatures==false</CODE>, <CODE>ChunkedDataOutputStream</CODE>
 * will work exactly like <CODE>DataOutputStream</CODE>.
 * <BR>
 * finalizeDataTransfer() MUST be called when the last piece of data has been sent.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class ChunkedDataOutputStream extends DataOutputStream
{
	private StringBuffer bufString;
	private final static int i_maxBufferSize=5000;
	private boolean b_useChunkedFeatures;	//Iff this is false ChunkedDataOutputStream will work exactly as a DataOutputStream, otherwise ChunkedDataOutputStream will be used to buffer data and send it "chunked", as it is defined in HTTP/1.1. (This is useful when we don't have the Content-Length of the data we want to send, for example during a directory listing)
	private boolean b_logThisHit;
    /**
     * If argUseChunkedFeatures==false ChunkedDataOutputStream is equivalent to DataOutputStream.
	  * If argUseChunkedFeatures==false you can use this class to send "chunked" data, as it is defined in HTTP/1.1.
     */
	ChunkedDataOutputStream(OutputStream out, boolean argUseChunkedFeatures, boolean argLogThisHit)
	{
		super(out);
		bufString=new StringBuffer(i_maxBufferSize);
		b_useChunkedFeatures=argUseChunkedFeatures;
		b_logThisHit=argLogThisHit;
	}

    /**
     * When you send the HTTP-headers use bufferData==false,
	  * which will make this method to work exactly as writeBytes(str) defined in DataOutputStream.
	  * When bufferData==false then writeBytes(str) defined in DataOutputStream will be used, no matter
	  * if there already exists a buffer. You can use this if you want to send some piece of data before the
	  * current buffer is sent.
	  * In all other cases bufferData must be true to use the buffer which this class is using.
     */
	public synchronized void writeBytes(String str, boolean bufferData) throws IOException
	{
		if (bufferData && b_useChunkedFeatures)
		{
			bufString.append(str);

			if (bufString.length()>i_maxBufferSize)
			{
				sendChunkedData();
			}
		}
		else
		{
			super.writeBytes(str);	//writeUTF?
		}
	}


    /**
     * This can be called at any time and will send what is left in the buffer.
	  * Note that it's recommended to call finalizeDataTransfer() when you are done sending data.
	  * finalizeDataTransfer() will call on flush.
     */
	public synchronized void flush() throws IOException
	{
		//The format of "Transfer-Encoding: chunked\r\n" is:
		if (bufString.length()>0 && b_useChunkedFeatures)
		{
			sendChunkedData();
		}
		super.flush();
	}

    /**
     * This method sends the data chunked.
     * <CODE>Flush()</CODE> and <CODE>writeBytes()</CODE> will call this method when necessary.
     */
	private void sendChunkedData() throws IOException
	{
		int i_sizeOfDataToSend=bufString.length();
		//The format of "Transfer-Encoding: chunked\r\n" is:
		super.writeBytes(Integer.toHexString(i_sizeOfDataToSend));	//First write length of buffer in hexadecimal chars
		super.writeBytes("\r\n");	//Then write \r\n
		super.writeBytes(bufString.toString());	//Then write the buffer
		super.writeBytes("\r\n");	//Then write \r\n
		bufString=new StringBuffer(i_maxBufferSize);

		if (b_logThisHit)
			NewConnection.totalNumberOfBytesDownloaded+=i_sizeOfDataToSend;
	}

    /**
     * This should be called ONCE per each HTTP-respond. After this has been called, don't call "writeBytes" any more.
	  * (or the data won't be sent according to a correct HTTP/1.1 standard)
	  * This Method calls on flush(), so you don't need to call flush() after you called this method.
	  * There will however be no problems if you can flush() after this, but it's unnecessary.
     */
	public synchronized void finalizeDataTransfer() throws IOException
	{
		if (b_useChunkedFeatures)
		{
			flush();//Send what is left in the buffer...
			super.writeBytes("0\r\n\r\n");//Then send a "zero-sized" chunk ending this transfer...

			if (b_logThisHit)
				NewConnection.totalNumberOfBytesDownloaded+=5;	//Size of "0\r\n\r\n"
		}
		super.flush();//Now flush to make sure the "0\r\n" above has been sent...
	}
}
