//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import java.io.*;


final public class RunKiller extends Thread
{
	Process p_proc;
	int i_millisToWait;
	DataOutputStream fos;

	public RunKiller(Process p_argProc, DataOutputStream argFos, int i_argMillisToWait)
	{
		p_proc=p_argProc;
		i_millisToWait=i_argMillisToWait;
		fos=argFos;
	}

	public void run()
	{
		try
		{
			sleep(i_millisToWait);	//Kill process after i_millisToWait milli seconds
		} catch (Exception e){}

		if (p_proc!=null)
		{
			if (fos!=null)
			{
				try
				{
					fos.flush();
					fos.writeBytes("\n\n\nProcess killed by Xerver after "+(i_millisToWait/1000)+" seconds.");
				} catch (Exception e){}
			}
			p_proc.destroy();
			p_proc=null;
		}
	}
}