//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package common;
import ftp_server.*;
import webserver.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;


/**
 *
 * <B>How to use:</B>
 * <BR>
 *<CODE>new ExtractZipFile(String zipFileName, boolean b_overwriteFiles);</CODE>
 * <BR>
 *<CODE>new ExtractZipFile(File zipFile, boolean b_overwriteFiles);</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * <CODE>ExtractZipFile</CODE> opens a zip-file and extracts the files in the zip-file.
 * <BR>
 * This class does also support zip-files with directories (directories will be created and files moved into the directories).
 * <BR>
 * Set <CODE>b_overwriteFiles = true</CODE> and files will be overwritten if they already exists.
 * <BR>
 * Set <CODE>b_overwriteFiles = false</CODE> and files will NOT be overwritten if they already exists.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

public class ExtractZipFile
{
	protected final boolean b_showErrors=false;
	protected boolean b_overwriteFiles=false;	//this will be set in the constructor as well...

	public ExtractZipFile(String s, boolean argOverwriteFiles)
	{
		this(new File(s), argOverwriteFiles);
	}

	public ExtractZipFile(File zipFile, boolean argOverwriteFiles)
	{
		this(zipFile, argOverwriteFiles, null);
	}

	public ExtractZipFile(String s, boolean argOverwriteFiles, String s_defaultPath)
	{
		this(new File(s), argOverwriteFiles, s_defaultPath);
	}

	public ExtractZipFile(File zipFile, boolean argOverwriteFiles, String s_defaultPath)
	{
		try {
		if (s_defaultPath==null)
			s_defaultPath="";
		else if ((new File(s_defaultPath)).exists())
			s_defaultPath=(new File(s_defaultPath)).getPath()+File.separator;
		else
			s_defaultPath="";

		b_overwriteFiles=argOverwriteFiles;
		ZipFile ZF_theZipFile=new ZipFile(zipFile);
		//Enumeration e_allFiles=ZF_theZipFile.entries();

		//System.out.println("Folders:");
		//First, create all folders
		for (Enumeration e = ZF_theZipFile.entries() ; e.hasMoreElements() ;)
		{
			ZipEntry myZipEntry=(ZipEntry)e.nextElement();
			if (myZipEntry.isDirectory())
			{
				File newDir=new File(s_defaultPath+myZipEntry.getName());
				newDir.mkdirs();
			}
		}

		//System.out.println("Files:");
		//Then extract all the files
		for (Enumeration e = ZF_theZipFile.entries() ; e.hasMoreElements() ;)
		{
			ZipEntry myZipEntry=(ZipEntry)e.nextElement();
			if (!myZipEntry.isDirectory() && (overWriteFile(myZipEntry) || !(new File(myZipEntry.getName())).exists()))	//if [this is not a directory] and [[we shall overwrite] or [this file doesn't exists]]...
			{
				BufferedInputStream bis=new BufferedInputStream(ZF_theZipFile.getInputStream(myZipEntry));
				BufferedOutputStream bos;
				bos=new BufferedOutputStream(new FileOutputStream(s_defaultPath+myZipEntry.getName()));

				(new ReadInputStream(bis,bos)).start();
			}
		}
		} catch (Exception e) {if (b_showErrors)System.out.println("An error has occured:\nProbably, \""+zipFile.getPath()+"\" was not found.\nThe error output is: "+e);}
	}

	boolean overWriteFile(ZipEntry myZipEntry)
	{
		return b_overwriteFiles;
	}
}