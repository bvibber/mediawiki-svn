//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package ftp_server;
import webserver.*;
import common.*;
import java.net.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is the FTP data connection.
 * <BR>
 * There are two different constructors.
 * One if you want use passive mode ("PASV") and one if you want use active mode ("PORT").
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class FTPDataConnection extends Thread
{
	private static final boolean b_showErrors=false;
	private ServerSocket ss_dataConnection;
	private int i_portNr;
	private Socket so_userConnection;
	private DataOutputStream bos;
	private DataInputStreamWithReadLine bis;
	private boolean b_isPASV;
	private boolean b_couldConnectInPORTmode=true;	//This MUST be true here, and will be set to false if port nr "i_dataPortNr" is already in use or banned (or another error occur so the connection fails).
	public static int i_dataPortNr;
	private String s_hostUsedForPORT;
	private int i_portUsedForPORT;
	private boolean b_weHaveStoppedListeningToPort = false;
	//Save this for future use?:	private int raknare=0;


	// Which port range shall we use? See the construction comment below.
	public static int [] ai_portRange = null;
	private static int i_nextPortToUse = -1;  // which port shall we use next? (For PASV only, when we want ports in a particular range)

	private static int MAX_NR_GET_FREE_PORT_ATTEMPTS = 100;		//This only matters if the size of the range of ports is greater than this value. Normally we try to open everysingle port in the specified interval to be able to find if any port works. However, if the interval is too big that would take to long time, instead we have this to have a maximum number of ports that we will try to open. If the range for example is 25-35 and this value is for example 50, we will still only try to open 10 ports, not 50.
	private static int MAX_NR_PASV_RETRY_ATTEMPTS = 10;			//This is how many times we should retry to call ".accept()" if it throws exceptions (other than the SocketTimeoutException exception which is thrown if the client never takes the connection - if SocketTimeoutException is thrown we will not retry to listen to the port).


	/**
	* Create DataConnection for passive mode (PASV).
	*/
	public FTPDataConnection()
	{
		//Save this for future use?:	raknare=(int)(Math.random()*1000);
		try {
			b_isPASV=true;
			ss_dataConnection = getFreePortServerSocket();
			ss_dataConnection.setSoTimeout(FTPNewConnection.i_timeForClientToTakeDataConnedtion);	//Wait i_timeForClientToTakeDataConnedtion milliseconds
			i_portNr=ss_dataConnection.getLocalPort();

		} catch (Exception e){showError(e);}
	}


 	/**
 	* Returns a ServerSocket bound to a port.
 	* We will try to pick a port in the range specified in "ai_portRange",
 	* but if not possible, we will just pick any port, so there are no guarantees
 	* that we will be connected to a port in the specified range.
	*/
	private static ServerSocket getFreePortServerSocket() throws Exception
	{
		//We will only look for a specific port number if a range is specified
		if (ai_portRange != null)
		{
			if (i_nextPortToUse == -1 || i_nextPortToUse > ai_portRange[1])
			{
				i_nextPortToUse = ai_portRange[0]; 	//The first port we should look for is ai_portRange[0]
			}
			int i_startPos = i_nextPortToUse;
			int i_nrFailures = 0;
			do
			{
				try
				{
					return new ServerSocket(i_nextPortToUse++);	//Try to open this port. If it throws an exception, we will loop and try next port
				}
				catch (Exception e)
				{
					//We could not open the port.
					//This can be due to that the port is already used, or due to that some security restriction
					//which does not allow us to connect to that port.
					//It could also happen that two threads starts at approximately the same time and they would both
					//try to open the same port, but only one would succeed and the other one would loop one more time
					//and get the next port in the range.
					i_nrFailures++;
					i_nextPortToUse++;
					if (i_nextPortToUse > ai_portRange[1])
					{
						i_nextPortToUse = ai_portRange[0];
					}
				}
			} while (i_startPos != i_nextPortToUse && i_nrFailures < MAX_NR_GET_FREE_PORT_ATTEMPTS);	//When we have looped through all ports in the range, and neither one worked, stop looping
		}

		//We failed to find any port in the correct range (or we didn't specify any interval), so just open any port
		return new ServerSocket(0);	//Just open any port
	}

	/**
	* Create DataConnection for active mode (PORT).
	* When we call waitForDataConnectionToBeTaken we will connect to port <CODE>port</CODE> at host <CODE>host</CODE>.
	*/
	public FTPDataConnection(String host, int port)
	{
		b_isPASV=false;
		s_hostUsedForPORT=host;
		i_portUsedForPORT=port;
	}

	/**
	* This is set when we use passive mode (PASV) and returns what port we are listening to.
	*/
	public int getPortNr()
	{
		return i_portNr;
	}

	/**
	* This returns true iff we use active mode (PORT) and if the local port was blocked or already in use.
	*<BR>
	* By defult we will try to use port 20, but this can be changed at setup.
	*<BR>
	* In all other cases this will return false.
	*/
	public boolean portNumberOccupiedWithPORT()
	{
		return !b_isPASV && !b_couldConnectInPORTmode;
	}

	public void run()
	{
		try {
			if (b_isPASV)
			{
				getSocket();		//Get socket here
				stopListenToPort();	//Now we might or might not have the Socket (connected to the client), but in any case, stop listen to the port. Free it up.
			}
			else
			{
			}
		} catch (Exception e){showError(e);}
	}

	/**
	* This is only used when we use passive mode (PASV).
	* <BR>
	* This will be called when we call "start()" ("run()") and starts listening for incoming connections.
	*/
	private void getSocket()
	{
		int i_nrIter = 0;
		//To stop listen to the port, set ss_dataConnection to null.
		while (ss_dataConnection != null && so_userConnection == null && i_nrIter < MAX_NR_PASV_RETRY_ATTEMPTS)	//IMPORTANT!!! make sure this loop won't go around too many times without doing anything or java will use up to 100% CPU. Instead let the loop be halted by for example an accept call which will wait for a network connection to be established...
		{
			try
			{
				so_userConnection=ss_dataConnection.accept();	//Wait until a request is sent to the server (with "myServerSocket.setSoTimeout()" we can limit the time we wait for "accept")
			}
			catch (SocketTimeoutException e)	//After i_timeForClientToTakeDataConnedtion milliseconds an SocketTimeoutException will be thrown from ".accept()"
			{
				//Before we go out of the getSocket() function, make sure we have stopped listening to the port, so close the ServerSocket
				return;	//We have waited enough, don't iterate
			}
			catch (Exception e)
			{
				try
				{
					Thread.sleep(200);
				}
				catch (InterruptedException ex)
				{
					//do nothing
				}
			}
			finally
			{
				i_nrIter++;
			}
		}

		try
		{
			if (ss_dataConnection != null)
			{
				//At this point the client might or might not have taken the connection. Even if it has not taken it we will stop waiting here and close the ServerSocket that is listening to the port. The client has to request to open a new ServerSocket if he wants to connect to us.
				ss_dataConnection.close();
				ss_dataConnection=null;
			}
			bos=new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));
			bis=new DataInputStreamWithReadLine(new BufferedInputStream(so_userConnection.getInputStream()));
		}
	    catch (Exception e)
	    {
		    showError(e);
	    }
	}

	private void showError(Exception e)
	{
		if (b_showErrors)
		{
			System.out.println("Error: " + e);
			e.printStackTrace();
		}
	}

	/**
	* Close the socket that is used to communicate with the client.
	*/
	public void killConnection()
	{
		try {
			if (so_userConnection!=null)
				so_userConnection.close();
			if (bis!=null)
				bis.close();
			if (bos!=null)
				bos.close();
			//if (ss_dataConnection!=null)
			//	ss_dataConnection.close();

			//ss_dataConnection=null;
			so_userConnection=null;
			bis=null;
			bos=null;
		} catch (Exception e){showError(e);}
	}

	/**
	* If we use active mode (PORT) we will always just return true.
	* <BR>
	* If we use passive mode (PASV) we will see if the connection we are listening to is taken or not.
	* <BR>
	* If not taken we will see if it becomes taken within maxWaitTimeInMillis milli seconds.
	* <BR>
	* If it's taken, we return true. Otherwise false.
	*/
	public boolean waitForDataConnectionToBeTaken(long maxWaitTimeInMillis)	//Returns true iff the dataconnection is taken within the time given (returns false if the connection is never taken and if it has not been taken earlier either)
	{
		if (b_isPASV)
		{
			long l_startTime=System.currentTimeMillis();
			while (bos==null && !b_weHaveStoppedListeningToPort && l_startTime+maxWaitTimeInMillis>System.currentTimeMillis())
			{
				yield();
				try
				{
					Thread.sleep(50);
				}
				catch (Exception e)
				{
					//Do nothing
				}
			}

			if (bos==null)
				return false;	//Data connection never taken
			else
				return true;	//Data connection taken
		}
		else
			return true;
	}


	/**
	* We only use this in active mode (PORT).
	* <BR>
	* When we call this we will try to connect to the client.
	*/
	private void connectPORTconnection() throws Exception
	{
		if (so_userConnection==null)
		{
			try {
				so_userConnection=new Socket(s_hostUsedForPORT,i_portUsedForPORT,InetAddress.getLocalHost(),i_dataPortNr);
			}
			catch (BindException e)
			{
				b_couldConnectInPORTmode=false;	//this must be set here so we know if the connection was successful or failed
				throw e;
			}

			bos=new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));
			bis=new DataInputStreamWithReadLine(new BufferedInputStream(so_userConnection.getInputStream()));
		}
	}


	/**
	* In passive mode (PASV) we will stop listening for incoming connections by killing the ServerSocket we have created.
	* <BR>
	* In both active mode (PORT) and passive mode (PASV) we will close the Socket that is used to communicate with the client.
	*/
	public void stopListenToPortAndKillCurrentConnection()
	{
		try {
			killConnection();	//First kill any connection that might be available
			stopListenToPort();	//Now close any ServerSocket that might be listening for incoming connections
		} catch (Exception e){showError(e);}
	}

	/**
	* In passive mode (PASV) we will stop listening for incoming connections by killing the ServerSocket we have created.
	* <BR>
	* In both active mode (PORT) and passive mode (PASV) we will close the Socket that is used to communicate with the client.
	*/
	public void stopListenToPort()
	{
		try {
			b_weHaveStoppedListeningToPort = true;
			//Now close any ServerSocket that might be listening for incoming connections
			if (ss_dataConnection!=null)
				ss_dataConnection.close();
			ss_dataConnection=null;
		} catch (Exception e){showError(e);}
	}


	/**
	* Send a directory listing.
	*/
	public void sendDirectoryListing(LSListing ls_listing) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		ls_listing.sendDirectoryListing(bos);
	}

	/**
	* Send an alias listing as if the aliases where directories.
	*/
	public void sendAliasListing(LSListing ls_listing, String [] as_aliasesName, String [] as_aliasesPath) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		ls_listing.sendAliasListing(bos, as_aliasesName, as_aliasesPath);
	}

	/**
	* Send the line that is related to this file when we do a normal folder listing.
	*/
	public void sendFileInfo(LSListing ls_listing) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		ls_listing.sendFileInfo(bos);
	}


	/**
	* Send a directory listing.
	*/
	public void sendDirectoryListingMLSDStyle(MLSDListing mlsd) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		mlsd.sendDirectoryListing(bos);
	}

	/**
	* Send an alias listing as if the aliases where directories.
	*/
	public void sendAliasListingMLSDStyle(MLSDListing mlsd, String [] as_aliasesName, String [] as_aliasesPath) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		mlsd.sendAliasListing(bos, as_aliasesName, as_aliasesPath);
	}

	/**
	* Send the line that is related to this file when we do a normal folder listing.
	*/
	public void sendHeaderListingMLSDStyle(MLSDListing mlsd) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		mlsd.sendHeaderListing(bos);
	}

	/**
	* Read this file, skip i_startPosition bytes.
	*/
	public void sendFileContentBinary(String s_file, int i_startPosition) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		StreamIO.writeFileToStream(new File(s_file), bos, i_startPosition);
	}

	/**
	* Read this file.
	*/
	public void sendFileContentASCII(String s_file) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		StreamIO.writeASCIIFileToStream(new File(s_file), bos);
	}

	/**
	* Write data to this file.
	*/
	public void writeFile(String s_file, boolean b_append) throws Exception
	{
		if (!b_isPASV)	//PORT shall make the connection AFTER the first response. So we most connect here.
			connectPORTconnection();

		StreamIO.writeFile(s_file, bis, b_append);
	}

	/**
	* Just in case clean up.
	*/
	protected void finalize() throws Throwable
	{
		stopListenToPortAndKillCurrentConnection();
	}
}




