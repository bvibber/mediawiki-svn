//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;



/**
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>(new ReadInputStream(InputStream argIs, OutputStream argOs)).start();</CODE>
 * <BR>
 * <CODE>(new ReadInputStream(String argStringToOutput, OutputStream argOs)).start();</CODE>
 * <BR>
 * <CODE>(new ReadInputStream(char [] argCharToOutput, OutputStream argOs)).start();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * Takes an <CODE>InputStream</CODE> (<CODE>argIs</CODE>) (or a <CODE>String</CODE> or an array of <CODE>char</CODE>)
 * <BR>
 * and writes everything coming from this stream to the <CODE>OutputStream</CODE> (<CODE>argOs</CODE>).
 * <BR>
 * If you don't give an <CODE>InputStream</CODE>, but a <CODE>String</CODE> or an array of <CODE>char</CODE>,
 * <BR>
 * the <CODE>String</CODE>/the <CODE>char</CODE>s will be written to the <CODE>OutputStream</CODE> (<CODE>argOs</CODE>).
 * <BR>
 * <BR>
 *
 * <B>IMPORTANT:</B> <CODE>argOs</CODE> is closed ("<CODE>argOs.close()</CODE>") by <CODE>ReadInputStream</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

public class ReadInputStream extends Thread
{
	protected final static int INPUT_MODE=0;
	protected final static int CHAR_MODE=1;
	protected final static int RESPOND_UNDEFINED=-1;
	protected final static int RESPOND_STDERR=0;
	protected final static int RESPOND_STDOUT=1;
	protected InputStream is;
	protected OutputStream os;
	private String s_StringToOutput=null;
	private char [] c_charToOutput;
	protected int currentMode;
	protected final static boolean b_showErrors=false;

	public ReadInputStream()	//now we can Extend ReadInputStream without problem
	{
	}

	public ReadInputStream(InputStream argIs, OutputStream argOs)
	{
		currentMode=INPUT_MODE;
		is=argIs;
		os=argOs;
	}

	public ReadInputStream(String argStringToOutput, OutputStream argOs)
	{
		this(argStringToOutput.toCharArray(), argOs);
	}

	public ReadInputStream(char [] argCharToOutput, OutputStream argOs)
	{
		currentMode=CHAR_MODE;
		c_charToOutput=argCharToOutput;
		os=argOs;
	}

	public void run()
	{
		if (currentMode==INPUT_MODE)
			sendDataInputMode();
		else if (currentMode==CHAR_MODE)
			sendDataCharMode();
	}

	public void sendDataCharMode()
	{
		try
		{
			char [] b=c_charToOutput;
			for (int i=0 , bLength=b.length; i<bLength; i++)
			{
				os.write(b[i]);
			}

			os.flush();
			os.close();
		} catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ sendDataCharMode\n"+e);}
	}

	public void sendDataInputMode()
	{
		try
		{
			int n;
			byte [] buffer=new byte [8192];
			while ((n=is.read(buffer))!=-1)
			{
				os.write(buffer,0,n);
			}

			os.flush();
			os.close();	// os MUST be closed, or the browser will wait for more data. (with netscape: the stop-button will be "clickable" as the browser waits for the server to write more data or to close the connection (we close the connection with this line).
		} catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ sendDataInputMode:\n"+e.getMessage());}
	}
}

