#######################################################################
################### How To Install and Start Xerver ###################
#######################################################################


  WINDOWS USERS:
  Start Xerver with "StartXerver.exe"
  and run the setup with "Setup.exe".

  NON WINDOWS USERS:
  Enter one of the following lines in your prompt:
  * java -jar xerver.jar		Start Xerver
  * java -jar xerver.jar Server		Start Xerver
  * java -jar xerver.jar Setup		Start Xerver Setup
  * java -jar xerver.jar FTPServer	Start Xerver FTP
  * java -jar xerver.jar FTPSetup	Start Xerver FTP Setup


  Actually, you also have these "subparameters" you can use as well
  (you can combine them as well):
  * java -jar xerver.jar FTPServer -pXX		Start server on port XX
  * java -jar xerver.jar FTPServer -c		Send all requests and responses to STDOUT

  * java -jar xerver.jar FTPSetup -pXX		Start FTP setup on port XX
  * java -jar xerver.jar FTPSetup -r		Start FTP remote setup

  * java -jar xerver.jar Setup -pXX		Start setup on port XX
  * java -jar xerver.jar Setup -r		Start remote setup
  * java -jar xerver.jar Setup -nw		Start setup without a GUI

  * java -jar xerver.jar Server -nw		Is equivalent to -s0
  * java -jar xerver.jar Server -sX		Start server in mode X where X is an integer:
						0 = start with no GUI 
						1 = start with a basic AWT-interface
						2 = start with an advanced Swing-interface
                                                    (not minimized at startup)
						3 = start with an advanced Swing-interface
                                                    (minimized at startup)


  EXAMPLE:
  * java -jar xerver.jar Setup -nw -r -p1234	Start setup on port 1234 without a GUI
						and allow remote IPs to connect to setup.


  Additional instructions can be found in the "help" directory
  (which will be created after you have followed the instructions above).