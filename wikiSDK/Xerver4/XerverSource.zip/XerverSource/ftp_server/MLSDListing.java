//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is doing a directory listing with the format that the MLSD command requires.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MLSDListing
{
	private File f_folder;
	private String s_path;
	private String s_absolutePath;
	private boolean isValidDirectory=false;

	private final static boolean b_showErrors=false;

	public MLSDListing(String argPath, String absolutePath)
	{
		s_path=argPath;
		s_absolutePath=absolutePath;
		f_folder=new File(s_path);
		if (f_folder.isDirectory())
			isValidDirectory=true;
	}

	public boolean isValidDirectory()
	{
		return isValidDirectory;
	}


	/**
	* Only send the one row that has "Type=cdir".
	* This should be sent regardless if we show folders, aliases, or both.
	*/
	public void sendHeaderListing(DataOutputStream bos) throws Exception
	{
		bos.writeBytes(getMLSDFormatForCurrentDirector(f_folder,s_absolutePath)+"\r\n");
		bos.flush();
	}

	/**
	* Send the directory listing to bos.
	*/
	public void sendDirectoryListing(DataOutputStream bos) throws Exception
	{
		File [] af_allFilesAndFolders;
		int i_numberOfFiles;
		af_allFilesAndFolders=f_folder.listFiles();
		if (af_allFilesAndFolders != null)
		{
			i_numberOfFiles=af_allFilesAndFolders.length;
		}
		else
		{
			throw new Exception("Could not get directory listing. The folder might not exist.");
		}

		File tmpFile;

		for (int i=0; i<i_numberOfFiles; i++)
		{
			bos.writeBytes(getMLSDFormat(af_allFilesAndFolders[i])+"\r\n");
		}

		bos.flush();
	}


	/**
	* Send a alias listing as if the aliases where directories.
	*/
	static public void sendAliasListing(DataOutputStream bos, String [] as_aliasesName, String [] as_aliasesPath) throws Exception
	{
		for (int i=0; i<as_aliasesName.length; i++)
		{
			System.out.println(as_aliasesPath[i]);
			System.out.println(as_aliasesName[i]);
			bos.writeBytes(getMLSDFormatForAliasDirector(new File(as_aliasesPath[i]),as_aliasesName[i])); //"Type=dir;Modify=20000101000000; "+tmpAlias+"\r\n");
		}
		bos.flush();
	}

	/**
	* This gives the MLST format for the a file or folder.
	* MLST is used when we send the data over the control connection,
	* and not the data connection.
	* Note that when we print it out we should also send a space before we
	* send what this function returns.
	* Also note that we show the entire PATH instead of just the file name.
	* Example:
	*  Type=dir;Modify=20061219222955; /some/path/MyFolder
	*  Type=file;Size=3806664;Modify=20061219223422; /some/path/MyText.txt
	*/
	static public String getMLSTFormat(File f_file, String s_absPath)
	{
		StringBuffer sb = new StringBuffer();

		/*
		* First give the "Type":
		* "cdir" for the current directory (this is kind of the heading for a MLSD response)
		* "dir" a directory.
		* "file" a file.
		*/

		if (f_file.isDirectory())
		{
			sb.append("Type=dir;");
		}
		else
		{
			sb.append("Type=file;");
		}


		/*
		* For "Size":
		* Only for files, not for folders
		*/

		if (!f_file.isDirectory())
		{
			sb.append("Size=");
			sb.append(f_file.length());
			sb.append(";");
		}


		/*
		* "Modify".
		* Using the YYYYMMDDhhmmss format. Both for files and folders.
		*/

		sb.append("Modify=");
		sb.append(MyFileFunctions.getLastModifiedAsFormatedString(f_file));
		sb.append(";");


		/*
		* The last entry is just the filename
		*/

		sb.append(" ");
		sb.append(MyPathFunctions.makeSlashForResponse(s_absPath));


		return sb.toString();
	}


	/**
	* This gives the MLSD format for the a file or folder. Example:
	* Type=dir;Modify=20061219222955; MyFolder
	* Type=file;Size=3806664;Modify=20061219223422; MyText.txt
	*/
	static private String getMLSDFormat(File f_file)
	{
		StringBuffer sb = new StringBuffer();

		/*
		* First give the "Type":
		* "cdir" for the current directory (this is kind of the heading for a MLSD response)
		* "dir" a directory.
		* "file" a file.
		*/

		if (f_file.isDirectory())
		{
			sb.append("Type=dir;");
		}
		else
		{
			sb.append("Type=file;");
		}


		/*
		* For "Size":
		* Only for files, not for folders
		*/

		if (!f_file.isDirectory())
		{
			sb.append("Size=");
			sb.append(f_file.length());
			sb.append(";");
		}


		/*
		* "Modify".
		* Using the YYYYMMDDhhmmss format. Both for files and folders.
		*/

		sb.append("Modify=");
		sb.append(MyFileFunctions.getLastModifiedAsFormatedString(f_file));
		sb.append(";");


		/*
		* The last entry is just the filename
		*/

		sb.append(" ");
		sb.append(f_file.getName());


		return sb.toString();
	}



	/**
	* This gives the MLSD format for the current dirctory. Example:
	* Type=cdir;Modify=20060202221608; /Musik/oldies 1
	*/
	private static String getMLSDFormatForCurrentDirector(File f_file, String s_absPath)
	{
		StringBuffer sb = new StringBuffer();

		/*
		* First give the "Type":
		* "cdir" for the current directory (this is kind of the heading for a MLSD response)
		* "dir" a directory.
		* "file" a file.
		*/

		if (f_file.isDirectory())
		{
			sb.append("Type=cdir;");
		}
		else
		{
			throw new Error("getMLSDFormatForCurrentDirector was called for a file that is not a directory.");
		}

		/*
		* "Modify".
		* Using the YYYYMMDDhhmmss format.
		*/

		sb.append("Modify=");
		sb.append(MyFileFunctions.getLastModifiedAsFormatedString(f_file));
		sb.append(";");


		/*
		* The last entry is just the absolute path to the folder
		*/
		sb.append(" ");
		sb.append(MyPathFunctions.makeSlashForResponse(MyPathFunctions.makeSlashAtEnd(s_absPath)));

		return sb.toString();
	}


	/**
	* This gives the MLSD format for the an alias. Example:
	* Type=dir;Modify=20061219222955; MyFolder
	*/
	private static String getMLSDFormatForAliasDirector(File f_file, String s_aliasName)
	{
		StringBuffer sb = new StringBuffer();

		/*
		* First give the "Type":
		* "cdir" for the current directory (this is kind of the heading for a MLSD response)
		* "dir" a directory.
		* "file" a file.
		*/

		if (f_file.isDirectory())
		{
			sb.append("Type=dir;");
		}
		else
		{
			throw new Error("getMLSDFormatForAliasDirector was called for a file that is not a directory.");
		}

		/*
		* "Modify".
		* Using the YYYYMMDDhhmmss format.
		*/

		sb.append("Modify=");
		sb.append(MyFileFunctions.getLastModifiedAsFormatedString(f_file));
		sb.append(";");


		/*
		* The last entry is just the absolute path to the folder
		*/
		sb.append(" ");
		sb.append(s_aliasName);

		return sb.toString();
	}
}



