//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat



/**
 *
 * <B>About this class:</B>
 * <BR>
 * For every connection that is made to the Xerver FTP Setup one
 * <CODE>FTPSetupConnection</CODE> is created.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class FTPSetupConnection extends Thread
{
	private final static String s_userFolder=FTPServerController.s_userFolder;
	private final static String s_initFile=FTPServerController.s_initFile;
	private final static String s_dataFolder=FTPServerController.s_dataFolder;
	private final static String s_userDataExtension=FTPServerController.s_userDataExtension;
	private final static boolean b_showErrors=false;
	private Socket so_userConnection;
	private DataOutputStream theOutput;	//Everything written to this will be sent to the browser
	private String s_allData, s_requestedFolderLocation, s_errorStatus, s_requestMethod, s_requestDocument;
	private Date d_dateToday;
	private DateFormat df_dateFormat;
	private BufferedReader br_theInputWeGetFromBrowser;	//Read the browsers header from this
	private MyHashTable MyHT_allDataFromQuery;
	private FTPSettings FTPS_settings;
	private UserDatabase UD_userDatabase;


	public FTPSetupConnection(Socket agrUserConnection)
	{
		try {
			so_userConnection=agrUserConnection;
			d_dateToday = new Date();
			df_dateFormat=DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
			s_errorStatus="200 OK";

			getRequestInformation();
			createVariables();

			theOutput = new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));	//I "java.io.*"

			chooseWhatToReturn();
		} catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getRequestInformation:\n"+e.getMessage());}
	}



	private void chooseWhatToReturn()
	{
		try {
			String s_actionValue=MyHT_allDataFromQuery.giveValueByIndex("action");
			String s_userValue=MyHT_allDataFromQuery.giveValueByIndex("username");

			if (!ValidateInput.isValidUserName(s_userValue))
			{
				s_userValue=null;	//s_userValue shall either be null, or a valid user name...
			}

			if (s_actionValue!=null)	//If there is an action given (there shall always be an action given, but not if you visit the "setup root" (="http://localhost:32123/")...
			{
				//************** SAVE SETTINGS TO XERVER, NOT TO A USER **************
				if (s_actionValue.equals("saveConfig"))
				{
					DatabaseFile DF_setupFile=new DatabaseFile(s_initFile);
					String s_portNr=MyHT_allDataFromQuery.giveValueByIndex("portNr");
					String s_logFile=MyHT_allDataFromQuery.giveValueByIndex("logFile");
					String s_passiveRange=MyHT_allDataFromQuery.giveValueByIndex("passiveRange");
					String s_localIP=MyHT_allDataFromQuery.giveValueByIndex("localIP");
					String s_outerIP=MyHT_allDataFromQuery.giveValueByIndex("outerIP");
					String s_showAlias=MyHT_allDataFromQuery.giveValueByIndex("showAlias");
					String s_guestAccount=MyHT_allDataFromQuery.giveValueByIndex("guestAccount");
					String s_maxTimeToIdle=MyHT_allDataFromQuery.giveValueByIndex("maxIdleTime");
					String s_maxNumberOfNOOP=MyHT_allDataFromQuery.giveValueByIndex("maxNOOPAllowed");
					String s_dataPortNr=MyHT_allDataFromQuery.giveValueByIndex("dataPortNr");

					if (s_portNr!=null)
						DF_setupFile.setValue("PORT_NR",s_portNr);
					if (s_logFile!=null)
						DF_setupFile.setValue("LOG_FILE",s_logFile);
					if (s_showAlias!=null)
						DF_setupFile.setValue("SHOW_ALIAS",s_showAlias);
					if (s_guestAccount!=null)
						DF_setupFile.setValue("GUEST_ACCOUNT",s_guestAccount);
					if (s_maxTimeToIdle!=null)
						DF_setupFile.setValue("MAX_IDLE_TIME",s_maxTimeToIdle);
					if (s_maxNumberOfNOOP!=null)
						DF_setupFile.setValue("MAX_NOOP_ALLOWED",s_maxNumberOfNOOP);
					if (s_passiveRange!=null)
						DF_setupFile.setValue("PASSIVE_PORT_RANGE",s_passiveRange);
					if (s_localIP!=null)
						DF_setupFile.setValue("LOCAL_IP",s_localIP);
					if (s_outerIP!=null)
						DF_setupFile.setValue("OUTER_IP",s_outerIP);
					if (s_dataPortNr!=null)
						DF_setupFile.setValue("DATA_PORT_NR",s_dataPortNr);

					FTPServer FTPS_currentlyRunning=FTPServer.getFTPServer();
					FTPS_settings.updateData();

					if (FTPS_currentlyRunning!=null)	//If server is running, make sure we update settings to the server that is already running.
					{
						FTPS_currentlyRunning.initSettings();	//Set the port-variable...
						FTPS_currentlyRunning.listenForConnections();//...Which is used here
					}

					returnThisPage(s_dataFolder+"WizUserFrames.html", "text/html");

				} //************** SAVE SETTINGS TO A USER **************
				else if (s_actionValue.equals("save"))
				{
					String s_typeValue=MyHT_allDataFromQuery.giveValueByIndex("type");
					String s_newValue=MyHT_allDataFromQuery.giveValueByIndex("newValue");
					if (s_userValue!=null && s_typeValue!=null)
					{
						DatabaseFile DF_user=new DatabaseFile(s_userFolder+s_userValue+s_userDataExtension);
						if (s_typeValue.equals("root"))
						{
							s_newValue=ValidateInput.makeValidPath(s_newValue);	//Necessary??

							if (s_newValue!=null)
							{
								DF_user.setValue("ROOT",s_newValue);
								DF_user.destroy();
								DF_user=null;
								UD_userDatabase.updateDatabase();

								returnThisPage(s_dataFolder+"WizDataSaved.html", "text/html");
							}
							else
							{
								ShowFTPSetupPages.showInvalidrequest(theOutput);
							}
						}
						else if (s_typeValue.equals("updatePermissions"))
						{
							if (s_newValue!=null)
							{
								DF_user.setValue("PERMISSIONS",s_newValue);
								DF_user.destroy();
								DF_user=null;
								UD_userDatabase.updateDatabase();

								returnThisPage(s_dataFolder+"WizSetPermissions.html", "text/html");
								ShowFTPSetupPages.showPermissionsInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
							}
							else
							{
								ShowFTPSetupPages.showInvalidrequest(theOutput);
							}
						}
						else if (s_typeValue.equals("addPermissions"))
						{
							UserData UD_user=UD_userDatabase.getUserData(s_userValue);
							String newPermissionPath=ValidateInput.makeValidPath(MyHT_allDataFromQuery.giveValueByIndex("newPermissionPath"));

							if (ValidateInput.isValidPath(newPermissionPath))
							{



								//******* START: FIND OUT IF PATH ALREADY EXISTS ************
								String [] as_allPermissions=MyString.makeArrayOfString(UD_user.getPermissionsString(),",");

								//ALL THESE ARE TEMPORARY VARIABLES (NO GLOBAL VARIABLES)
								int i_lengthAllPermissions=as_allPermissions.length;
								int separatorIndexOf;
								String path, tmpLine /*, attribute*/;
								boolean b_pathAlreadyInList=false;
								String attributes;


								for (int i=0; i<i_lengthAllPermissions; i++)
								{
									tmpLine=as_allPermissions[i];
									separatorIndexOf=tmpLine.lastIndexOf(';');
									path=tmpLine.substring(0,separatorIndexOf);
									//Don't need this here:		attribute=tmpLine.substring(separatorIndexOf+1);

									if (path.endsWith("*"))
									{
										if ((newPermissionPath+"*").equalsIgnoreCase(path))
										{
											b_pathAlreadyInList=true;
											break;
										}
									}
									else
									{
										if (newPermissionPath.equalsIgnoreCase(path))
										{
											b_pathAlreadyInList=true;
											break;
										}
									}
								}
								//******* STOP: FIND OUT IF PATH ALREADY EXISTS ************


								if (!b_pathAlreadyInList)
								{
									attributes="";
									if (MyHT_allDataFromQuery.giveValueByIndex("thisRead")!=null)
										attributes+="r";
									if (MyHT_allDataFromQuery.giveValueByIndex("thisWrite")!=null)
										attributes+="w";
									if (MyHT_allDataFromQuery.giveValueByIndex("thisCreate")!=null)
										attributes+="c";
									if (MyHT_allDataFromQuery.giveValueByIndex("thisList")!=null)
										attributes+="l";

									if (MyHT_allDataFromQuery.giveValueByIndex("thisSubdir")!=null)
										newPermissionPath+="*";

									if (i_lengthAllPermissions==0)	//If no permissions already exists...
									{
										DF_user.setValue("PERMISSIONS",newPermissionPath+";"+attributes);
									}
									else	//If permissions already exists and we shall append to the list
									{
										DF_user.setValue("PERMISSIONS",UD_user.getPermissionsString()+","+newPermissionPath+";"+attributes);
									}
									DF_user.destroy();
									DF_user=null;
									UD_userDatabase.updateDatabase();

									returnThisPage(s_dataFolder+"WizSetPermissions.html", "text/html");
									ShowFTPSetupPages.showPermissionsInfo(theOutput, UD_userDatabase.getUserData(s_userValue));

								}
								else
								{
									returnThisPage(s_dataFolder+"WizSetPermissions.html", "text/html");
									ShowFTPSetupPages.showPermissionsInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
									ShowFTPSetupPages.showAlertInfo(theOutput, "You have already shared this directory and set permissions for it.");
								}
							}
							else
							{
								returnThisPage(s_dataFolder+"WizSetPermissions.html", "text/html");
								ShowFTPSetupPages.showPermissionsInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
								ShowFTPSetupPages.showAlertInfo(theOutput, "The directory was not shared.\\nThe directory path you have entered is not a path to a valid directory.");
							}
						}
						else if (s_typeValue.equals("addAlias"))
						{
							UserData UD_user=UD_userDatabase.getUserData(s_userValue);
							String [] as_aliasesPath, as_aliasesName;
							as_aliasesName=UD_user.getAliasesName();
							as_aliasesPath=UD_user.getAliasesPath();
							String newAliasName=MyHT_allDataFromQuery.giveValueByIndex("newAliasName");
							String newAliasPath=ValidateInput.makeValidPath(MyHT_allDataFromQuery.giveValueByIndex("newAliasPath"));

							if (!MyString.stringExistInArrayIgnoreCase(newAliasName,as_aliasesName))
							{
								if (ValidateInput.isValidAliasName(newAliasName))
								{
									if (ValidateInput.isValidPath(newAliasPath))
									{
										if (as_aliasesName.length==0)	//If no aliases already exists...
										{
											DF_user.setValue("ALIASES",newAliasName+"="+newAliasPath);
										}
										else	//If aliases already exists and we shall append to the list
										{
											DF_user.setValue("ALIASES",UD_user.getAliasString()+","+newAliasName+"="+newAliasPath);
										}
										DF_user.destroy();
										DF_user=null;
										UD_userDatabase.updateDatabase();

										returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
										ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
									}
									else
									{
										returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
										ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
										ShowFTPSetupPages.showAlertInfo(theOutput, "The new alias was not created.\\nThe alias path you have entered is not a path to a valid directory.");
									}
								}
								else
								{
									returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
									ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
									ShowFTPSetupPages.showAlertInfo(theOutput, "The new alias was not created because the alias name given was not a valid alias name.\\nAn alias name shall only contain letters, digits and underscores (_).");
								}
							}
							else
							{
								returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
								ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
								ShowFTPSetupPages.showAlertInfo(theOutput, "The alias name given does already exists.\\nPlease choose another alias name.");
							}
						}
						else if (s_typeValue.equals("removeAlias"))
						{
							UserData UD_user=UD_userDatabase.getUserData(s_userValue);
							String [] as_aliasesPath, as_aliasesName;
							as_aliasesName=UD_user.getAliasesName();
							as_aliasesPath=UD_user.getAliasesPath();
							String s_newAlias="";
							String tmpRemoveThese=MyHT_allDataFromQuery.giveValueByIndex("removeThese");
							String [] s_removeThese;
							if (tmpRemoveThese!=null)
							{
								s_removeThese=MyString.makeArrayOfString(tmpRemoveThese,",");

								for (int i=0; i<as_aliasesName.length; i++)
								{
									if (!MyString.stringExistInArrayIgnoreCase(as_aliasesName[i],s_removeThese))
									{
										s_newAlias+=as_aliasesName[i]+"="+as_aliasesPath[i]+",";
									}
								}

								if (!s_newAlias.equals(""))
								{
									s_newAlias=s_newAlias.substring(0,s_newAlias.length()-1);	//Remove last comma (,)
								}

								DF_user.setValue("ALIASES",s_newAlias);
								DF_user.destroy();
								DF_user=null;
								UD_userDatabase.updateDatabase();

								returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
								ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
							}
							else
							{
								ShowFTPSetupPages.showInvalidrequest(theOutput);
							}
						}
						else if (s_typeValue.equals("password"))
						{
							if (!s_userValue.equals("guest") || s_newValue==null)
							{
								if (s_newValue.equals(MyHT_allDataFromQuery.giveValueByIndex("password2")) &&
									!s_newValue.equals(""))
								{
									DF_user.setValue("PASSWORD",s_newValue);
									DF_user.destroy();
									DF_user=null;
									UD_userDatabase.updateDatabase();

									returnThisPage(s_dataFolder+"WizDataSaved.html", "text/html");
								}
								else
								{
									returnThisPage(s_dataFolder+"WizSetPassword.html", "text/html");
									ShowFTPSetupPages.showPasswordInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
									ShowFTPSetupPages.showAlertInfo(theOutput, "Passwords did not match or empty password given.\\nPassword was not saved!");
								}
							}
							else	//else guest can not be choosen
							{
								ShowFTPSetupPages.showInvalidrequest(theOutput);
							}
						}
						else if (s_typeValue.equals("copy"))
						{
								if (ValidateInput.isValidUserName(s_newValue))	//We create a valid account name...
								{
									boolean b_resultFromAction=DF_user.copyFile(s_userFolder+s_newValue+s_userDataExtension);
									DF_user.destroy();
									DF_user=null;
									UD_userDatabase.updateDatabase();

									returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
									ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());

									if (!b_resultFromAction)
									{
										ShowFTPSetupPages.showAlertInfo(theOutput, "Could not create new account file.\\nThe reason might be that there already exists an account with the same account name.");
									}
								}
								else	//An invalid name has been choosen
								{
									returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
									ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());
									ShowFTPSetupPages.showAlertInfo(theOutput, "The new account was not created.\\nAn account name shall only contain letters, digits and underscores (_).");
								}
						}
						else if (s_typeValue.equals("rename"))
						{
							if (!s_userValue.equals("guest"))
							{
								if (ValidateInput.isValidUserName(s_newValue))	//We rename to a valid name...
								{
									boolean b_resultFromAction=DF_user.renameFile(s_userFolder+s_newValue+s_userDataExtension);
									DF_user.destroy();
									DF_user=null;
									UD_userDatabase.updateDatabase();

									returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
									ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());

									if (!b_resultFromAction)
									{
										ShowFTPSetupPages.showAlertInfo(theOutput, "Could not rename account file.\\nThe reason might be that there already exists an account with the same name.");
									}
								}
								else	//An invalid name has been choosen
								{
									returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
									ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());
									ShowFTPSetupPages.showAlertInfo(theOutput, "The account name was not renamed.\\nAn account name shall only contain letters, digits and underscores (_).");
								}
							}
						}
						else if (s_typeValue.equals("addUser"))
						{
							String s_root=ValidateInput.makeValidPath(MyHT_allDataFromQuery.giveValueByIndex("root"));
							String s_password1=MyHT_allDataFromQuery.giveValueByIndex("password1");
							String s_password2=MyHT_allDataFromQuery.giveValueByIndex("password2");
							if (ValidateInput.isValidPath(s_root))
							{
								if (s_password1!=null && s_password1.equals(s_password2) && !s_password1.equals(""))
								{
									boolean b_fileAlreadyExists=DF_user.fileExists();
									boolean b_resultFromAction=DF_user.createNewFile();

									returnThisPage(s_dataFolder+"WizAddNewUser.html", "text/html");

									if (b_fileAlreadyExists)
									{
										ShowFTPSetupPages.showAlertInfo(theOutput, "This user already exists.\\nPlease choose another username.");
									}
									else if (b_resultFromAction)
									{
										DF_user.addNewLine();
										DF_user.addNewLine();
										DF_user.addNewComment("User password");
										DF_user.addNewValue("PASSWORD",s_password1);
										DF_user.addNewLine();
										DF_user.addNewLine();
										DF_user.addNewComment("Your root");
										DF_user.addNewValue("ROOT",s_root);
										DF_user.addNewLine();
										DF_user.addNewComment("Your shared folders and with what permissions");
										DF_user.addNewValue("PERMISSIONS","");
										DF_user.addNewLine();
										DF_user.addNewComment("Your aliases");
										DF_user.addNewValue("ALIASES","");
										DF_user.addNewLine();
										DF_user.addNewLine();

										ShowFTPSetupPages.showReloadUserFrame(theOutput);
										ShowFTPSetupPages.showAlertInfo(theOutput, "New account created!\\nFeel free to change settings for this account in the menu.");
									}
									else
									{
										ShowFTPSetupPages.showAlertInfo(theOutput, "Xerver could not create new account.\\nFile access denied.");
									}

									DF_user.destroy();
									DF_user=null;
									UD_userDatabase.updateDatabase();
								}
								else
								{
									returnThisPage(s_dataFolder+"WizAddNewUser.html", "text/html");
									ShowFTPSetupPages.showAlertInfo(theOutput, "The account was not created.\\nYou have entered two different passwords or an empty password.");
								}
							}
							else
							{
								returnThisPage(s_dataFolder+"WizAddNewUser.html", "text/html");
								ShowFTPSetupPages.showAlertInfo(theOutput, "The account was not created.\\nThe root you have entered is not a path to a valid directory.");
							}
						}
						else if (s_typeValue.equals("remove"))
						{
							if (!s_userValue.equals("guest"))
							{
								boolean b_resultFromAction=DF_user.deleteFile();
								DF_user.destroy();
								DF_user=null;
								UD_userDatabase.updateDatabase();

								returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
								ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());

								if (!b_resultFromAction)
								{
									ShowFTPSetupPages.showAlertInfo(theOutput, "Xerver could not remove account.\\nFile access denied.");
								}
							}
							else	//else guest can not be choosen
							{
								ShowFTPSetupPages.showInvalidrequest(theOutput);
							}
						}
					}
					else	//An invalid request has been made...
					{
						ShowFTPSetupPages.showInvalidrequest(theOutput);
					}
				}
				else if (s_actionValue.equals("chooseDirectory"))
				{
					showHeaderData("text/html");
					LSListing.showChooseDirectory(theOutput,MyHT_allDataFromQuery.giveValueByIndex("currentPath"));	//Note: "MyHT_allDataFromQuery.giveValueByIndex("currentPath")" might be null. If it's null it means the root shall be showed.
				}
				else if (s_actionValue.equals("wizardEmpty"))
				{
					returnThisPage(s_dataFolder+"WizEmpty.html", "text/html");
				}
				else if (s_actionValue.equals("wizardGeneralSettings"))
				{
					returnThisPage(s_dataFolder+"WizGeneralSettings.html", "text/html");
					ShowFTPSetupPages.showGeneralInfo(theOutput, FTPS_settings);
				}
				else if (s_actionValue.equals("wizardAdvancedSettings"))
				{
					returnThisPage(s_dataFolder+"WizAdvancedSettings.html", "text/html");
					ShowFTPSetupPages.showAdvancedInfo(theOutput, FTPS_settings);
				}
				else if (s_actionValue.equals("wizardAddUserIntro"))
				{
					returnThisPage(s_dataFolder+"WizAddUserIntro.html", "text/html");
				}
				else if (s_actionValue.equals("wizardAddNewUser"))
				{
					returnThisPage(s_dataFolder+"WizAddNewUser.html", "text/html");
				}
				else if (s_actionValue.equals("wizardChooseUser"))
				{
					returnThisPage(s_dataFolder+"WizChooseUser.html", "text/html");
					ShowFTPSetupPages.showChooseUserScript(theOutput, UD_userDatabase.getAllUsers());
				}
				else if (s_actionValue.equals("wizardSetRoot"))
				{
					returnThisPage(s_dataFolder+"WizSetRoot.html", "text/html");
					ShowFTPSetupPages.showRootInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
				}
				else if (s_actionValue.equals("wizardSetAliases"))
				{
					returnThisPage(s_dataFolder+"WizSetAliases.html", "text/html");
					ShowFTPSetupPages.showAliasesInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
				}
				else if (s_actionValue.equals("wizardSetPermissions"))
				{
					returnThisPage(s_dataFolder+"WizSetPermissions.html", "text/html");
					ShowFTPSetupPages.showPermissionsInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
				}
				else if (s_actionValue.equals("wizardSetPassword"))
				{
					returnThisPage(s_dataFolder+"WizSetPassword.html", "text/html");
					ShowFTPSetupPages.showPasswordInfo(theOutput, UD_userDatabase.getUserData(s_userValue));
				}
				else if (s_actionValue.equals("wizardUserFrames"))
				{
					returnThisPage(s_dataFolder+"WizUserFrames.html", "text/html");
				}
				else if (s_actionValue.equals("wizardMenu"))
				{
					returnThisPage(s_dataFolder+"WizMenu.html", "text/html");
				}
				else if (s_actionValue.equals("wizardFrames"))
				{
					returnThisPage(s_dataFolder+"WizFrames.html", "text/html");
				}
				else if (s_actionValue.equals("showLogo"))
				{
					returnThisPage(s_dataFolder+"imagelogo.gif", "image/gif");
				}
				else if (s_actionValue.equals("showBigWizard"))
				{
					returnThisPage(s_dataFolder+"imagewizardbig.gif", "image/gif");
				}
				else if (s_actionValue.equals("showSmallWizard"))
				{
					returnThisPage(s_dataFolder+"imagewizardsmall.gif", "image/gif");
				}
				else if (s_actionValue.equals("showImageRecycleBin"))
				{
					returnThisPage(s_dataFolder+"imagerecyclebin.gif", "image/gif");
				}
				else if (s_actionValue.equals("showWizardHelp"))
				{
					returnThisPage(s_dataFolder+"WizardHelp.html", "text/html");
				}
				else if (s_actionValue.equals("showStyleSheets"))
				{
					returnThisPage(s_dataFolder+"style.css", "text/css");
				}
				else	//else guest can not be choosen
				{
					ShowFTPSetupPages.showInvalidrequest(theOutput);
				}
			}
			else
			{
				returnThisPage(s_dataFolder+"IndexPage.html", "text/html");		//No "action" has been set
			}


			yield();
			sleep(125);	//Be safe, don't close before all data has been sent

			theOutput.flush();
			theOutput.close();
		} catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getRequestInformation:\n"+e);}
	}


	void getRequestInformation()// throws IOException
	{
		try {
			String [] firstLineIndata;

			br_theInputWeGetFromBrowser = new BufferedReader(new InputStreamReader(so_userConnection.getInputStream()));
			firstLineIndata=MyString.makeArrayOfString(br_theInputWeGetFromBrowser.readLine()," ");	//Opera:	"GET /mapp/fil.txt HTTP/1.1"
			s_requestMethod=firstLineIndata[0];	//"GET" eller "GET/"

			s_requestDocument=firstLineIndata[1];

			if (s_requestDocument.startsWith("/?"))
				s_allData=s_requestDocument.substring(2);	//Ignore the first /?, but get everything else
			else
				s_allData=s_requestDocument.substring(1);	//Ignore the first /, but get everything else

		} catch (Exception e) {if (b_showErrors)System.out.println("An error occured @ getRequestInformation:\n"+e.getMessage());}
	}




	private void createVariables()	//Returns true if everything went OK
	{
		MyHT_allDataFromQuery=new MyHashTable(s_allData, "&", "=");
		MyHT_allDataFromQuery.unescapeMakePlusesIntoSpacesAllValues();
		getSettingsFromFile();
	}



	private void getSettingsFromFile()
	{
		try {
			if (FTPS_settings==null)
				FTPS_settings=FTPServer.getFTPSettings();

			UD_userDatabase=FileAccess.getDataBase();
			if (UD_userDatabase==null)
			{
				FileAccess.createDataBase();
				UD_userDatabase=FileAccess.getDataBase();
			}
		}	catch (Exception e) { if (b_showErrors)System.out.println("An error occured @ getSettingsFromFile:\n"+e.getMessage());}
	}



	private void showHeaderData(String contentType)
	{
		try
		{
			theOutput.writeBytes("HTTP/1.1 "+s_errorStatus+" \r\nDate: "+df_dateFormat.format(d_dateToday)+" \r\n"+
               "Server: "+XerverKernel.getXerverName()+" \r\nConnection: close \r\n"+
               "Pragma: no-cache \r\nCache-Control: no-cache \r\n"+
               "Location: / \r\n"+
               "Content-Type: "+contentType+" \r\n\r\n");
		}	catch (Exception e) { if (b_showErrors)System.out.println("An error occured @ returnThisPage:\n"+e.getMessage());}
	}



	private void returnThisPage(String documentToReturn, String contentType)// throws IOException
	{
		FileInputStream fileStreamed=null;

		try
		{
			showHeaderData(contentType);
			File theFile=new File(documentToReturn);
			fileStreamed=new FileInputStream(theFile);

			byte [] myBuffer = new byte[8192];
			int n;
			while ((n=fileStreamed.read(myBuffer))!=-1)
				theOutput.write(myBuffer,0,n);

			yield();
			sleep(125);	//Be safe, don't close before all data has been sent

			//fileStreamed.close();
		}	catch (Exception e) { if (b_showErrors)System.out.println("An error occured @ returnThisPage:\n"+e.getMessage());}

		try
		{
			if (fileStreamed!=null)	//If fileStreamed "holds" a file
			{
				fileStreamed.close();	//Important: This must be reached no matter what! Even if an exception occurs in the try block, whis must be reached. Otherwise the file will be locked by Xerver (locked by Java.exe) until the garbage collector is runned (and you don't know when it will run) and detects that the file (the object "fileStreamed") is no longer referenced from anywhere else and it release the file by automatic. Until this happenes, no other application can write to or rename this file (however, this problem is solved with this line).
			}
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}
	}
}

