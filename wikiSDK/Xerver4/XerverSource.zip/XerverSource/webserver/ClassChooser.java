//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import javax.swing.*;
import webserver.*;
import ftp_server.*;
import common.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class allows users to start several different classes while running the jar-file
 * by passing on parameters to this class.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class ClassChooser
{
	private static boolean b_printOutput=false;



	/**
	* Depending on what argument we get, we will start different classes.
	*/
	public static void main(String [] s)
	{
		try {
			UIManager.setLookAndFeel(
			"com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); //Try to use Windows interface
		}
		catch (Exception e) { }

		if (s.length==0)
		{
			new Start();
		}
		else
		{
			if (s[0].equalsIgnoreCase("Setup"))
				startSetup(getArrayExceptFirstArgument(s));
			else if (s[0].equalsIgnoreCase("Server"))
				startServer(getArrayExceptFirstArgument(s));
			else if (s[0].equalsIgnoreCase("FTPSetup"))
				startFTPSetup(getArrayExceptFirstArgument(s));
			else if (s[0].equalsIgnoreCase("FTPServer"))
				startFTPServer(getArrayExceptFirstArgument(s));
			else
			{
				System.out.println("Valid arguments are:");
				System.out.println("Server    - Start Web Server");
				System.out.println("Setup     - Web Server Setup");
				System.out.println("FTPServer - Start FTP Server");
				System.out.println("FTPSetup  - FTP Server Setup");
			}
		}
	}





	/**
	* Returns an array which does not contain the first element. ([1,2,3] ==> [2,3])
	*/
	private static String [] getArrayExceptFirstArgument(String [] o1)
	{
		if (o1.length==0)
		{
			return null;
		}
		else
		{
			String [] o2=new String[o1.length-1];

			for (int i=0; i<o1.length-1; i++)
			{
				o2[i]=o1[i+1];
			}

			return o2;
		}
	}



	private static void startServer(String [] s)
	{
		boolean b_startServer=true;
		b_printOutput=true;
		int choice=-1;


		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].equals("-nw"))
				{
					choice=0;
				}
				else if (s[i].startsWith("-s"))
				{
					try
					{
						choice=Integer.parseInt(s[i].substring(2));
					}
					catch (Exception e)
					{
						b_startServer=false;
						showOutput("Invalid startup mode.");
						showOutput("The flag given should be \"-sX\" where X is 0, 1, 2 or 3.");
					}
				}
				else// if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startServer=false;
					showOutput("Flags:");
					showOutput("-h or -help = Show this help text.");
					showOutput("-nw = is equivalent to -s0");
					showOutput("-sX = Startup mode where X shall be 0, 1, 2 or 3:");
					showOutput("    = 0 means start with no GUI.");
					showOutput("    = 1 means start with a basic AWT-interface.");
					showOutput("    = 2 means start with an advanced Swing-interface (not minimized at startup).");
					showOutput("    = 3 means start with an advanced Swing-interface (minimized at startup).");
				}
			}
		}

		if (choice!=-1 && (choice!=0 && choice!=1 && choice!=2 && choice!=3))
		{
			b_startServer=false;
			showOutput("The flag given should be \"-sX\" where X is 0, 1, 2 or 3.");
		}

		if (b_startServer)
		{
			new Start(choice);
		}
	}


	private static void startSetup(String [] s)
	{
		boolean b_startSetup=true;
		boolean showAWTWindow=true;
		boolean b_startRemote=false;
		int port=-1;
		b_printOutput=true;

		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].equals("-nw"))
				{
					showAWTWindow=false;
				}
				else if (s[i].startsWith("-p"))
				{
					try
					{
						port=Integer.parseInt(s[i].substring(2));
						if (port<=0)
							throw new Exception("Please use a positive integer when you set port.");
					}
					catch (Exception e)
					{
						b_startSetup=false;
						showOutput("Invalid port.");
						showOutput("The flag given should be \"-pXX\" where XX is a port number.");
					}
				}
				else if (s[i].equals("-remote") || s[i].equals("-r"))
				{
					b_startRemote=true;
				}
				else// if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startSetup=false;
					showOutput("Flags:");
					showOutput("-h or -help = Show this help text.");
					showOutput("-nw = Start setup with no GUI.");
					showOutput("-pXX = Start setup on port XX.");
					showOutput("-r or -remote = Allow all IP-addresses to change settings in setup.");
				}
			}
		}

		if (b_startSetup)
		{
			new Thread(new SetupXerverKernel(showAWTWindow, port, b_startRemote)).start();
		}
	}

	private static void startFTPServer(String [] s)
	{
		FTPServer server=null;
		boolean b_startRemote=false;
		boolean b_startServer=true;
		int port=-1;
		b_printOutput=true;

		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].startsWith("-p"))
				{
					try
					{
						port=Integer.parseInt(s[i].substring(2));
						if (port<=0)
							throw new Exception("Please use a positive integer when you set port.");
					}
					catch (Exception e)
					{
						b_startServer=false;
						showOutput("Invalid port.");
						showOutput("The flag given should be \"-pXX\" where XX is a port number.");
					}
				}
				else// if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startServer=false;
					showOutput("Flags:");
					showOutput("-h or -help = Show this help text.");
					showOutput("-pXX = Start FTP server on port XX.");
				}
			}
		}

		if (b_startServer)
		{
			server=new FTPServer(port);
			server.startFTPServer();
			if (!server.getPortError())
			{
				String s_IP=HostInfo.getOuterIPOrLocalhost();
				showOutput("FTPServer is now running.");
				showOutput("Host: "+s_IP);
				showOutput("Port: "+server.getPort());

				server.start();
			}
			else
			{
				if (server.isPortInUse())
					showOutput("Port "+server.getPort()+" is already in use.\nPlease use setup to choose another port.");
				else
					showOutput("Port "+server.getPort()+" is an invalid port number.\nPlease use setup to choose another port number.");
			}
		}
	}




	private static void startFTPSetup(String [] s)
	{
		FTPSetup setup=null;
		boolean b_startRemote=false;
		boolean b_startServer=true;
		int port=FTPSetup.i_portNr;
		b_printOutput=true;
		FTPSetup.b_printOutput=true;	//Note, we must set this to true as well

		if (s.length!=0)
		{
			for (int i=0; i<s.length; i++)
			{
				if (s[i].equals("-p"))
				{
					try
					{
						port=Integer.parseInt(s[i].substring(2));
					}
					catch (Exception e)
					{
						b_startServer=false;
						showOutput("Invalid port.");
						showOutput("The flag given should be \"-pXX\" where XX is a port number.");
					}
				}
				else if (s[i].equals("-remote") || s[i].equals("-r"))
				{
					b_startRemote=true;
				}
				else //if (s[i].equals("-help") || s[i].equals("-h"))
				{
					b_startServer=false;
					showOutput("Flags:");
					showOutput("-h or -help = Show this help text.");
					showOutput("-pXX = Start setup on port XX, not "+FTPSetup.i_portNr+" which is default.");
					showOutput("-r or -remote = Allow all IP-addresses to change settings in setup.");
				}
			}
		}

		if (b_startServer)
		{
			setup=new FTPSetup(port);

			if (!setup.getPortError())
			{
				String s_IP=HostInfo.getOuterIPOrLocalhost();
				showOutput("FTPSetup is now running, please visit:");
				showOutput("http://"+s_IP+":"+port+"/");
			}
			else
			{
				if (setup.isPortInUse())
					showOutput("Port "+port+" is already in use.\nXerver FTP Setup is probably already running.");
				else
					showOutput("Port "+port+" is an invalid port number.\nPlease choose another port number.");
			}
		}

		if (b_startRemote && b_startServer)
		{
			//This inside the other if-statement because here we are 100% sure "setup!=null"... (unnecessary?)
			if (!setup.getPortError())
			{
				showOutput("Remote setup has been started.");
				setup.startFTPSetup();
			}
		}

		if (b_startServer)
			setup.start();
	}




	private static void showOutput(String txt)
	{
		if (b_printOutput)
			System.out.println(txt);
	}
}