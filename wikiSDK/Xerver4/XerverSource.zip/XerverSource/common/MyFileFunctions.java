//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import webserver.*;
import common.*;
import ftp_server.*;
import java.util.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is a class that contains static general purpose File functions.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MyFileFunctions
{

	/**
	* See "getLastModifiedAsFormatedString(File f_string)".
	*/
	public static String getLastModifiedAsFormatedString(String s_file)
	{
		return getLastModifiedAsFormatedString(new File(s_file));
	}


	/**
	* Returns the last modified date of the file with this format: "YYYYMMDDhhmmss".
	* "YYYYMMDDhhmmss": YYYY is the four-digit year, MM is the month from 01 to 12,
	* DD is the day of the month from 01 to 31, hh is the hour from 00 to 23,
	* mm is the minute from 00 to 59, and ss is the second from 00 to 59.
	*/
	public static String getLastModifiedAsFormatedString(File f_string)
	{
		//"YYYYMMDDhhmmss": YYYY is the four-digit year, MM is the month from 01 to 12, DD is the day of the month from 01 to 31, hh is the hour from 00 to 23, mm is the minute from 00 to 59, and ss is the second from 00 to 59.
		MyGregorianCalendar c_lastModified = new MyGregorianCalendar(TimeZone.getTimeZone("GMT"));
		c_lastModified.setTimeInMillis(f_string.lastModified());
		int YYYY = c_lastModified.get(Calendar.YEAR);
		int MM = (c_lastModified.get(Calendar.MONTH)+1);
		int DD = c_lastModified.get(Calendar.DAY_OF_MONTH);
		int hh = c_lastModified.get(Calendar.HOUR_OF_DAY);
		int mm = c_lastModified.get(Calendar.MINUTE);
		int ss = c_lastModified.get(Calendar.SECOND);
		StringBuilder sb = new StringBuilder();
		sb.append(YYYY);
		if (MM<10)sb.append('0');
		sb.append(MM);
		if (DD<10)sb.append('0');
		sb.append(DD);
		if (hh<10)sb.append('0');
		sb.append(hh);
		if (mm<10)sb.append('0');
		sb.append(mm);
		if (ss<10)sb.append('0');
		sb.append(ss);

		return sb.toString();	//Return YYYYMMDDhhmmss
	}


	/**
	* Returns true iff the file or folder exist.
	*/
	public static boolean fileExists(String s_file)
	{
		return fileExists(new File(s_file));
	}

	/**
	* Returns true iff the file or folder exist.
	*/
	public static boolean fileExists(File f_file)
	{
		return f_file.exists();
	}

	/**
	* Returns true iff the File is a directory.
	*/
	public static boolean isDirectory(String s_file)
	{
		return isDirectory(new File(s_file));
	}

	/**
	* Returns true iff the File is a directory.
	*/
	public static boolean isDirectory(File f_file)
	{
		return f_file.isDirectory();
	}
}

