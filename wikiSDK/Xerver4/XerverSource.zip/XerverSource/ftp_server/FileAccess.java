//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class takes a user name and a password and then reads from a UserDatabase to see what permissions this user have.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class FileAccess
{
	static private UserDatabase udb_userDatabase=null;
	private UserData ud_user;
	boolean b_userAndPassOK=false;
	private String [] as_writePermissionDirs;
	private String [] as_readPermissionDirs;
	private String [] as_createPermissionDirs;
	private String [] as_listPermissionDirs;
	private MyHashTableWithPaths MH_allPermissions;
	private static boolean isWindows=File.separatorChar=='\\';
	//private String s_root;

	public FileAccess(String name, String password)
	{
		if (udb_userDatabase==null)
			createDataBase();

		ud_user=udb_userDatabase.getUserData(name);

		if (ud_user!=null)
		{
			if (password.equals(ud_user.getPassword()))	//If [wrong password]...
			{
				b_userAndPassOK=true;
				MH_allPermissions=ud_user.getAllPermissionDirs();
				as_writePermissionDirs=ud_user.getWritePermissionDirs();
				as_readPermissionDirs=ud_user.getReadPermissionDirs();
				as_createPermissionDirs=ud_user.getCreatePermissionDirs();
				as_listPermissionDirs=ud_user.getListPermissionDirs();
			}
			else
			{
				ud_user=null;
			}
		} //else b_userAndPassOK=false;
	}


	public boolean userAndPassOK()
	{
		return b_userAndPassOK;
	}

	public boolean writePermissionOK(String s_file)
	{
		if (s_file==null)
			return false;

		//First check if the OS will give access at all...
		File f_file=new File(s_file);
		if (!f_file.exists())
			f_file=new File(f_file.getParent());
		if (!f_file.canWrite())
		{
			return false;
		}
		//Stop OS check

		s_file=s_file.substring(0,s_file.lastIndexOf(File.separatorChar)+1);

		int i_longestMatchingPath=MH_allPermissions.giveBiggestKeySize(s_file);	//The reason why we have this is to make sure that if we have "c:\*;w,c:\a\;r" and someone visits "c:\a\" he shall NOT have write permissions (because as_writePermissionDirs only contains "c:\*", not "c:\a\". With i_longestMatchingPath we are not able to check that "c:\a\" won't match "c\*" when it comes to write permissions).

		for (int i=0 , sharedPathsLength=as_writePermissionDirs.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=as_writePermissionDirs[i];//.replace('\\','/');

			if (tmpDir.endsWith("*") && i_longestMatchingPath<=tmpDir.length())	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(isWindows,0,s_file,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (isWindows==true ==> case insensitive)]...
					return true;
			}
			else if (pathEQ(tmpDir,s_file) && i_longestMatchingPath<=tmpDir.length())
				return true;
		}
		return false;
	}

	public boolean readPermissionOK(String s_file)
	{
		if (s_file==null)
			return false;

		//First check if the OS will give access at all...
		File f_file=new File(s_file);
		if (!f_file.exists())
			f_file=new File(f_file.getParent());
		if (!f_file.canRead())
		{
			return false;
		}
		//Stop OS check

		s_file=s_file.substring(0,s_file.lastIndexOf(File.separatorChar)+1);

		int i_longestMatchingPath=MH_allPermissions.giveBiggestKeySize(s_file);	//The reason why we have this is to make sure that if we have "c:\*;w,c:\a\;r" and someone visits "c:\a\" he shall NOT have write permissions (because as_writePermissionDirs only contains "c:\*", not "c:\a\". With i_longestMatchingPath we are not able to check that "c:\a\" won't match "c\*" when it comes to write permissions).

		for (int i=0 , sharedPathsLength=as_readPermissionDirs.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=as_readPermissionDirs[i];//.replace('\\','/');

			if (tmpDir.endsWith("*") && i_longestMatchingPath<=tmpDir.length())	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(isWindows,0,s_file,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (isWindows==true ==> case insensitive)]...
					return true;
			}
			else if (pathEQ(tmpDir,s_file) && i_longestMatchingPath<=tmpDir.length())
				return true;
		}
		return false;
	}

	public boolean createPermissionOK(String s_file)
	{
		if (s_file==null)
			return false;

		//First check if the OS will give access at all...
		File f_file=new File(s_file);
		if (!f_file.exists())
			f_file=new File(f_file.getParent());
		if (!f_file.canWrite())
		{
			return false;
		}
		//Stop OS check

		s_file=s_file.substring(0,s_file.lastIndexOf(File.separatorChar)+1);

		int i_longestMatchingPath=MH_allPermissions.giveBiggestKeySize(s_file);	//The reason why we have this is to make sure that if we have "c:\*;w,c:\a\;r" and someone visits "c:\a\" he shall NOT have write permissions (because as_writePermissionDirs only contains "c:\*", not "c:\a\". With i_longestMatchingPath we are not able to check that "c:\a\" won't match "c\*" when it comes to write permissions).

		for (int i=0 , sharedPathsLength=as_createPermissionDirs.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=as_createPermissionDirs[i];//.replace('\\','/');

			if (tmpDir.endsWith("*") && i_longestMatchingPath<=tmpDir.length())	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(isWindows,0,s_file,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (isWindows==true ==> case insensitive)]...
					return true;
			}
			else if (pathEQ(tmpDir,s_file) && i_longestMatchingPath<=tmpDir.length())
				return true;
		}
		return false;
	}

	public boolean listPermissionOK(String s_file)
	{
		if (s_file==null)
			return false;

		//First check if the OS will give access at all...
		File f_file=new File(s_file);
		if (!f_file.exists())
			f_file=new File(f_file.getParent());
		if (!f_file.canRead())
			return false;
		//Stop OS check

		s_file=s_file.substring(0,s_file.lastIndexOf(File.separatorChar)+1);

		int i_longestMatchingPath=MH_allPermissions.giveBiggestKeySize(s_file);	//The reason why we have this is to make sure that if we have "c:\*;w,c:\a\;r" and someone visits "c:\a\" he shall NOT have write permissions (because as_writePermissionDirs only contains "c:\*", not "c:\a\". With i_longestMatchingPath we are not able to check that "c:\a\" won't match "c\*" when it comes to write permissions).

		for (int i=0 , sharedPathsLength=as_listPermissionDirs.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=as_listPermissionDirs[i];//.replace('\\','/');

			if (tmpDir.endsWith("*") && i_longestMatchingPath<=tmpDir.length())	//If you are allowed to view the content of subfolders as well... (if the name ends with an * ("/mapp1/mapp2/*"))
			{
				if (tmpDir.regionMatches(isWindows,0,s_file,0,tmpDir.length()-1))	//If [the first "tmpDir.length()-1" characters of the two strings are equal (isWindows==true ==> case insensitive)]...
					return true;
			}
			else if (pathEQ(tmpDir,s_file) && i_longestMatchingPath<=tmpDir.length())
				return true;
		}
		return false;
	}


	private static boolean pathEQ(String p1, String p2)
	{
		if (isWindows)	//If Windows...
		{
			return p1.equalsIgnoreCase(p2);
		}
		else
		{
			return p1.equals(p2);
		}
	}

	public UserData getUserData()
	{
		return ud_user;
	}

	public boolean isNotAllowedToCreateNewFile(String s_file)
	{
		return !createPermissionOK(s_file) || MyFileFunctions.fileExists(s_file);		//If [We are NOT allowed to create new files] OR [This file name does exists]... (then we are not allowed to create a new file)
	}

	public static UserDatabase getDataBase()
	{
		return udb_userDatabase;
	}

	public static void createDataBase()
	{
		if (udb_userDatabase==null)
			udb_userDatabase=new UserDatabase();
	}
}

