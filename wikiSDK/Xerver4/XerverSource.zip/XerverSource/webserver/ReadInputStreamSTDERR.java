//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;	//new Date();
import java.text.*;	//DateFormat



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class reads the STDERR from a script and sends it to the browser.
 * <BR>
 * <BR>
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>(new ReadInputStreamSTDERR(InputStream argIs, OutputStream argOs, String argScriptLocation, NewConnection argTheNewConnection)).start();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * <CODE>argIs</CODE> = STDERR from a script.
 * <BR>
 * <CODE>argOs</CODE> = Everything written to this will be sent to browser.
 * <BR>
 * <CODE>argScriptLocation</CODE> = Location of script as browser path ("http://server.com/dir1/dir2/file.pl" ==> "/dir1/dir2/")
 * <BR>
 * <CODE>argTheNewConnection</CODE> = this shall be the <CODE>NewConnection</CODE> that belongs to the specific request that started RunScript. We need this to change the value off <CODE>s_errorStatus</CODE> to "500 Internal Server Error" and to run <CODE>addThisHitToLog()</CODE>.
 * <BR>
 * <BR>
 *
 * <B>IMPORTANT:</B> <CODE>argOs</CODE> will be closed ("<CODE>argOs.close()</CODE>") by <CODE>ReadInputStreamSTDERR</CODE> if (and only if) there is data in <CODE>argIs</CODE> (the script has caused an error).
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class ReadInputStreamSTDERR extends ReadInputStream
{
	private DataOutputStream os;
	private final DateFormat df_dateFormat=DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
	private String s_scriptLocation;
	private NewConnection NC_theNewConnection;
	public boolean b_hasSentData=false;	//This must be public! Set this to true if data is found in STDERR, so that ReadInputStreamSTDOUT won't close the outputstream
	private MyInteger whoShallRespond;
	RunScript rs_theRunScript;

	public ReadInputStreamSTDERR()	//now we can Extend ReadInputStream without problem
	{
	}

	public ReadInputStreamSTDERR(InputStream argIs, OutputStream argOs, String argScriptLocation, NewConnection argTheNewConnection, MyInteger argWhoShallRespond, RunScript argTheRunScript)
	{
		whoShallRespond=argWhoShallRespond;
		currentMode=INPUT_MODE;
		is=argIs;
		os=(DataOutputStream)argOs;
		s_scriptLocation=argScriptLocation;
		NC_theNewConnection=argTheNewConnection;
		rs_theRunScript=argTheRunScript;
	}

	public void sendDataInputMode()
	{
		try
		{
			int n;
			byte [] buffer=new byte [8192];
			boolean b_waitForData=true;	//We use this to be able to check for data in the InputStream twice. If we don't find anything the first time we check, we check another time a few milliseconds later
			while (b_waitForData)
			{
				b_waitForData=false;
				while ((n=is.read(buffer))!=-1)
				{
					b_waitForData=true;	//Do the loop only
					if (!b_hasSentData)
					{
						b_hasSentData=true;
						sendHTMLBeforeError();
					}

					if (whoShallRespond.getValue()!=RESPOND_STDOUT)
					{
						NewConnection.totalNumberOfBytesDownloaded+=n;
						os.write(buffer,0,n);
					}
					else
					{
						break;	//If STDOUT is being sent right now, then we stop here and don't send STDERR
					}
					sleep(25);	//Don't remove: without this it might happen that we don't read the complete output (or any output) from the process.
				}
				yield();
				sleep(75);	//Don't remove: without this it might happen that we don't read the complete output (or any output) from the process.
			}

			if (b_hasSentData)	//Only send data if data has been sent to the stream
				sendHTMLAfterError();

		} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendDataInputMode:\n"+e.getMessage());}
	}

	private void sendHTMLBeforeError()
	{
		try {
			if (whoShallRespond.getValue()!=RESPOND_STDOUT)
			{
				whoShallRespond.setValue(RESPOND_STDERR);	//This will make sure so no STDERR is sent to the browser (a reference of "B_hasGotAResponse" is also at ReadInputStreamSTDERR, which will "block" it from sending data now)

				NC_theNewConnection.s_errorStatus="500 Internal Server Error";
				NC_theNewConnection.addThisHitToLog();

				os.writeBytes(""
//					+"HTTP/1.1 500 Internal Server Error \r\n"
					+"HTTP/1.1 200 OK\r\n"		//NOTE!! We are sending a "200 OK", so that Internet Explorers default "500 Internal Server Error" shall not be shown. This is actually not correct according to the HTTP-protocoll, but this make the user see a correct and helpful 500-error page.
					+"Date: "+df_dateFormat.format(new Date())+"\r\n"
					+"Server: "+XerverKernel.getXerverName()+"\r\n"
					+"Connection: close\r\n"
					+"Location: "+s_scriptLocation+"\r\n"
					+"Content-Type: text/html\r\n\r\n"
				+""
				+"<HTML>"
				+"<HEAD>"
				+"<TITLE>Error: 500 Internal Server Error</TITLE>"
				+"</HEAD>"
				+"<BODY BGCOLOR=\"white\" TEXT=\"black\">"
				+"<TABLE BORDER=0 WIDTH=500 CELLPADDING=0 CELLSPACING=0>"
				+"<TR><TD>"
				+"<FONT FACE=\"arial,verdana\">"
				+"<CENTER><H2>Error: 500 Internal Server Error</H2></CENTER>"
				+"</FONT>"
				+"<P>"
				+"<FONT SIZE=\"-1\" FACE=\"arial,verdana\">"
				+"An error occured when the script was executed."
				+"<BR>"
				+"The error output is:"
				+"</FONT>"
				+"<BR>"
				+"<BR>"
				+"<CENTER>"
				+"<TABLE BORDER=1 CELLPADDING=2 CELLSPACING=0 BGCOLOR=\"#cccccc\">"
				+"<TR><TD>"
				+"<PRE>");
			}
		} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendHTMLBeforeError\n"+e);}

	}


	private void sendHTMLAfterError()
	{
		try {
			if (whoShallRespond.getValue()==RESPOND_STDERR)
			{
		os.writeBytes(""
				+"</PRE>"
				+"</TD></TR>"
				+"</TABLE>"
				+"<BR>"
				+"<BR>"
				+"<BR>"
				+"<HR>"
				+"<FONT SIZE=\"-1\" FACE=\"arial,verdana\">"
				+"<CENTER><A HREF=\"http://www.JavaScript.nu/xerver/\">Hosted by Xerver</A></CENTER>"
				+"</FONT>"
				+"</TD></TR>"
				+"</TABLE>"
				+"</BODY>"
				+"</HTML>");

				yield();
				sleep(125);	//Be safe, don't close before all data has been sent

				os.flush();
				os.close();	// os MUST be closed, or the browser will wait for more data. (with netscape: the stop-button will be "clickable" as the browser waits for the server to write more data or to close the connection (we close the connection with this line).
			}
		} catch (Exception e) {exceptionOccured(e);if (b_showErrors)System.out.println("An error has occured @ sendHTMLAfterError\n"+e);}
	}



	private void exceptionOccured(Exception e)
	{
		rs_theRunScript.killProcess();
	}
}

