//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package webserver;
import common.*;
import ftp_server.*;
import java.util.*;


/**
 *
 * <B>How to use:</B>
 * <BR>
 * <CODE>new HitStatistic(String argIP, String argStatusCode, String argFileLocation, String arghitDate, String argFileExtension, String argLoginRealm, String argLoginUserName[, char argSpaceCharacter=' ']);</CODE>
 * <BR>
 * <CODE>new HitStatistic();</CODE>
 * <BR>
 * <BR>
 *
 * <B>More info:</B>
 * <BR>
 * For each request sent to the server (and logging is enabled = the swing interface is used), a <CODE>HitStatistic</CODE> will be created, containing information about the request.
 * <BR>
 * This is in other words a log-entry.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */



final public class HitStatistic
{
	private String IP;
	private String statusCode;
	private String fileLocation;
	private String hitDate;
	private String fileExtension;
	private String loginRealm;
	private String loginUserName;
	public static boolean showIP=true;
	public static boolean showStatusCode=true;
	public static boolean showFileLocation=true;
	public static boolean showHitDate=true;
	public static boolean showFileExtension=true;
	public static boolean showLoginRealm=true;
	public static boolean showLoginUserName=true;
	public static int showLengthIP=30;
	public static int showLengthStatusCode=14;
	public static int showLengthHitDate=15;
	public static int showLengthFileExtension=6;
	public static int showLengthLoginRealm=10;
	public static int showLengthLoginUserName=10;
	private char spaceCharacter;

	HitStatistic()
	{
		this("IP/Host","Status Code","File","Date","Extension","Zone","UserName", '.');
	}


	HitStatistic(String argIP, String argStatusCode, String argFileLocation, Date arghitDate, String argFileExtension, String argLoginRealm, String argLoginUserName)
	{
		this(argIP, argStatusCode, argFileLocation, arghitDate.toString().substring(4,19), argFileExtension, argLoginRealm, argLoginUserName, ' ');
	}

	HitStatistic(String argIP, String argStatusCode, String argFileLocation, String arghitDate, String argFileExtension, String argLoginRealm, String argLoginUserName, char argSpaceCharacter)
	{
		IP=argIP.intern();
		statusCode=argStatusCode.intern();
		fileLocation=argFileLocation;
		hitDate=arghitDate;
		fileExtension=argFileExtension.intern();
		loginRealm=argLoginRealm.intern();
		loginUserName=argLoginUserName.intern();
		spaceCharacter=argSpaceCharacter;
	}

	public String toString()
	{
//hitDate.toString() ==> "Sat Aug 12 02:30:00 PDT 1995"
		StringBuffer strBuf=new StringBuffer();


		if (showIP)
			strBuf.append(MyString.giveStringWithFixLength(IP,showLengthIP,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showStatusCode)
			strBuf.append(MyString.giveStringWithFixLength(statusCode,showLengthStatusCode,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showFileExtension)
			strBuf.append(MyString.giveStringWithFixLength(fileExtension,showLengthFileExtension,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showLoginRealm)
			strBuf.append(MyString.giveStringWithFixLength(loginRealm,showLengthLoginRealm,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showLoginUserName)
			strBuf.append(MyString.giveStringWithFixLength(loginUserName,showLengthLoginUserName,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showHitDate)
			strBuf.append(MyString.giveStringWithFixLength(hitDate,showLengthHitDate,spaceCharacter)).append(spaceCharacter).append(spaceCharacter);
		if (showFileLocation)
			strBuf.append(fileLocation);

		return strBuf.toString();
	}
}


//(1+hitDate.getHours())+":"+(1+hitDate.getMinutes())+":"+(1+hitDate.getSeconds())+" "+hitDate.getDate()+"/"+hitDate.getMonth()+"