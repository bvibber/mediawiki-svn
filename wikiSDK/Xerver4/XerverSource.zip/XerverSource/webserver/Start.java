//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class reads the config file and runs one of these lines:
 * <BR>
 * <CODE>(new Thread(new XerverKernel(true,null))).start();	//no window</CODE>
 * <BR>
 * <CODE>(new Thread(new XerverKernel(false,null))).start();	//awt-window</CODE>
 * <BR>
 * <CODE>new ProgramWindow();	//Swing-window (NOT minimized at startup)</CODE>
 * <BR>
 * <CODE>new ProgramWindow(true);	//Swing-window (minimized at startup)</CODE>
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class Start// extends JFrame implements ActionListener
{
	private int i_howToStartXerver;
	private String hiddenFolder="data"+File.separator;
	private String errorFilesFolder="errorHTML"+File.separator;
	private String s_configFile=hiddenFolder+"Xerver2.cfg";

	public static void main(String [] s)
	{
/*
	    try {
    //    UIManager.setLookAndFeel(
    //        UIManager.getCrossPlatformLookAndFeelClassName());
				UIManager.setLookAndFeel(
    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); //Try to use Windows interface
    } catch (Exception e) { }
*/
		new Start();
	}

 	public Start()
 	{
		this(-1);
	}
 	public Start(int choice)
 	{
		getServerDefaults();

		if (choice!=-1)
		{
			if (choice==0)
			{
				XerverKernel.setInstance(new XerverKernel(true,null));
				XerverKernel.getInstance().start();		//Start with no window
			}
			else if (choice==1)
			{
				XerverKernel.setInstance(new XerverKernel(false,null));
				XerverKernel.getInstance().start();		//Start with a basic AWT-window
			}
			else if (choice==2)
				new ProgramWindow();	//Start with an advanced Swing-window (NOT minimized at startup)
			else if (choice==3)
				new ProgramWindow(true);	//Start with an advanced Swing-window (minimized at startup)
		}
		else
		{
			if (i_howToStartXerver==0)
			{
				XerverKernel.setInstance(new XerverKernel(true,null));
				XerverKernel.getInstance().start();		//Start with no window
			}
			else if (i_howToStartXerver==1)
			{
				XerverKernel.setInstance(new XerverKernel(false,null));
				XerverKernel.getInstance().start();		//Start with a basic AWT-window
			}
			else if (i_howToStartXerver==2)
				new ProgramWindow();	//Start with an advanced Swing-window (NOT minimized at startup)
			else if (i_howToStartXerver==3)
				new ProgramWindow(true);	//Start with an advanced Swing-window (minimized at startup)
		}
	}



	/**
	* Read line 12 in the "Xerver2.cfg" file (<CODE>s_configFile</CODE>) and
	* put the (integer) value at that line into <CODE>i_howToStartXerver</CODE>.
	*/
	public void getServerDefaults()
	{
		String tmpStr="";

		//*********READ SETTINGS FROM FILE!*******
		try
		{
			BufferedReader f_setupFileData = new BufferedReader(new FileReader(s_configFile));

			for (int i=1; i<=12; i++)
				tmpStr = f_setupFileData.readLine();	//read line 12 (line 12=information xerver user interface)
				i_howToStartXerver = Integer.parseInt(tmpStr);

			f_setupFileData.close();
		}
		catch (Exception e)
		{
			System.out.println("An error occured!\nPlease make sure that "+s_configFile+" is in the data-directory (in your Xerver folder).\n"+e);
			System.exit(0);
		}
	}
}