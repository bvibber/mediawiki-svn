//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.text.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is the kernel for the setup program (and it's a <CODE>Thread</CODE>). This class creates all <CODE>Thread</CODE>s (<CODE>SetupNewConnection</CODE>) that are used when a request is sent to the setup server. Instead of starting this class, start <CODE>SetupXerver</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class SetupXerverKernel extends Thread
{
	private final static boolean b_showErrors=false;
	private static int i_portNr=32123;
	private MyWindow theWindow;
	private boolean b_showAWTWindow=true;
	private MenuOptions myMenuOptions=null;	//This will remain null if you for example start Xerver directly from SetupXerver.class. However, if you start Xerver from the swing interface this will NOT be null.
	private boolean xerverSetupHasStarted=false, b_hasStartedXerver=false;	//use b_hasStartedXerver to make sure no more than one instance of Xerver is started ("new Start();" is run when this setup has been started from InstallXerver, but shall never be run twice (or the user will see two Xerver-windows))
	protected boolean b_show401NotAuthorized=true;

	SetupXerverKernel()
	{
		Locale.setDefault(new Locale("en", "US"));	//I "java.util.*"
		//By default only the own computer shall be able to reach the setup:		startXerverSetup();
	}

	SetupXerverKernel(MenuOptions argMenuOptions)
	{
		b_showAWTWindow=false;	//Don't show Xerver window when starting with swing interafce
		myMenuOptions=argMenuOptions;
		//By default only the own computer shall be able to reach the setup:		startXerverSetup();
	}

	SetupXerverKernel(boolean argShowAWTWindow, int argPort, boolean argXerverSetupHasStarted)
	{
		b_showAWTWindow=argShowAWTWindow;
		if (argPort!=-1)
		{
			i_portNr=argPort;
		}
		xerverSetupHasStarted=argXerverSetupHasStarted;
		Locale.setDefault(new Locale("en", "US"));	//I "java.util.*"
		//By default only the own computer shall be able to reach the setup:		startXerverSetup();
	}

	public void run()
	{
	try
	{
		//getServerDefaults();
		ServerSocket myServerSocket = new ServerSocket(i_portNr);

		openWindow();

		if (myMenuOptions==null)	//If the user has no graphical interface (is not using ProgramWindow), then...
		{
			writeManyChar("#", 70);
			writeNiceText("Xerver Setup is running!", 64);
			writeNiceText("To start Setup you must visit:", 64);
			writeNiceText("Local IP: http://"+HostInfo.getLocalIP()+":"+i_portNr+"/", 64);
			writeNiceText("or", 64);
			writeNiceText("Outer IP: http://"+HostInfo.getOuterIP()+":"+i_portNr+"/", 64);
			writeManyChar("#", 70);
		}

		Socket so_userConnection;//create this ONCE outside the loop... (it's faster...)
		while(true)	//IMPORTANT!!! make sure this loop won't go around too many times without doing anything or java will use up to 100% CPU. Instead let the loop be halted by for example an accept call which will wait for a network connection to be established...
		{
			try
			{
				so_userConnection=myServerSocket.accept();	//Wait until first connection has been established
				so_userConnection.setSoTimeout(5000);
//				System.out.println(InetAddress.getLocalHost());
//				System.out.println(so_userConnection.getLocalAddress());
				if (xerverSetupHasStarted || so_userConnection.getLocalAddress().equals(so_userConnection.getInetAddress()))
				{
					SetupNewConnection myNewConnection = new SetupNewConnection(so_userConnection, this);
					myNewConnection.start();
				}
			}
			catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ run\n"+e);}
		}
	}
	catch (Exception e)
	{
		if (b_showAWTWindow)
		{
			theWindow=new MyWindow(530,300,"Xerver: An error occured");
			System.out.println("An error occured:\nYou are probably already running Xerver.\nIf you're not running Xerver already you have another application using port "+i_portNr+".\nPlease run the setup and change the port number you are using to another number.");
			theWindow.setBackground(new Color(212,208,200));

			int deltaX=0, deltaY=0;	//To make it easy to adjust there is no specific origo
			theWindow.setFont(new Font("Arial, Verdana", Font.BOLD, 38));
			theWindow.setColor(Color.black);
			theWindow.drawString("X", 22+deltaX, 32+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("erver", 46+deltaX, 32+deltaY);
			theWindow.setColor(Color.gray);
			theWindow.drawString("- an error occured", 152+deltaX, 32+deltaY);

			theWindow.setColor(Color.red);
			theWindow.drawString("X", 20+deltaX, 30+deltaY);
			theWindow.setColor(Color.blue);
			theWindow.drawString("erver", 44+deltaX, 30+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("- an error occured", 150+deltaX, 30+deltaY);


			theWindow.setColor(Color.black);
			theWindow.setFont(new Font("Courier", Font.PLAIN, 12));

			int xKord=5, yKord=50, deltaYKord=13;
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("An error occured:", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("You are probably already running Xerver setup in the background.", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("To start Setup you must visit:", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Local IP: http://"+HostInfo.getLocalIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("or", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Outer IP: http://"+HostInfo.getOuterIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("If you're not running Xerver setup already,", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("try to start the setup again in a few seconds.", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
		}//if
	}//catch
	}//run

	public void startXerverSetup()
	{
		xerverSetupHasStarted=true;
	}

	public void stopXerverSetup()
	{
		xerverSetupHasStarted=false;
	}

	private void openWindow()
	{
		if (b_showAWTWindow)
		{
			theWindow=new MyWindow(530,350,"Xerver setup is running");
			theWindow.setColor(Color.black);
			theWindow.setBackground(new Color(212,208,200));

			int deltaX=0, deltaY=0;	//To make it easy to adjust there is no specific origo
			theWindow.setFont(new Font("Arial, Verdana", Font.BOLD, 38));
			theWindow.drawString("X", 22+deltaX, 32+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("erver", 46+deltaX, 32+deltaY);
			theWindow.setColor(Color.gray);
			theWindow.drawString("setup is running...", 152+deltaX, 32+deltaY);

			theWindow.setColor(Color.red);
			theWindow.drawString("X", 20+deltaX, 30+deltaY);
			theWindow.setColor(Color.blue);
			theWindow.drawString("erver", 44+deltaX, 30+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("setup is running...", 150+deltaX, 30+deltaY);

			theWindow.setColor(Color.black);
			theWindow.setFont(new Font("Courier", Font.PLAIN, 12));

			int xKord=5, yKord=65, deltaYKord=13;

			theWindow.drawString("", xKord, yKord+=deltaYKord);
			theWindow.drawString("", xKord, yKord+=deltaYKord);


			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Xerver Setup is running!", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("To start Setup you must visit:", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Local IP: http://"+HostInfo.getLocalIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("or", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Outer IP: http://"+HostInfo.getOuterIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);

			theWindow.drawString("", xKord, yKord+=deltaYKord);
			theWindow.drawString("", xKord, yKord+=deltaYKord);

			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Close this window when you are done!", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("http://www.JavaScript.nu/xerver/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
		}
	}

	public void setupIsDone(boolean setupIsFinished)
	{
		if (myMenuOptions==null && setupIsFinished)	//If [The setup is finished] and [user interface is NOT being used] ==> Start Xerver!
		{					//Turn off setup...
			if (!b_hasStartedXerver)
			{
//				stopXerverSetup();	//Don't stop the setup-server, as the images on the last setup-website won't be shown
				theWindow.setVisible(false);
				theWindow.dispose();
				new Start();
				b_hasStartedXerver=true;
			}
		}
		else if (myMenuOptions!=null)	//If [user interface is being used]...
			myMenuOptions.xerverSetupIsDone(setupIsFinished);
		//else  [[user interface is NOT being used] and [the setup is NOT finsihed]]...
	}




	private static void writeNiceText(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer("## "+txt);
		int forGoUntil=lengthOfText-txt.length();		//Optimization...
		for (int i=0; i<forGoUntil; i++)
			strBuf.append(" ");
		strBuf.append(" ##");
		System.out.println(strBuf.toString());
	}

	private static void writeManyChar(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer(txt);	//Add the frst here....
		for (int i=1; i<lengthOfText; i++)	//And have "1" here (not "0")
			strBuf.append(txt);
		System.out.println(strBuf.toString());
	}

	private static String returnNiceText(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer("## "+txt);
		int forGoUntil=lengthOfText-txt.length();	//Optimization...
		for (int i=0; i<forGoUntil; i++)
			strBuf.append(" ");
		strBuf.append(" ##");
		return strBuf.toString();
	}

	private static String returnManyChar(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer(txt);	//Add the first txt here....	//Optimization...
		for (int i=1; i<lengthOfText; i++)	//And have "1" here (not "0")
			strBuf.append(txt);

		return strBuf.toString();
	}
}






