//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.lang.Object.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is the kernel for <CODE>Xerver</CODE> (and it's a <CODE>Thread</CODE>). This class creates all threads (<CODE>NewConnection</CODE>) that are used when a request is sent to Xerver. Instead of starting this class, start <CODE>Start.class</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class XerverKernel extends Thread
{
	private static XerverKernel xk_xerverKernelInstance = null;
	private static final double thisVersion=4.31;
	private static final String thisVersionString="4.31";

	private static final String s_xerverName="Xerver/"+getThisVersionString();
	private final boolean b_showErrors=false;
	private static final String hiddenFolder="data"+File.separator;
	private static final String errorFilesFolder="errorHTML"+File.separator;
	private static final String s_configFile=hiddenFolder+"Xerver2.cfg";
	private final static int i_soTimeoutAfterKeepAliveTransfer=5000;
	private static final int i_maxNumberOfActiveConnections=150;	//Note: one normal browser might create more than one connection. A visitor with a *normal* browser might create 1-5 connections (depending on how well the browser uses the "Keep-Alive" connection ability). And yes, this means that if someone creates 150 connections to this server, no one else will be able to connect to us anymore.
	private static ServerSocket myServerSocket;
	private String s_logFile;
	public static int i_portNr;
	public static boolean b_startupWindowMode;	//If this is true, no window will be opened. If this is false, the awt-window will be used. NOTE: When you start this class from the Swing interface, this will be set to true so that the AWT-window won't popup		//When you call the XerverKernel()-constructor this varaiable will be set to true/false depending on what you have choosed in the setup-file: true=[0=you have choosen to run with no "window"]; false=[1 = you have choosen to use a static window (AWT); 2 = you have choosen to use the most advanced interface (with logging) (Swing)]

	/*
	public String [] as_indexNames;
	public String [] as_sharedPaths;
	public String [] as_fileExtensions;
	public String s_rootPath;
	public MyHashTable myHT_runnableExtensions;
	public MyHashTable myHT_allAliases;
	public String [] as_xerverPasswd;
	public boolean b_allowFolderListing;
	public boolean b_allowTheseFileExtensions;
	public boolean b_shareHiddenFiles;
	public boolean b_allowExecuteScript;
	*/

	public boolean xerverHasStarted;
	public static String s_egetIp;
	private MyWindow theWindow;
	public MenuOptions myMenuOptions=null;	//This will remain null if, and only if, you run Xerver without the Swing interface. However, if you start Xerver from the swing interface this will NOT be null.
	private ThreadGroup connectionsThreadGroup;//Make all connection-Threads belong to this connection-ThreadGroup. (now we can easy keep track of how many Threads we have alive)


	XerverKernel()	//Run this only if you want the setup-file to decide if the AWT window shall open or not
	{					//When you call the XerverKernel()-constructor "b_startupWindowMode" will be set to true/false depending on what you have choosed in the setup-file: true=[0=you have choosen to run with no "window"]; false=[1 = you have choosen to use a static window (AWT); 2 = you have choosen to use the most advanced interface (with logging) (Swing)]
		Locale.setDefault(new Locale("en", "US"));	//I "java.util.*"
		getServerDefaults();
		initVariables();
		stuffToDoAfterSettingsAreReloaded();	//ALWAYS run this after running "getServerDefaults()"
		startXerver();
		printStartupMessageToConsole();
		openWindow();
	}

	//If you call this constructor with null Xerver will start but without the "Xerver is Running"-window.
	XerverKernel(MenuOptions argMenuOptions)
	{
		this(true,argMenuOptions);
	}

	//If you call this constructor with null Xerver will start but without the "Xerver is Running"-window.
	//if argStartupWindowMode==true, no window will open. If argStartupWindowMode==false an AWT window will popup
	XerverKernel(boolean argStartupWindowMode, MenuOptions argMenuOptions)
	{
		myMenuOptions=argMenuOptions;
		Locale.setDefault(new Locale("en", "US"));	//I "java.util.*"
		getServerDefaults();
		initVariables();
		stuffToDoAfterSettingsAreReloaded();	//ALWAYS run this after running "getServerDefaults()"
		b_startupWindowMode=argStartupWindowMode;	//Also, this overwrites what the Xerver2.cfg says about this variable
		//totalNumberOfHits=0;
		//totalNumberOfBytesDownloaded=0;
		startXerver();
		printStartupMessageToConsole();
		openWindow();
	}

	/**
	* This initializes variables that are set only once, regardless if the settings are changed in the setup.
	* Variables that need to update after the settings are changed should be set in stuffToDoAfterSettingsAreReloaded().
	*/
	private void initVariables()
	{
		try
		{
			/*
			s_egetIp=InetAddress.getLocalHost().toString();	// "pii-450/213.114.143.48"
			s_egetIp=s_egetIp.substring(s_egetIp.indexOf("/")+1);
			*/
			connectionsThreadGroup=new ThreadGroup("Connections");
			s_egetIp=HostInfo.getOuterIPOrLocalhost();

		}
		catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ initVariables\n"+e);}
	}


	public void run()
	{
		while (true)
		{
			try
			{
				Socket so_userConnection;//create this ONCE outside the loop... (it's faster...)
				while (true)	//IMPORTANT!!! make sure this loop won't go around too many times without doing anything or java will use up to 100% CPU. Instead let the loop be halted by for example an accept call which will wait for a network connection to be established...
				{
					NewConnection myNewConnection;
					so_userConnection=myServerSocket.accept();	//Wait until a request is sent to the server (with "myServerSocket.setSoTimeout()" we can limit the time we wait for "accept")
					so_userConnection.setSoTimeout(i_soTimeoutAfterKeepAliveTransfer);	//IMPORTANT: This must be long enough to make sure the Keep-Alive-functionality will work. Lets say this is set to 5000 (5 sec), and a browser starts to download a file which might take 6 sec. After the download is completed the connection will be closed, which means we don't use the smart "Keep-Alive" features. The solution is to set this to 0 (infinity) when the download starts and set this back to 5 secs when the file download is finished.
					if (xerverHasStarted && connectionsThreadGroup.activeCount()<=i_maxNumberOfActiveConnections)	//IF [The browser has started] AND [the maximum number of connections allowed has not been reached]...
					{
						//i_numberOfUsersOnline++;
						myNewConnection = new NewConnection(so_userConnection, connectionsThreadGroup);
						try
						{
							myNewConnection.start();
						}
						catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ run\n"+e);}
					}
					else
					{
						so_userConnection.close();
					}
				}
			}
			catch (Exception e)
			{
				//We will come here when we for example close the ServerSocket
				//(for example when the port has changed in the setup and we need to start listen to a new port).
				try
				{
					Thread.sleep(500);
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	/**
	* Start listen to port "i_portNr".
	* If the port number has not changed and we already are listening to port "i_portNr"
	* then nothing will happen to the ServerSocket, so it's ok to call this many times without
	* interupting the server in any way.
	* This is called both at startup and when settings change due to the setup.
	*/
	private void startListenToPort()
	{
		try
		{
			if (myServerSocket != null)
			{
				if (myServerSocket.getLocalPort() != i_portNr)	//The user has changed what port we shall use, so create a new ServerSocket
				{
					myServerSocket.close();		//Stop listen to the old port. Closing the old ServerSocket will result in that the old thread will die (due to the exception that is thrown in ".run()"), so we need to run ".start()" (".run()") again so that we again start listen to the new port
					myServerSocket = new ServerSocket(i_portNr);
				}
			}
			else
			{
				myServerSocket = new ServerSocket(i_portNr);	//This is the first time we create a ServerSocket at startup
			}
		}
		catch (Exception e)
		{
			if (!b_startupWindowMode || myMenuOptions!=null)	//If [the user shall see all popup windows] OR [the user has a graphical interface (is using ProgramWindow)], then...
			{
				theWindow=new MyWindow(530,200,"Xerver: An error occured");
				System.out.println("An error occured:\nYou are probably already running Xerver.\nIf you're not running Xerver already you have another application using port "+i_portNr+".\nPlease run the setup and change the port number you are using to another number.");
				theWindow.setBackground(new Color(212,208,200));

				int deltaX=0, deltaY=0;	//To make it easy to adjust there is no specific origo
				theWindow.setFont(new Font("Arial, Verdana", Font.BOLD, 38));

				theWindow.setColor(Color.black);
				theWindow.drawString("X", 22+deltaX, 32+deltaY);
				theWindow.setColor(Color.black);
				theWindow.drawString("erver", 46+deltaX, 32+deltaY);
				theWindow.setColor(Color.gray);
				theWindow.drawString("- an error occured", 152+deltaX, 32+deltaY);

				theWindow.setColor(Color.red);
				theWindow.drawString("X", 20+deltaX, 30+deltaY);
				theWindow.setColor(Color.blue);
				theWindow.drawString("erver", 44+deltaX, 30+deltaY);
				theWindow.setColor(Color.black);
				theWindow.drawString("- an error occured", 150+deltaX, 30+deltaY);


				theWindow.setColor(Color.black);
				theWindow.setFont(new Font("Courier", Font.PLAIN, 12));

				int xKord=5, yKord=50, deltaYKord=13;
				theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("An error occured:", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("You are probably already running Xerver.", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("If you're not running Xerver already you have", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("another application using port "+i_portNr+".", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("Please run the setup and change the port number", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnNiceText("you are using to another number.", 64), xKord, yKord+=deltaYKord);
				theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			}
			else
				System.out.println("An error occured:\nYou are probably already running Xerver.\nIf you're not running Xerver already you have\nanother application using port "+i_portNr+".\nPlease run the setup and change the port number\nyou are using to another number.");
		}
	}

	public int getNumberOfActiveConnections()
	{
		return connectionsThreadGroup.activeCount();
	}

	public void startXerver()
	{
		NewConnection.b_acceptConnections=true;
		xerverHasStarted=true;
	}

	public void stopXerver()
	{
		NewConnection.b_acceptConnections=false;
		xerverHasStarted=false;
	}

	/**
	* Print startup message to the console, but only if there is no graphical user interface (using ProgramWindow).
	*/
	private void printStartupMessageToConsole()
	{
		if (myMenuOptions==null)	//If the user has no graphical interface (is not using ProgramWindow), then...
		{
			writeManyChar("#", 70);
			writeNiceText("Xerver, powered with Java Technology, is up and running!", 64);
			writeNiceText("http://www.JavaScript.nu/xerver/", 64);
			writeManyChar("#", 70);
			writeNiceText("Xerver is currently scanning port "+i_portNr+" for new connections.", 64);
			writeNiceText("You may change this in the setup. Enjoy!", 64);
			writeNiceText("Your website is available at:", 64);
			if (i_portNr!=80)
				writeNiceText("Outer IP: http://"+HostInfo.getOuterIP()+":"+i_portNr+"/", 64);
			else
				writeNiceText("Outer IP: http://"+HostInfo.getOuterIP()+"/", 64);
			if (i_portNr!=80)
				writeNiceText("Local IP: http://"+HostInfo.getLocalIP()+":"+i_portNr+"/", 64);
			else
				writeNiceText("Local IP: http://"+HostInfo.getLocalIP()+"/", 64);

// InetAddress.getByName("localhost").toString() == "localhost/127.0.0.1"

			writeNiceText("Your friends can visit your website using the \"Outer IP\".", 64);
			writeManyChar("#", 70);
			System.out.println("");
			System.out.println("");
			writeManyChar("#", 70);
			writeNiceText("IMPORTANT:", 64);
			writeNiceText("If you close this window Xerver will be shut down!", 64);
			writeManyChar("#", 70);
		}
	}

	private void openWindow()
	{
		if (!b_startupWindowMode)	//If the user has no graphical interface (is not using ProgramWindow), then...
		{
			theWindow=new MyWindow(530,350,"Xerver is running");
			//theWindow.killProgramAtShutdown=true;	//true is default

			theWindow.setColor(Color.black);
			theWindow.setBackground(new Color(212,208,200));

			int deltaX=45, deltaY=0;	//To make it easy to adjust there is no specific origo
			theWindow.setFont(new Font("Arial, Verdana", Font.BOLD, 38));
			theWindow.setColor(Color.black);
			theWindow.drawString("X", 22+deltaX, 32+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("erver", 46+deltaX, 32+deltaY);
			theWindow.setColor(Color.gray);
			theWindow.drawString("is running...", 152+deltaX, 32+deltaY);

			theWindow.setColor(Color.red);
			theWindow.drawString("X", 20+deltaX, 30+deltaY);
			theWindow.setColor(Color.blue);
			theWindow.drawString("erver", 44+deltaX, 30+deltaY);
			theWindow.setColor(Color.black);
			theWindow.drawString("is running...", 150+deltaX, 30+deltaY);


			theWindow.setColor(Color.black);
			theWindow.setFont(new Font("Courier", Font.PLAIN, 12));

			int xKord=5, yKord=50, deltaYKord=13;
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Xerver, powered with Java Technology, is up and running!", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("http://www.JavaScript.nu/xerver/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Xerver is currently scanning port "+i_portNr+" for new connections.", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("You may change this in the setup. Enjoy!", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Your website is available at:", 64), xKord, yKord+=deltaYKord);
			if (i_portNr!=80)
				theWindow.drawString(returnNiceText("http://"+HostInfo.getOuterIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			else
				theWindow.drawString(returnNiceText("http://"+HostInfo.getOuterIP()+"/", 64), xKord, yKord+=deltaYKord);
			if (i_portNr!=80)
				theWindow.drawString(returnNiceText("http://"+HostInfo.getLocalIP()+":"+i_portNr+"/", 64), xKord, yKord+=deltaYKord);
			else
				theWindow.drawString(returnNiceText("http://"+HostInfo.getLocalIP()+"/", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("Your friends can visit your website using the \"Outer IP\".", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);

			theWindow.drawString("", xKord, yKord+=deltaYKord);
			theWindow.drawString("", xKord, yKord+=deltaYKord);

			theWindow.setColor(Color.red);

			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("IMPORTANT:", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnNiceText("If you close this window Xerver will be shut down!", 64), xKord, yKord+=deltaYKord);
			theWindow.drawString(returnManyChar("#", 70), xKord, yKord+=deltaYKord);
		}
	}


	public void getServerDefaults()
	{
		//*********READ SETTINGS FROM FILE!*******
		try
		{
			BufferedReader f_setupFileData = new BufferedReader(new FileReader(s_configFile));

			int tmp;
			NewConnection.i_portNr = Integer.parseInt(f_setupFileData.readLine());
			NewConnection.as_indexNames = MyString.makeArrayOfString(f_setupFileData.readLine(),",");
			NewConnection.as_sharedPaths = MyString.makeArrayOfString(f_setupFileData.readLine(),",");
			String tmpStr=f_setupFileData.readLine();
			if (tmpStr!=null)
				tmpStr=tmpStr.toLowerCase();	//File extensions shall be lower case, there is no difference between "html" and "HTML"...
			NewConnection.as_fileExtensions = MyString.makeArrayOfString(tmpStr,",");	//NOTE: always lower case...
			NewConnection.s_rootPath = f_setupFileData.readLine();
			NewConnection.myHT_runnableExtensions = new MyHashTable(f_setupFileData.readLine());
			NewConnection.myHT_allAliases = new MyHashTable(f_setupFileData.readLine());
			NewConnection.as_xerverPasswd = MyString.makeArrayOfString(f_setupFileData.readLine(),"<<$>>");

			tmp = Integer.parseInt(f_setupFileData.readLine());
			if (tmp==1)
				NewConnection.b_allowFolderListing=true;
			else
				NewConnection.b_allowFolderListing=false;

			tmp = Integer.parseInt(f_setupFileData.readLine());
			if (tmp==1)
				NewConnection.b_allowTheseFileExtensions=true;
			else
				NewConnection.b_allowTheseFileExtensions=false;

			tmp = Integer.parseInt(f_setupFileData.readLine());
			if (tmp==1)
				NewConnection.b_shareHiddenFiles=true;
			else
				NewConnection.b_shareHiddenFiles=false;

			tmp = Integer.parseInt(f_setupFileData.readLine());	//Note: today it doesn't matter what we found here, as the XerverKernel()-constructor is never called. However, if, and only if, the XerverKernel()-constructor is called, the value of startupWindowMode will depend on what is found on this line (otherwise, the startupWindowMode is owerwritten by an argument that is sent to the constructor of XerverKernel))
			if (tmp==0)	//note ==0
				NewConnection.b_startupWindowMode=true;
			else
				NewConnection.b_startupWindowMode=false;

			tmp = Integer.parseInt(f_setupFileData.readLine());
			if (tmp==1)
				NewConnection.b_allowExecuteScript=true;
			else
				NewConnection.b_allowExecuteScript=false;

			s_logFile = f_setupFileData.readLine();

			f_setupFileData.close();
		}
		catch (Exception e)
		{
			System.out.println("An error occured!\nPlease make sure that "+s_configFile+" is in the data-directory (in your Xerver folder).\n"+e);
			System.exit(0);
		}
	}

	/**
	* This should be called everytime settings are being changed in the setup (and when Xerver first starts).
	* This helps settings go into effect as soon as the setting is changed and Xerver does not have to restart.
	*/
	public void stuffToDoAfterSettingsAreReloaded()
	{
		/*
		* Copy variables between classes.
		*/
		/* Don't only set to NewConnection but also to this class */
		b_startupWindowMode = NewConnection.b_startupWindowMode;
		i_portNr = NewConnection.i_portNr;

		/* Don't only set to this class but also to NewConnection */
		NewConnection.myMenuOptions=myMenuOptions;

		//Finally set this (which we don't actually read from the file)...
		NewConnection.s_defaultRootLocationWithoutSlashAtEnd=NewConnection.s_rootPath.substring(0,NewConnection.s_rootPath.length()-1);

		//If the port number has changed we want to start listen to the new port (if port has not changed, we will not do anything to the ServerSocket)
		startListenToPort();

		//Start log to the new log file
		NewConnection.l_logFile = new Log(s_logFile);		//s_logFile can be "", and if it is then no logging will be performed
	}

	private static void writeNiceText(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer("## "+txt);
		int forGoUntil=lengthOfText-txt.length();		//Optimization...
		for (int i=0; i<forGoUntil; i++)
			strBuf.append(" ");
		strBuf.append(" ##");
		System.out.println(strBuf.toString());
	}

	private static void writeManyChar(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer(txt);	//Add the first txt here....	//Optimization...
		for (int i=1; i<lengthOfText; i++)	//And have "1" here (not "0")
			strBuf.append(txt);
		System.out.println(strBuf.toString());
	}

	private static String returnNiceText(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer("## "+txt);
		int forGoUntil=lengthOfText-txt.length();	//Optimization...
		for (int i=0; i<forGoUntil; i++)
			strBuf.append(" ");
		strBuf.append(" ##");
		return strBuf.toString();
	}

	private static String returnManyChar(String txt, int lengthOfText)
	{
		StringBuffer strBuf=new StringBuffer(txt);	//Add the first txt here....	//Optimization...
		for (int i=1; i<lengthOfText; i++)	//And have "1" here (not "0")
			strBuf.append(txt);

		return strBuf.toString();
	}

	public static String getXerverName()
	{
		return s_xerverName;
	}

	public static double getThisVersion()
	{
		return thisVersion;
	}

	public static String getThisVersionString()
	{
		return thisVersionString;
	}

	public static XerverKernel getInstance()
	{
		return xk_xerverKernelInstance;
	}

	public static void setInstance(XerverKernel xerverKernel)
	{
		xk_xerverKernelInstance = xerverKernel;
	}
}










