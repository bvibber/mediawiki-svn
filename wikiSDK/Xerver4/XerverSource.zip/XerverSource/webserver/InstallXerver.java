//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
import javax.swing.*;




/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class creates the directories that Xerver needs and moves files into these directories when Xerver is installed.
 * <BR>
 * You can also (safety) run this class when Xerver already has been installed.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class InstallXerver
{
	private String hiddenFolder="data"+File.separator;
	private String errorFilesFolder="errorHTML"+File.separator;
	private String helpFilesFolder="help"+File.separator;
	private final String zipFileName="filesZipped.zip";
	private final static boolean b_showErrors=false;

	public static void main(String [] s)
	{
		    try {
    //    UIManager.setLookAndFeel(
    //        UIManager.getCrossPlatformLookAndFeelClassName());
				UIManager.setLookAndFeel(
    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); //Try to use Windows interface
    } catch (Exception e) { }

		new InstallXerver();
	}

	/**
	* Run the main method to start this constructor which is only used to start an
	* terminal based install program where the user is asked where to install Xerver.
	*/
	InstallXerver()
	{
		String indata=null;
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What do you want to do?");
		System.out.println("[1]  Start Xerver installer (require a graphical interface). (RECOMMENDED)");
		System.out.println("[2]  Install Xerver in the current directory.");
		System.out.println("[3]  I want to enter a location where Xerver shall be installed.");
		System.out.println("");
		do
		{
			System.out.println("Please enter 1, 2, 3 or \"exit\" to quit:");
			try {
				indata=in.readLine();

				if (indata.toLowerCase().equals("exit"))
					System.exit(0);
				else if (indata.equals("1"))
				{
					System.out.println("Starting Xerver installer...");
					new SetupWindow();
					System.out.println("Start Xerver Setup with \"java SetupXerver\".");
					System.out.println("Start Xerver with \"java Start\".");
				}
				else if (indata.equals("2"))
				{
					System.out.println("Installing in progress...");
					new InstallXerver("");
					System.out.println("Installing done!");
					System.out.println("");
					System.out.println("Starting Xerver Setup:");
					new SetupXerver();
				}
				else if (indata.equals("3"))
				{
					System.out.println("Where do you want to install Xerver:");
					String s_installPathEntered=in.readLine();
					File f_installPathEntered=new File(s_installPathEntered);
					if (f_installPathEntered.isDirectory() && !s_installPathEntered.equals(""))
					{
						System.out.println("Installing in progress...");
						new InstallXerver(f_installPathEntered.getPath());
						System.out.println("Installing done!");
						System.out.println("When you are in "+f_installPathEntered.getAbsolutePath()+", you can use these commands:");
						System.out.println("\"java SetupXerver\" - Start Xerver Setup");	//Note, we can't start "new SetupXerver()" automatically as it might not have been installed (extracted) Xerver in the "present working directory"...
						System.out.println("\"java Start\" - Start Xerver");
					}
					else
					{
						indata="dummy value";	//not 1, 2 or 3
						System.out.println(f_installPathEntered.getPath()+" does not exists! Try again!");
					}
				}
			} catch(Exception e){if (b_showErrors)System.out.println("An error occured:\n"+e.getMessage());}
		} while (!indata.equals("1") && !indata.equals("2") && !indata.equals("3"));
	}


	/**
	* This installs Xerver into <CODE>s_installPath</CODE>.
	* Make sure the zip file <CODE>zipFileName</CODE> is located in the "current working directory"
	* (usually the same folder as this class file is located).
	* <CODE>s_installPath</CODE> must be a valid path or "" ("" = install in "present working directory")
	*/
	InstallXerver(String s_installPath)
	{
		if (s_installPath==null)
			s_installPath="";
		else if ((new File(s_installPath)).exists())
			s_installPath=(new File(s_installPath)).getPath()+File.separator;
		else
			s_installPath="";

//		System.out.println("*******************************************");
//		System.out.println("****    Xerver is being installed!     ****");
//		System.out.println("*******************************************");
//		System.out.println("");
//		System.out.print("* Extracting \""+zipFileName+"...\"       ");
		new ExtractZipFileInstall(zipFileName, true, s_installPath);	//true=overwrite files (ExtractZipFileInstall will never owerwrite "xerver2.cfg")
		moveAllFiles(s_installPath);		//In case the user has unzipped the zip-file manually or if someone only got all files coming with the source files in one folder.
//		System.out.println("[ DONE! ]");
//		System.out.println("");
//		System.out.println("* Running Xerver Setup                     [ DONE! ]");
// 		System.out.println("");
// 		(new Thread(new SetupXerverKernel())).start();
//		System.out.println("[NOTE: Visit http://localhost:32123/ now!]");
// 		System.out.println("");
// 		System.out.print("* Starting Xerver                            ");
// 		new Start();
//		System.out.println("[ DONE! ]");
// 		System.out.println("");
// 		System.out.println("* Install is finished!");
	}


	/**
	* Move all files Xerver uses to the correct directories.
	* This is actually not used during a normal install, as
	* <CODE>ExtractZipFileInstall</CODE> takes care of that,
	* but this is useful for example when someone already has extracted all files
	* in one directory and now runs the "java InstallXerver" to move all files to the correct directories.
	*/
	private void moveAllFiles(String s_installPath)
	{
		String [] filesThatShallBeHidden={
"AddAliasSetup.html",
"AddDirSetup.html",
"AddExtSetup.html",
"AddIndSetup.html",
"AddProtDirSetup.html",
"AddProtFrameSetup.html",
"AddProtSetup.html",
"AddProtUserSetup.html",
"AddScriptExtSetup.html",
"empty.html",
"WizGeneralSettings.html",
"WizFrames.html",
"WizMenu.html",
"WizStep1.html",
"WizStep2.html",
"WizStep3.html",
"WizStep4.html",
"WizStep5.html",
"WizStep6.html",
"WizStep7.html",
"WizStep8.html",
"WizStep9.html",
"WizardHelp.html",
"Xerver2.cfg",
"Xerver2.cfg.txt",
"empty.html",
"imagefileicon.gif",
"imagefolder.gif",
"imageinvisible.gif",
"imagelogo.gif",
"imagestartbutton.gif",
"imagestartsetupbutton.gif",
"imagestopbutton.gif",
"imagestopsetupbutton.gif",
"imagewizardbig.gif",
"imagewizardsmall.gif",
"imagexerverlogo.gif"};





		String [] filesThatCanBeEdited={
"error400badrequest.html",
"error401notauthorized.html",
"error403hiddenfilenotshared.html",
"error403noaccessextension.html",
"error403noaccessfolder.html",
"error403nodirectorylisting.html",
"error403webservercantreadfile.html",
"error404filedoesnotexist.html",
"error505unknownhttp.html"};



		String [] helpFiles={
"help403forbidden.html",
"helpcantrunperl.html",
"helpcantrunphp.html",
"helpdifferentrunmodes.html",
"helpfriendscantbrowse.html",
"helpisxerverfree.html",
"helpjavainstalled.html",
"helplowsystemresources.html",
"helpownerrorpages.html",
"helppasswordtofolders.html",
"helpperlhelloworld.html",
"helpperlwontrun.html",
"helpphphelloworld.html",
"helpphpwontrun.html",
"helpproblemwithscripts.html",
"helprunotherscripts.html",
"helprunxerver.html",
"helpstartxerver.html",
"helpuninstall.html",
"helpwhatisxerver.html",
"index.html",
"main.html",
"menu.html"};

		createFolders(s_installPath);
		moveFiles(hiddenFolder, filesThatShallBeHidden, s_installPath);
		moveFiles(errorFilesFolder, filesThatCanBeEdited, s_installPath);
		moveFiles(helpFilesFolder, helpFiles, s_installPath);
	}


	/**
	* This creates all necessary directories for Xerver at <CODE>s_installPath</CODE>.
	* <CODE>s_installPath</CODE> shall be "" if you want create the directories in the "present working directory".
	*/
	private void createFolders(String s_installPath)
	{
			(new File(s_installPath+hiddenFolder)).mkdir();
			(new File(s_installPath+errorFilesFolder)).mkdir();
			(new File(s_installPath+helpFilesFolder)).mkdir();
	}

	/**
	* Moves all files located at <CODE>s_installPath</CODE> and listed in <CODE>filesToHide</CODE> into
	* a folder called <CODE>s_installPath</CODE>+<CODE>folder</CODE>.
	* <CODE>s_installPath</CODE> can, but must not, end with an \ or /.
	* For example: "C:\dir" works as well as "C:\dir\".
	* <CODE>s_installPath</CODE> might be "" if you want to use relative path's
	* (relative from "present working directory") in <CODE>folder</CODE> and <CODE>filesToHide</CODE>.
	*/
	private void moveFiles(String folder, String [] filesToHide, String s_installPath)
	{
		if (s_installPath==null)
			s_installPath="";

		if (s_installPath!="" || (new File(s_installPath)).exists())
		{
			s_installPath=(new File(s_installPath)).getPath()+File.separator;
			for (int i=0, filesToHideLength=filesToHide.length; i<filesToHideLength; i++)	//Optimization...
			{
				File theFile=new File(s_installPath+filesToHide[i]);
				if (theFile.exists() && theFile.isFile())	//Om filen man ska flytta finns
				{
					File theFileToReplace=new File(s_installPath+folder+filesToHide[i]);
					if (theFileToReplace.exists() && !filesToHide[i].toLowerCase().equals("xerver2.cfg"))	//If a file already exists (and if it isn't "xervers2.cfg"), remove it... (so you don't have to remove it manually when you update Xerver; However, do not replace "Xerver2.cfg", as it's a data file)
					{
						theFileToReplace.delete();
					}
					theFile.renameTo(new File(s_installPath+folder+filesToHide[i]));	//Flytta filen
				}
				//else	the file doesn't exists, which means that the installation has already been done
			}
		}
	}
}
