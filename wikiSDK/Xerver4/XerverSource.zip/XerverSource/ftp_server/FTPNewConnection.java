//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.net.*;
import java.util.*;




/**
 *
 * <B>About this class:</B>
 * <BR>
 * For each user that connects to the server, one <CODE>FTPNewConnection</CODE> will be created.
 * <BR>
 * This is the most important class for the FTP server.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class FTPNewConnection extends Thread
{
	//Global vars
	private static final boolean b_showErrors=false;
	private boolean b_correctUserName=false;
	private boolean b_correctPassword=false;
	private boolean b_binaryFlag=false;
	private boolean isAlive=true;
	private FTPDataConnection FTPDC_dataConnection;
	private Socket so_userConnection;
	private DataOutputStream bos;
	private String s_userName, s_password;
	private DataInputStreamWithReadLine bis;
	//private BufferedReader bis;
//	File f_currentFolder;
	private String s_root=null;
	private String s_currentRelativePath=File.separator;	//  ="\\";
	//private String s_lastCommand="";	//Shall be a nonexisting command. Shall not be null!
	private File f_fileToRenameWithRNFR=null;
	private int i_startPosition;
	private int i_permissionLevel=NO_PERMISSIONS;
	private FileAccess fa_permissions=null;
	private UserData ud_userdata;
	private String [] as_aliasesName;
	private String [] as_aliasesPath;
	private String s_usersIPNumber;
	private long l_timeForLastCommand=System.currentTimeMillis();
	private int i_countNOOP=0;
	private boolean b_isLocalConnection;
	private static int i_globalConnectionID = 0;	//Increment this for each new FTPNewConnection we create and assign each connection we have a unique ID
	private int i_connectionID;	//This is the unique ID for this FTPNewConnection. The first connection has value 1, the second 2, etc...

	public static boolean b_guestAccountExists=true;
	public static final int i_timeForClientToTakeDataConnedtion=25000;	//Wait 2 secs for client to take the data connection direct after a command when the data connection is going to be used.
	public static String s_serverOuterIP;
	public static String s_serverLocalIP;
	public static int i_maxTimeToIdle;
	public static int i_maxNumberOfNOOP;
	private final static int SHOW_ONLY_ALIASES=0;
	private final static int SHOW_NO_ALIASES=1;
	private final static int SHOW_ALIASES_AND_DIRS=2;
	private final static int NO_PERMISSIONS=-1;
	private final static int PASSWORD_ACCEPTED=5;
	public static int i_howToShowAlias=SHOW_ALIASES_AND_DIRS;
	public static Log l_logFile = null;


	public FTPNewConnection(Socket argUserConnection)
	{
		so_userConnection=argUserConnection;
		initVarsBeforeRun();
	}

	public void run()
	{
		try
		{
			initVarsAfterRun();
			sendWelcomeMessage();
			//getUserInfo();
			readRequestes();
		} catch (Exception e){showError(e);}
	}

	private void initVarsBeforeRun()
	{
		try
		{
			b_isLocalConnection =	so_userConnection.getInetAddress().isLinkLocalAddress() ||	//Ex. 169.254.100.254
									so_userConnection.getInetAddress().isLoopbackAddress() ||	//Ex. 127.0.0.1
									so_userConnection.getInetAddress().isSiteLocalAddress();	//Ex. 192.168.0.100
			s_usersIPNumber=so_userConnection.getInetAddress().getHostAddress();
			i_connectionID = ++i_globalConnectionID;	//Assign this connection a unique ID to show in log file (note that "++i_globalConnectionID" should actually be synchronized to be thread safe)

		} catch (Exception e){showError(e);}
	}

	private void initVarsAfterRun() throws Exception
	{
		bos=new DataOutputStream(new BufferedOutputStream(so_userConnection.getOutputStream()));
		bis=new DataInputStreamWithReadLine(new BufferedInputStream(so_userConnection.getInputStream()));
		//bis=new BufferedReader(new InputStreamReader(so_userConnection.getInputStream()));
	}


	private void readRequestes() throws Exception
	{
		String cmd;
		int cmdIndexOf;
		while (isAlive && FTPServer.isAlive)
		{
			cmd=bis.myReadLine(512);

			if (!cmd.equals(""))
			{
				cmd=cmd.trim();

				cmdIndexOf=cmd.indexOf(" ");
				if (cmdIndexOf!=-1)	//Argument exists
				{
					doCommand(	cmd.substring(0,cmdIndexOf),
								cmd.substring(cmdIndexOf+1));
				}
				else
				{
					doCommand(cmd, null);
				}
			}
			else if (disconnectBecauseIdleTime())
			{
				sendResponse("221 Bye. You have been idle for a long time now.\r\n");
			}
			else
			{
				yield();
				sleep(250);
			}
		}

		if (FTPDC_dataConnection!=null)
		{
			FTPDC_dataConnection.stopListenToPortAndKillCurrentConnection();
			FTPDC_dataConnection = null;
		}
		so_userConnection.close();
	}


	private boolean disconnectBecauseIdleTime() throws Exception
	{
		if ((i_maxTimeToIdle!=0 && l_timeForLastCommand+i_maxTimeToIdle<=System.currentTimeMillis()) ||
		(i_maxNumberOfNOOP!=0 && i_countNOOP>=i_maxNumberOfNOOP))
		{
			isAlive=false;
			return true;
		}
		return false;
	}

	private void sendWelcomeMessage() throws Exception
	{
		sendResponse("220-Welcome to Xerver Free FTP Server "+FTPServerController.getVersionString()+".\r\n");
		sendResponse("220-\r\n");
		sendResponse("220-You can login below now.\r\n");
		sendResponse("220 Features: .\r\n");
	}

	private void doCommand(String cmd, String args)
	{
//		System.out.print("Command: ");
//		System.out.println("-"+cmd+"-"+args+"-");

		String s_response;
		cmd=cmd.toUpperCase();

		if (cmd.startsWith("PASS"))
			logThis("PASS ******");
		else if (args==null)
			logThis(cmd.trim());
		else
			logThis(cmd.trim()+" "+args.trim());

		s_response="500 Syntax error, command unrecognized.";

		l_timeForLastCommand=System.currentTimeMillis();//This shall happen only if we don't make a NOOP. If we make a NOOP we don't update l_timeForLastCommand.

		if (cmd.equals("NOOP"))
			s_response=command_NOOP(args);
		else
		{
			i_countNOOP=0;

			if (cmd.equals("USER"))
				s_response=command_USER(args);
			else if (cmd.equals("PASS"))
				s_response=command_PASS(args);
			else if (cmd.equals("HELP"))
				s_response=command_HELP(args);
			else if (cmd.equals("QUIT"))
				s_response=command_QUIT(args);
			else if (i_permissionLevel==PASSWORD_ACCEPTED)
			{
				s_response="500 Syntax error, command unrecognized.";

				if (cmd.equals("CWD") || cmd.equals("XCWD"))
					s_response=command_CWD(args);
				else if (cmd.equals("PWD") || cmd.equals("XPWD"))
					s_response=command_PWD(args);
				else if (cmd.equals("CDUP") || cmd.equals("XCUP"))
					s_response=command_CDUP(args);
				else if (cmd.equals("SYST"))
					s_response=command_SYST(args);
				else if (cmd.equals("STAT"))
					s_response=command_STAT(args);
				else if (cmd.equals("STRU"))
					s_response=command_STRU(args);
				else if (cmd.equals("MODE"))
					s_response=command_MODE(args);
				else if (cmd.equals("TYPE"))
					s_response=command_TYPE(args);
				else if (cmd.equals("REST"))
					s_response=command_REST(args);
				else if (cmd.equals("PASV"))
					s_response=command_PASV(args);
				else if (cmd.equals("PORT"))
					s_response=command_PORT(args);
				else if (cmd.equals("LIST"))
					s_response=command_LIST(args);
				else if (cmd.equals("RETR"))
					s_response=command_RETR(args);
				else if (cmd.equals("STOR"))
					s_response=command_STOR(args);
				else if (cmd.equals("ALLO"))
					s_response=command_ALLO(args);
				else if (cmd.equals("MKD") || cmd.equals("XMKD"))
					s_response=command_MKD(args);
				else if (cmd.equals("RMD") || cmd.equals("XRMD"))
					s_response=command_RMD(args);
				else if (cmd.equals("DELE"))
					s_response=command_DELE(args);
				else if (cmd.equals("RNFR"))
					s_response=command_RNFR(args);
				else if (cmd.equals("RNTO"))
					s_response=command_RNTO(args);
				else if (cmd.equals("SIZE"))
					s_response=command_SIZE(args);
				else if (cmd.equals("MDTM"))
					s_response=command_MDTM(args);
				else if (cmd.equals("ABOR"))
					s_response=command_ABOR(args);
				else if (cmd.equals("FEAT"))
					s_response=command_FEAT(args);
				else if (cmd.equals("MLST"))
					s_response=command_MLST(args);
				else if (cmd.equals("MLSD"))
					s_response=command_MLSD(args);
			}
			else
			{
				if (//The first names in this list are allowed without login (for example USER and PASS), so we don't have to check these
					//cmd.equals("USER") ||
					//cmd.equals("PASS") ||
					//cmd.equals("HELP") ||
					//cmd.equals("QUIT") ||
					//cmd.equals("NOOP") ||
					cmd.equals("CWD")  ||
					cmd.equals("XCWD") ||
					cmd.equals("PWD")  ||
					cmd.equals("XPWD") ||
					cmd.equals("CDUP") ||
					cmd.equals("XCUP") ||
					cmd.equals("MKD")  ||
					cmd.equals("XMKD") ||
					cmd.equals("RMD")  ||
					cmd.equals("XRMD") ||
					cmd.equals("SYST") ||
					cmd.equals("STAT") ||
					cmd.equals("STRU") ||
					cmd.equals("MODE") ||
					cmd.equals("TYPE") ||
					cmd.equals("REST") ||
					cmd.equals("PASV") ||
					cmd.equals("PORT") ||
					cmd.equals("LIST") ||
					cmd.equals("RETR") ||
					cmd.equals("STOR") ||
					cmd.equals("ALLO") ||
					cmd.equals("DELE") ||
					cmd.equals("RNFR") ||
					cmd.equals("RNTO") ||
					cmd.equals("SIZE") ||
					cmd.equals("MDTM") ||
					cmd.equals("ABOR") ||
					cmd.equals("FEAT") ||
					cmd.equals("MLST") ||
					cmd.equals("MLSD"))
					{
						s_response="530 Please login with USER and PASS first.";
					}
			}
		}

		sendResponse(s_response+"\r\n");
		//s_lastCommand=cmd;
	}

	private void sendResponse(String response)
	{
		try {
			if (response.indexOf("\n")!=response.lastIndexOf("\n"))
			{

				String [] as_allLines = MyString.makeArrayOfString(response,"\n");
				for (int i=0; i<as_allLines.length; i++)
				{
					logThis(as_allLines[i].trim());
				}

				//String tmpStr=MyString.searchAndReplace(response,"\r\n","\r\n"+"ID_"+i_connectionID+"\t");
				//logThis(tmpStr.substring(0,tmpStr.length()-1));
			}
			else
				logThis(response.trim());

			bos.writeBytes(response);
			bos.flush();
		} catch (Exception e){showError(e);}
	}


	private void showError(Exception e)
	{
		if (b_showErrors)
		{
			System.out.println("Error: " + e);
			e.printStackTrace();
		}
	}

	private String command_USER(String argUsername)
	{
		if (argUsername==null)
			argUsername="guest";

		//Start removing all permissions for the user since a new USER has been given
		i_permissionLevel=NO_PERMISSIONS;
		fa_permissions=null;
		s_userName=argUsername;
		return "331 User name okay, need password.";
	}

	private String command_PASS(String argPassword)
	{
		if (argPassword==null)
			argPassword="";

		fa_permissions=new FileAccess(s_userName, argPassword);
		if (fa_permissions.userAndPassOK() && !s_userName.equalsIgnoreCase("guest"))
		{
			ud_userdata=fa_permissions.getUserData();
			i_permissionLevel=PASSWORD_ACCEPTED;
			setAliasesAndRoot(fa_permissions);
			return "230 User logged in, proceed.";
		}
		else
		{
			if (b_guestAccountExists)
			{
				fa_permissions=new FileAccess("guest","");	//Login as guest
				ud_userdata=fa_permissions.getUserData();
				i_permissionLevel=PASSWORD_ACCEPTED;
				setAliasesAndRoot(fa_permissions);
				return "230 User logged in as guest, proceed.";
			}
			else
			{
				fa_permissions=null;
				return "530 Not logged in.";
			}
		}
	}

	private void setAliasesAndRoot(FileAccess fa_permissions)
	{
		s_root=ud_userdata.getRoot();
		as_aliasesName=ud_userdata.getAliasesName();
		as_aliasesPath=ud_userdata.getAliasesPath();
	}

	private String command_RNFR(String argFile)
	{
		f_fileToRenameWithRNFR=null;	//Make sure to set this to null here so that after command_RNFR has been called we shall either (1) have f_fileToRenameWithRNFR=null or (2) f_fileToRenameWithRNFR="a correct file that might be renamed" (if we didn't made this we might end up with running this function and get a 550 erro rbut still have f_fileToRenameWithRNFR="some old value from last time this function was executed successfully").

		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.writePermissionOK(s_file))
		{
			if (fa_permissions.createPermissionOK(s_file))
				return 	"550-Requested action not taken. Permission denied.\r\n"+
						"550 You are not allowed to move files or folders from this directory.";
			else
				return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			f_fileToRenameWithRNFR=new File(s_file);
			return "350 "+MyPathFunctions.makeSlashForResponse(argFile)+" exists, ready for destination name.";
		}
	}

	private String command_RNTO(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (f_fileToRenameWithRNFR==null)
		{
			return "503 Bad sequence of commands. Please first try to give a valid RNFR command.";
		}
		else
		{
			if (!fa_permissions.writePermissionOK(s_file) && fa_permissions.isNotAllowedToCreateNewFile(s_file))
			{
				if (fa_permissions.createPermissionOK(s_file))
					return 	"550-Requested action not taken. Permission denied.\r\n"+
							"550-A file with the same name does already exists in this directory,\r\n"+
							"550 and you do not have permission to overwrite it.";
				else
					return "550 Requested action not taken. Permission denied.";
			}
			/*
			* If we don't want that RNTO shall give an "file already exists"-error,
			* but only overwrite the file, comment the following "else if"-statement...
			*/
			else if (MyFileFunctions.fileExists(s_file))
			{
				return "553 Requested action not taken. File or folder does already exists.";
			}
			else
			{
				try {
					if (f_fileToRenameWithRNFR.renameTo(new File(s_file)))	//If [file renamed successfully] then...
					{
						return "250 File was successfully renamed to "+MyPathFunctions.makeSlashForResponse(argFile)+".";
					}
					else
					{
						return	"450 An error occured while trying to rename file to \""+MyPathFunctions.makeSlashForResponse(argFile)+"\".\r\n";
					}
				}
				catch (Exception e)
				{
					return	"450-An error occured while trying to rename file to \""+MyPathFunctions.makeSlashForResponse(argFile)+"\".\r\n"+
							"450 The error message was: "+e;
				}
			}
		}
	}



	private String command_DELE(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.writePermissionOK(s_file))
		{
			boolean b_isAllowedToCreateNewDir=fa_permissions.createPermissionOK(s_file);

			if (b_isAllowedToCreateNewDir)
					return 	"550-Requested action not taken. Permission denied.\r\n"+
							"550 You are not allowed to delete files in this directory.";
			else
				return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			try {
				File theFile=new File(s_file);
				if (!theFile.isDirectory())
				{
					theFile.delete();
					return "250 "+MyPathFunctions.makeSlashForResponse(argFile)+" was successfully deleted.";
				}
				else
				{
					return "550 "+MyPathFunctions.makeSlashForResponse(argFile)+" exists, but is a directory.";
				}
			}
			catch (Exception e)
			{
				return	"450-An error occured while trying to delete \""+MyPathFunctions.makeSlashForResponse(argFile)+"\".\r\n"+
						"450 The error message was: "+e;
			}
		}
	}



	private String command_RMD(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.writePermissionOK(s_file))
		{
			boolean b_isAllowedToCreateNewDir=fa_permissions.createPermissionOK(s_file);

			if (b_isAllowedToCreateNewDir)
					return 	"550-Requested action not taken. Permission denied.\r\n"+
							"550 You are not allowed to delete folders in this directory.";
			else
				return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			try {
				File theFile=new File(s_file);
				if (theFile.isDirectory())
				{
					if (theFile.delete())
						return "250 "+MyPathFunctions.makeSlashForResponse(argFile)+" was successfully deleted.";
					else
						return 	"550-"+MyPathFunctions.makeSlashForResponse(argFile)+" could not be deleted.\r\n"+
								"550 Make sure you have permissions to delete the folder and that the folder is empty.";
				}
				else
				{
					return "550 "+MyPathFunctions.makeSlashForResponse(argFile)+" exists, but is not a directory.";
				}
			}
			catch (Exception e)
			{
				return	"450-An error occured while trying to delete \""+MyPathFunctions.makeSlashForResponse(argFile)+"\".\r\n"+
						"450 The error message was: "+e;
			}
		}
	}



	private String command_MKD(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.writePermissionOK(s_file) && fa_permissions.isNotAllowedToCreateNewFile(s_file))
		{
			if (fa_permissions.createPermissionOK(s_file))
				return 	"550-Requested action not taken. Permission denied.\r\n"+
						"550-A folder with the same name does already exists in this directory,\r\n"+
						"550 and you do not have permission to overwrite it.";
			else
				return "550 Requested action not taken. Permission denied.";
		}
		else if (MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder with this name does already exists.";
		}
		else
		{
			try {
				boolean result=(new File(s_file)).mkdir();
				if (result)
				{
					return "257 \""+MyPathFunctions.makeSlashForResponse(argFile)+"\"";
				}
				else
				{
					return	"550-Server could not create directory.\r\n"+
							"550-The reason might be that the directory name is illegal\r\n"+
							"550 or that the server doesn't have write permissions to this folder.";
				}
			}
			catch (Exception e)
			{
				return	"450-An error occured while trying to create \""+MyPathFunctions.makeSlashForResponse(argFile)+"\".\r\n"+
						"450 The error message was: "+e;
			}
		}
	}


	private String command_ALLO(String arg)
	{
		return "202 Command not imlemented, superfluous at this site.";
	}


	private String command_STOR(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (FTPDC_dataConnection!=null)
		{
			if (!fa_permissions.writePermissionOK(s_file) && fa_permissions.isNotAllowedToCreateNewFile(s_file))
			{
				if (fa_permissions.createPermissionOK(s_file))
					return 	"550-Requested action not taken. Permission denied.\r\n"+
							"550 You are not allowed to modify or delete files that already exists.";
				else
					return "550 Requested action not taken. Permission denied.";
			}
			else
			{
				try
				{
					if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
					{
						sendResponse("150 Starting binary file transfer.\r\n");
						FTPDC_dataConnection.writeFile(s_file, false);	//False=do not append to file, instead replace file

						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "226 Closing data connection; requested file action successful.";
					}
					else
					{
						//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
						return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
					}
				}
				catch (Exception e)
				{
					if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
					{
						return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
								"425-Port may already be in use.\r\n"+
								"425 Transfer aborted.";
					}
					else
					{
						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "426 Connection trouble, closed; transfer aborted.";
					}
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}




	private String command_APPE(String argFile)	//Like STOR, but appends data to end of file
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (FTPDC_dataConnection!=null)
		{
			if (!fa_permissions.writePermissionOK(s_file))
			{
				return "550 Requested action not taken. Permission denied.";
			}
			else if (!MyFileFunctions.fileExists(s_file))
			{
				return "550 Requested action not taken. File does not exist.";
			}
			else
			{
				try
				{
					if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
					{
						sendResponse("150 Starting binary file transfer.\r\n");
						FTPDC_dataConnection.writeFile(s_file, true);	//True=yes append to file

						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "226 Closing data connection; requested file action successful.";
					}
					else
					{
						//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
						return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
					}
				}
				catch (Exception e)
				{
					if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
					{
						return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
								"425-Port may already be in use.\r\n"+
								"425 Transfer aborted.";
					}
					else
					{
						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "426 Connection trouble, closed; transfer aborted.";
					}
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}




	private String command_RETR(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (FTPDC_dataConnection!=null)
		{
			File f_theFile=new File(s_file);
/*
			if (f_theFile.isDirectory())	//Firefox for example asks for the content of a file when it want to do a directory listing
			{
				if (!fa_permissions.listPermissionOK(s_file))
				{
					return "550 Requested action not taken. Permission denied.";
				}
				else
				{
					return command_LIST(argFile);
				}
			}
			else
*/
			if (!fa_permissions.readPermissionOK(s_file))
			{
				return "550 Requested action not taken. Permission denied.";
			}
			else if (!MyFileFunctions.fileExists(s_file))
			{
				return "550 Requested action not taken. File does not exist.";
			}
			else if (MyFileFunctions.isDirectory(s_file))
			{
				return "550 Requested action not taken. "+MyPathFunctions.makeSlashForResponse(makeAbsolutePath(argFile))+" is a directory, not a file.";
			}
			else
			{
				try
				{
					if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
					{
						if (b_binaryFlag)
						{
							sendResponse("150 Starting binary file transfer.\r\n");
							FTPDC_dataConnection.sendFileContentBinary(s_file, i_startPosition);
							i_startPosition=0;
						}
						else
						{
							sendResponse("150 Starting ASCII file transfer.\r\n");
							FTPDC_dataConnection.sendFileContentASCII(s_file);
							i_startPosition=0;
						}

						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "226 Closing data connection; requested file action successful.";
					}
					else
					{
						//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
						return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
					}
				}
				catch (Exception e)
				{
					if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
					{
						return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
								"425-Port may already be in use.\r\n"+
								"425 Transfer aborted.";
					}
					else
					{
						FTPDC_dataConnection.killConnection();
						FTPDC_dataConnection = null;
						return "426 Connection trouble, closed; transfer aborted.";
					}
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}


	private String command_SIZE(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.listPermissionOK(s_file))
		{
			return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			File tmpFile=new File(s_file);
			if (!tmpFile.isDirectory())
				return "213 "+tmpFile.length();
			else
				return "550 Requested action not taken. "+MyPathFunctions.makeSlashForResponse(makeAbsolutePath(argFile))+" is a directory, not a file.";
		}
	}


	private String command_ABOR(String argFile)
	{
		if (FTPDC_dataConnection != null)
		{
			FTPDC_dataConnection.killConnection();
			FTPDC_dataConnection = null;
		}
		return "226 ABOR command successful.";
	}


	private String command_MDTM(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (!fa_permissions.listPermissionOK(s_file))
		{
			return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			File tmpFile=new File(s_file);

			return "213 "+MyFileFunctions.getLastModifiedAsFormatedString(tmpFile);	//Return YYYYMMDDhhmmss
		}
	}



	private String subCommand_listFile(String argFile)
	{
		if (argFile==null)
			return "504 Command not implemented for an empty parameter.";

		String s_file=makeRealFilePath(argFile);

		if (FTPDC_dataConnection!=null)
		{
			try
			{
				if (!fa_permissions.listPermissionOK(s_file))
				{
					return "550 Requested action not taken. Permission denied.";
				}
				else if (!MyFileFunctions.fileExists(s_file))
				{
					return "550 Requested action not taken. File or folder does not exists.";
				}
				else if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
				{
					sendResponse("150 Starting ASCII transfer for file listing.\r\n");

					LSListing ls_listing = new LSListing(s_file, fa_permissions, true);	//true=sending over data connection; false=sending over control connection
					FTPDC_dataConnection.sendFileInfo(ls_listing);
					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "226 Closing data connection; requested file action successful.";
				}
				else
				{
					//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
					return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
				}
			}
			catch (Exception e)
			{
				if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
				{
					return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
							"425-Port may already be in use.\r\n"+
							"425 Transfer aborted.";
				}
				else
				{
					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "426 Connection trouble, closed; transfer aborted.";
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?

	}

	private String subCommand_listDir()
	{
		if (FTPDC_dataConnection!=null)
		{
			try
			{
				String s_listThisFolder=makeRealFilePath(s_currentRelativePath);

				if (!fa_permissions.listPermissionOK(s_listThisFolder))
				{
					return "550 Requested action not taken. Permission denied.";
				}
				else if (!MyFileFunctions.fileExists(s_listThisFolder))
				{
					return "550 Requested action not taken. Folder does not exists.";
				}
				else if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
				{
					sendResponse("150 Starting ASCII transfer for file listing.\r\n");

					LSListing ls_listing = new LSListing(s_listThisFolder, fa_permissions, true);	//true=sending over data connection; false=sending over control connection

					if (s_currentRelativePath.equals(File.separator))	//Aliases can only be listed (but might not be listed) when we are at root...
					{
						//HERE WE MAKE SURE THAT WE LIST ALIASES IF WE ARE IN ROOT AND WE SHALL SHOW ALIASES
						if (i_howToShowAlias==SHOW_NO_ALIASES)
							FTPDC_dataConnection.sendDirectoryListing(ls_listing);
						else if (i_howToShowAlias==SHOW_ONLY_ALIASES)
							FTPDC_dataConnection.sendAliasListing(ls_listing, as_aliasesName, as_aliasesPath);
						else 	//if (i_howToShowAlias==SHOW_ALIASES_AND_DIRS)
						{
							FTPDC_dataConnection.sendDirectoryListing(ls_listing);
							FTPDC_dataConnection.sendAliasListing(ls_listing, as_aliasesName, as_aliasesPath);
						}
					}
					else
					{
						FTPDC_dataConnection.sendDirectoryListing(ls_listing);
					}

					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "226 Closing data connection; requested file action successful.";
				}
				else
				{
					//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
					return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
				}
			}
			catch (Exception e)
			{
				if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
				{
					return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
							"425-Port may already be in use.\r\n"+
							"425 Transfer aborted.";
				}
				else
				{
					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "426 Connection trouble, closed; transfer aborted.";
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}


	private String command_MLST(String argFile)
	{
		String s_absPath;
		String s_file;
		if (argFile == null)	//If [Clients only sends "MLSD", with no parameters], then...
		{
			s_file=makeRealFilePath(s_currentRelativePath);	//...send listing for current directory
			s_absPath = makeAbsolutePath(s_currentRelativePath);
		}
		else	//Else [client used parameter], then...
		{
			s_file=makeRealFilePath(argFile); //Send the listin for that particular directory (or give error if it's not a folder)
			s_absPath = makeAbsolutePath(argFile);
		}

		if (!fa_permissions.listPermissionOK(s_file))
		{
			return "550 Requested action not taken. Permission denied.";
		}
		else if (!MyFileFunctions.fileExists(s_file))
		{
			return "550 Requested action not taken. File or folder does not exists.";
		}
		else
		{
			File tmpFile = new File(s_file);
			sendResponse("250-Listing "+MyPathFunctions.makeSlashForResponse(s_absPath)+"\r\n");
			sendResponse(" "+MLSDListing.getMLSTFormat(tmpFile, s_absPath)+"\r\n");
			return "250 End.";
		}
	}

	private String command_MLSD(String argFile)
	{
		if (FTPDC_dataConnection!=null)
		{
			try
			{
				String s_absPath;
				String s_listThisFolder;
				if (argFile == null)	//If [Clients only sends "MLSD", with no parameters], then...
				{
					s_listThisFolder=makeRealFilePath(s_currentRelativePath);	//...send listing for current directory
					s_absPath = makeAbsolutePath(s_currentRelativePath);
				}
				else	//Else [client used parameter], then...
				{
					s_listThisFolder=makeRealFilePath(argFile); //Send the listin for that particular directory (or give error if it's not a folder)
					s_absPath = makeAbsolutePath(argFile);
				}

				if (!fa_permissions.listPermissionOK(s_listThisFolder))
				{
					return "550 Requested action not taken. Permission denied.";
				}
				else if (!MyFileFunctions.fileExists(s_listThisFolder))
				{
					return "550 Requested action not taken. Folder does not exists.";
				}
				else if (!MyFileFunctions.isDirectory(s_listThisFolder))
				{
					return "501 Not a directory.";
				}
				else if (FTPDC_dataConnection.waitForDataConnectionToBeTaken(i_timeForClientToTakeDataConnedtion))	//Wait 2 secs for client to take data connection (true if taken, false if not taken)
				{
					sendResponse("150 Starting ASCII transfer for file listing.\r\n");

					MLSDListing mlsd = new MLSDListing(s_listThisFolder, s_absPath);

					FTPDC_dataConnection.sendHeaderListingMLSDStyle(mlsd);

					if (s_absPath.equals(File.separator))	//Aliases can only be listed (but might not be listed) when we are at root...
					{
						//HERE WE MAKE SURE THAT WE LIST ALIASES IF WE ARE IN ROOT AND WE SHALL SHOW ALIASES
						if (i_howToShowAlias==SHOW_NO_ALIASES)
							FTPDC_dataConnection.sendDirectoryListingMLSDStyle(mlsd);
						else if (i_howToShowAlias==SHOW_ONLY_ALIASES)
							FTPDC_dataConnection.sendAliasListingMLSDStyle(mlsd, as_aliasesName, as_aliasesPath);
						else 	//if (i_howToShowAlias==SHOW_ALIASES_AND_DIRS)
						{
							FTPDC_dataConnection.sendDirectoryListingMLSDStyle(mlsd);
							FTPDC_dataConnection.sendAliasListingMLSDStyle(mlsd, as_aliasesName, as_aliasesPath);
						}
					}
					else
					{
						FTPDC_dataConnection.sendDirectoryListingMLSDStyle(mlsd);
					}

					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "226 Closing data connection; requested file action successful.";
				}
				else
				{
					//I don't know if this is really a good response, as we don't close the connection... It's just that the client has not taken the data connection we have opened.
					return "426 Connection trouble, closed; transfer aborted. (Client did not take the data connection)";
				}
			}
			catch (Exception e)
			{
				if (FTPDC_dataConnection.portNumberOccupiedWithPORT())
				{
					return 	"425-Xerver was not allowed to use port "+FTPDataConnection.i_dataPortNr+".\r\n"+
							"425-Port may already be in use.\r\n"+
							"425 Transfer aborted.";
				}
				else
				{
					FTPDC_dataConnection.killConnection();
					FTPDC_dataConnection = null;
					return "426 Connection trouble, closed; transfer aborted.";
				}
			}
		}
		else
			return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}


	private String command_LIST(String argFile)
	{
		if (argFile==null)	//Lista en katalog
		{
			return subCommand_listDir();
		}
		else if (argFile.charAt(0)=='-')	//For example "-aL"
		{
			return subCommand_listDir();
		}
		else	//Visa info om en fil
		{
			return subCommand_listFile(argFile);
		}
	}

	private String command_PASV(String dummy)
	{
		try {
			if (FTPDC_dataConnection!=null)
			{
				FTPDC_dataConnection.stopListenToPortAndKillCurrentConnection();	//If a transfer already is established, just kill it (this is what PASV is supposed to do)
				FTPDC_dataConnection = null;
			}

			FTPDC_dataConnection=new FTPDataConnection();
			FTPDC_dataConnection.start();
			int portNr=FTPDC_dataConnection.getPortNr();

			if (b_isLocalConnection)
			{
				return "227 Entering passive mode ("+s_serverLocalIP+","+portNr/256+","+portNr%256+").";
			}
			else
			{
				return "227 Entering passive mode ("+s_serverOuterIP+","+portNr/256+","+portNr%256+").";
			}
		} catch (Exception e) {showError(e);}
		return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}


	private String command_PORT(String IPandPort)
	{
		if (IPandPort==null)
			return "504 Command not implemented for an empty parameter.";

		try {
			if (FTPDC_dataConnection!=null)
			{
				FTPDC_dataConnection.stopListenToPortAndKillCurrentConnection();	//If a transfer already is established, just kill it (this is what PASV is supposed to do)
				FTPDC_dataConnection = null;
			}

			// NOW MAKE IPandPort="1,2,3,4,a,b" ==> portNr=256*a+b  and  newIP="1.2.3.4"
			String newIP, tmpPortString;
			int portNr, tmpIndexOf;
			newIP=IPandPort;
			tmpIndexOf=newIP.lastIndexOf(',');
			tmpPortString=newIP.substring(tmpIndexOf+1);	//tmpPortString="b"
			newIP=newIP.substring(0,tmpIndexOf);			//"1,2,3,4,a,b" ==> "1,2,3,4,a"
			portNr=Integer.parseInt(tmpPortString);			//portNr=b
			tmpIndexOf=newIP.lastIndexOf(',');
			tmpPortString=newIP.substring(tmpIndexOf+1);	//tmpPortString="a"
			newIP=newIP.substring(0,tmpIndexOf);			//"1,2,3,4,a" ==> "1,2,3,4"
			portNr+=256*Integer.parseInt(tmpPortString);	//portNr=b+256*a
			newIP=newIP.replace(',','.');

			if (s_usersIPNumber.equals(newIP) || s_usersIPNumber.equals("127.0.0.1"))	//IF [user wants connect to himself] OR [User is sitting at server], then accept the PORT-command
			{
				FTPDC_dataConnection=new FTPDataConnection(newIP, portNr);
				FTPDC_dataConnection.start();

				return "200 Port command successful.";
			}
			else
			{
				return "500 I won't open a connection to "+newIP+" (only to "+s_usersIPNumber+")";
			}
		} catch (Exception e) {showError(e);}
		return "425 Can't open data connection";	//This response (425) shall not be given after a PASV, however, I have no idea what else to put here... Change this?
	}

	private String command_TYPE(String arg)
	{
		if (arg==null)
			return "504 Command not implemented for an empty parameter.";

		arg=arg.toUpperCase();

		if (arg.equals("A") || arg.equals("A N"))
		{
			b_binaryFlag=false;
			return "200 Binary flag is unset (turned off).";
		}
		else if (arg.equals("I") || arg.equals("L 8"))
		{
			b_binaryFlag=true;
			return "200 Binary flag is set (turned on).";
		}
		else
		{
			return "504 Command not implemented for that parameter.";
		}
	}

	private String command_REST(String startPosValue)
	{
		try {
			i_startPosition=Integer.parseInt(startPosValue);

			if (i_startPosition<0)
				return "501 Syntax error in parameters or arguments";

			if (b_binaryFlag)
				return "350 Restarting at "+i_startPosition+".";
			else
				return "350 Restarting at "+i_startPosition+". But we're in ASCII mode.";
		}
		catch (Exception e)	//java.lang.NumberFormatException: For input string: "noString"
		{
			return "501 Syntax error in parameters or arguments";
		}
	}

	private String command_STRU(String dummy)
	{
		if (dummy!=null && dummy.equalsIgnoreCase("F"))
			return "200 STRU is obsolete.";
		else
			return "504 STRU is obsolete, but I can accept a F as parameter.";
	}

	private String command_MODE(String dummy)
	{
		if (dummy!=null && dummy.equalsIgnoreCase("S"))
			return "200 MODE is obsolete.";
		else
			return "504 MODE is obsolete, but I can accept a S as parameter.";
	}

	private String command_HELP(String verb)
	{
		return 	"214-Supported commands:\r\n"+
				"214-USER PASS HELP QUIT CWD  XCWD\r\n"+
				"214-PWD  XPWD CDUP XCUP MKD  XMKD\r\n"+
				"214-RMD  XRMD SYST STAT NOOP STRU\r\n"+
				"214-MODE TYPE REST PASV PORT LIST\r\n"+
				"214-RETR STOR ALLO DELE RNFR RNTO\r\n"+
				"214-SIZE MDTM ABOR FEAT MLST MLSD\r\n"+
				"214-\r\n"+
				"214 [End of Help].";
	}

	private String command_FEAT(String verb)
	{
		/**
		* Should list all commands that Xerver supports,
		* except those defined in RFC 959 (http://www.faqs.org/rfcs/rfc959.html).
		*/
		return 	"211-Features supported\r\n"+
				" SIZE\r\n"+
				" MDTM\r\n"+
				" FEAT\r\n"+
				" MLST type*;size*;modify*;\r\n"+
				" MLSD\r\n"+
				"211 End";
	}

/*
 * Examples of FEAT results:
 *
[18:44:58] 211-Features supported
[18:44:58]  MDTM
[18:44:58]  MLST Type*;Size*;Modify*;Perm*;Unique*;
[18:44:58]  REST STREAM
[18:44:58]  SIZE
[18:44:58]  TVFS
[18:44:58] 211 End

[18:39:32] 211-Extensions supported:
[18:39:33]  MDTM
[18:39:33]  MLST type*,size*,modify*,create,unique*,perm,unix.mode,unix.owner,unix.group
[18:39:33]  PASV
[18:39:33]  REST STREAM
[18:39:33]  SSCN
[18:39:33]  SIZE
[18:39:33]  TVFS
[18:39:33]  EPRT
[18:39:33]  EPSV
[18:39:33] 211 End.

[18:39:14] 211-Extensions supported:
[18:39:14]  EPRT
[18:39:14]  IDLE
[18:39:14]  MDTM
[18:39:14]  SIZE
[18:39:14]  REST STREAM
[18:39:14]  MLST type*;size*;sizd*;modify*;UNIX.mode*;UNIX.uid*;UNIX.gid*;unique*;
[18:39:14]  MLSD
[18:39:14]  ESTP
[18:39:14]  PASV
[18:39:14]  EPSV
[18:39:14]  SPSV
[18:39:14]  ESTA
[18:39:14] 211 End.

 */

/*
 * Commands that Xerver support, but that are not in RFC 959:

	 SIZE
	 MDTM
	 FEAT
	 MLST
	 MLSD
 */

/*
 * In RFC 959: http://www.faqs.org/rfcs/rfc959.html:
 *
 * Supported by Xerver and exist in RFC 959:

	USER <SP> <username> <CRLF>
	PASS <SP> <password> <CRLF>
	CWD  <SP> <pathname> <CRLF>
	CDUP <CRLF>
	QUIT <CRLF>
	PORT <SP> <host-port> <CRLF>
	PASV <CRLF>
	TYPE <SP> <type-code> <CRLF>
	STRU <SP> <structure-code> <CRLF>
	MODE <SP> <mode-code> <CRLF>
	RETR <SP> <pathname> <CRLF>
	STOR <SP> <pathname> <CRLF>
	STOU <CRLF>
	APPE <SP> <pathname> <CRLF>
	ALLO <SP> <decimal-integer>
		[<SP> R <SP> <decimal-integer>] <CRLF>
	REST <SP> <marker> <CRLF>
	RNFR <SP> <pathname> <CRLF>
	RNTO <SP> <pathname> <CRLF>
	ABOR <CRLF>
	DELE <SP> <pathname> <CRLF>
	RMD  <SP> <pathname> <CRLF>
	MKD  <SP> <pathname> <CRLF>
	PWD  <CRLF>
	LIST [<SP> <pathname>] <CRLF>
	SITE <SP> <string> <CRLF>
	SYST <CRLF>
	STAT [<SP> <pathname>] <CRLF>
	HELP [<SP> <string>] <CRLF>
	NOOP <CRLF>

 *
 * Not supported by Xerver but exist in RFC 959:
 *

	SMNT <SP> <pathname> <CRLF>
	REIN <CRLF>
	NLST [<SP> <pathname>] <CRLF>
	ACCT <SP> <account-information> <CRLF>
*/

	private String command_NOOP(String dummy)
	{
		i_countNOOP++;
		try
		{
			if (disconnectBecauseIdleTime())	//Note: This MIGHT (if we have "been idle" too long) write a "Bye"-response and then close the connection, so Xerver will try to write "200 NOOP command successful." to a closed Socket later.
			{
				return "221 Bye. You have been idle for a long time now.";
			}
		}
		catch (Exception e){}
		return "200 NOOP command successful.";
	}

	private String command_SYST(String dummy)
	{
		return "215 Windows_NT version 5.0";
		//return "215 UNIX Type: L8";
	}

	private String command_STAT(String subCommand)
	{
		if (subCommand==null)
			return "211 This server is running Xerver Free FTP Server "+FTPServerController.getVersionString()+".";	//More information about the status of the server shall be given...
		else if (subCommand.charAt(0)=='-')
		{
			try {
				String s_file=makeRealFilePath(s_currentRelativePath);

				if (!fa_permissions.listPermissionOK(s_file))
				{
					return "550 Requested action not taken. Permission denied.";
				}
				else if (!MyFileFunctions.fileExists(s_file))
				{
					return "550 Requested action not taken. Folder does not exists.";
				}
				else
				{
					LSListing ls_listing = new LSListing(s_file, fa_permissions, false);	//true=sending over data connection; false=sending over control connection

					sendResponse("213-STAT directory listing:\r\n");

					if (s_currentRelativePath.equals(File.separator))	//Aliases can only be listed (but might not be listed) when we are at root...
					{
						//HERE WE MAKE SURE THAT WE LIST ALIASES IF WE ARE IN ROOT AND WE SHALL SHOW ALIASES
						if (i_howToShowAlias==SHOW_NO_ALIASES)
							ls_listing.sendDirectoryListing(bos);
						else if (i_howToShowAlias==SHOW_ONLY_ALIASES)
						{
							ls_listing.sendAliasListing(bos, as_aliasesName, as_aliasesPath);
						}
						else 	//if (i_howToShowAlias==SHOW_ALIASES_AND_DIRS)
						{
							ls_listing.sendDirectoryListing(bos);
							ls_listing.sendAliasListing(bos, as_aliasesName, as_aliasesPath);
						}
					}
					else
					{
						ls_listing.sendDirectoryListing(bos);
					}

					return "213 Directory listing done!";
				}

			}
			catch (Exception e)
			{
				return 	"213-Directory listing failed!"+
						"213 The reason for the failure is: "+e;
			}
		}
		else
			return "211 This server is running Xerver Free FTP Server "+FTPServerController.getVersionString()+".";
	}

	private String command_QUIT(String dummy)
	{
		isAlive=false;
		return "221 Bye.";
	}

	private String command_PWD(String dummy)
	{
		return "257 \""+MyPathFunctions.makeSlashForResponse(s_currentRelativePath)+"\"";
	}

	private String command_CDUP(String dummy)
	{
		if (!s_currentRelativePath.equals(File.separator))
			return command_CWD(s_currentRelativePath.substring(0,s_currentRelativePath.lastIndexOf(File.separatorChar, s_currentRelativePath.length()-2)+1));
		else
			return command_CWD(File.separator);
//		s_currentRelativePath=s_currentRelativePath.substring(0,s_currentRelativePath.lastIndexOf(File.separatorChar, s_currentRelativePath.length()-2)+1);
//-------		if (s_currentRelativePath.equals(""))	//Beh�vs ej l�ngre? vi garanterar (p� raden ovan) att vi har / i slutet �nd�...
//-------			s_currentRelativePath="/";
//		return "250 CWD command successful.";
	}

	private String command_CWD(String argPath)
	{
		if (argPath==null)
			return "504 Command not implemented for an empty parameter.";

		String s_newPath=makeRealFilePath(argPath);
		String s_absPath=makeAbsolutePath(argPath);

		s_newPath=MyPathFunctions.makeSlashAtEnd(s_newPath);	//NOTE: We must have this line, otherwise when someone would try to list "c:/dir/dir2" the listing would succeed or fail depending on what permission are set for "c:/dir/", but we want the listing to be allowed/denied depending on what access we have on "c:/dir/dir2/", so we must change "c:/dir/dir2" to "c:/dir/dir2/".

		File tmpFolder;
		tmpFolder=new File(s_newPath);
		if (tmpFolder.isDirectory())
		{
			s_currentRelativePath=MyPathFunctions.makeSlashAtEnd(s_absPath);
			return "250 Present working directory is now "+MyPathFunctions.makeSlashForResponse(s_currentRelativePath);
		}
		else
		{
			return "550 "+MyPathFunctions.makeSlashForResponse(s_absPath)+": No such directory";
		}
	}

	private String makeAbsolutePath(String path)
	{
		if (path.length()==0)
			return s_currentRelativePath;

		if (File.separatorChar=='\\')
			path=path.replace('/',File.separatorChar);
		else
			path=path.replace('\\',File.separatorChar);

		if (path.charAt(0)==File.separatorChar)
			path=MyString.makeCanonicalPath(path);
		else
			path=MyString.makeCanonicalPath(s_currentRelativePath+path);

		if (path.startsWith(".."+File.separator) || path.startsWith(File.separator+".."+File.separator) || path.equals("..") || path.equals(""))
			return File.separator;
		else
			return path;	//This will only occur if we try to come to a folder "below" / (for example: "/root/../../secret/" (which will evaluate to "../secret/"))
	}

	private String makeRealFilePath(String argFile)
	{
		String absPath=makeAbsolutePath(argFile);	//Format: "/" or "/bla" or "/*/bla" or "/*/bla/" (* = anything)
		String absPathWithoutFirstSlash=absPath.substring(1);
		if (absPathWithoutFirstSlash.length()==0)	//The path is "/"
			return MyPathFunctions.folderNameWithoutLastSlash(s_root)+absPath;
		else
		{
			String s_aliasRoot;
			int lengthOfAlias=absPathWithoutFirstSlash.indexOf(File.separatorChar);
			if (lengthOfAlias==-1)	//Path is "/bla" (but we don't know if "bla" is an alias or not)
			{
				lengthOfAlias=absPathWithoutFirstSlash.length();
				s_aliasRoot=getRealPathFromAliasName(absPathWithoutFirstSlash);
			}
			else
			{
				s_aliasRoot=getRealPathFromAliasName(absPathWithoutFirstSlash.substring(0,lengthOfAlias));
			}

			if (s_aliasRoot!=null)	//alias exists and lengthOfAlias is the alias length
				return MyPathFunctions.folderNameWithoutLastSlash(s_aliasRoot)+absPath.substring(lengthOfAlias+1);
			else	//alias does NOT exists and lengthOfAlias is a dummy value
				return MyPathFunctions.folderNameWithoutLastSlash(s_root)+absPath;
		}
	}


	private String getRealPathFromAliasName(String alias)
	{
		for (int i=0; i<as_aliasesName.length; i++)
		{
			if (as_aliasesName[i].equals(alias))
			{
				return as_aliasesPath[i];
			}
		}
		return null;
	}


	/*
	private String removeAliasFromAbsolutePath(String path)		// "/aliasname/dir1/dir2/" ==> "/dir1/dir2/" ...or... "\aliasname\dir1\dir2\" ==> "\dir1\dir2\"
	{
		return path.substring(path.indexOf(File.separatorChar));
	}
	*/

	private void logThis(String s_logTxt)
	{
		String s_date = new Date(System.currentTimeMillis()).toString().substring(4,19);
		l_logFile.writeToLog("ID_"+i_connectionID+"\t"+s_date+"\t"+s_logTxt);
	}

	public String getRemoteIP()
	{
		return s_usersIPNumber;
	}
}








