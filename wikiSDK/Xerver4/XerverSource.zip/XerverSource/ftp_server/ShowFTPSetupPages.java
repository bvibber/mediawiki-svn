//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;

import java.io.*;
import java.util.*;


/**
 *
 * <B>How to use (example):</B>
 * <BR>
 * <CODE>ShowFTPSetupPages.showGeneralInfo(theOutput, FTPS_settings);</CODE>
 * <BR>
 * <BR>
 * This class contains only static members.
 * <BR>
 * Members in this class are called from <CODE>FTPSetupConnection</CODE>.
 * <BR>
 * After a HTML-setup page is read and showed a member in this class is called, which write a piece of JavaScript to the bottom of the HTML-page.
 * <BR>
 * The JavaScript shows which the current settings are (for example: when you load the setup page where you choose port number, a piece of JavaScript changes the value in the "port number"-field to the port number that is used (for example 21)).
 * <BR>
 * This class also contains members that show the "Welcome to Xerver FTP Setup"-page and similar pages.
 *
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class ShowFTPSetupPages
{
	private static final boolean b_showErrors=false;

	public static void showChooseUserScript(DataOutputStream os, String [] allUsers)
	{
		try {
			Arrays.sort(allUsers);
			os.writeBytes("<SCRIPT>\n");

			for (int i=0; i<allUsers.length; i++)
			{
				os.writeBytes("addUserToList('"+allUsers[i]+"');\n");
			}

			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showChooseUserScript:\n"+e);}
	}



	public static void showRootInfo(DataOutputStream os, UserData UD_userData)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("userNameIs(\""+UD_userData.getUsername()+"\");\n");
			os.writeBytes("rootIs(\""+MyString.searchAndReplace(UD_userData.getRoot(),"\\","\\\\")+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showRootInfo:\n"+e);}
	}

	public static void showAliasesInfo(DataOutputStream os, UserData UD_userData)
	{
		try {
			String [] as_aliasesPath, as_aliasesName;
			as_aliasesName=UD_userData.getAliasesName();
			as_aliasesPath=UD_userData.getAliasesPath();
			int i_lengthOfArray=as_aliasesPath.length;

			if (i_lengthOfArray!=0)
			{
				os.writeBytes("<TABLE BGCOLOR=\"#eeeeee\" BORDER=2 BORDERCOLORDARK=black BORDERCOLORLIGHT=black BORDERCOLOR=black CELLPADDING=0 CELLSPACING=0>\n");
				os.writeBytes("<TR><TH>Remove</TH><TH>Alias name</TH><TH>Path</TH></TR>\n");
				for (int i=0; i<as_aliasesPath.length; i++)
				{
	//				os.writeBytes("addAliasToList(\""+as_aliasesName[i]+"\",\""+MyString.searchAndReplace(as_aliasesPath[i],"\\","\\\\")+"\");\n");
					os.writeBytes("<TR><TD><INPUT TYPE=checkbox NAME='aliasCheckbox' VALUE=\""+as_aliasesName[i]+"\"></TD><TD>"+as_aliasesName[i]+"</TD><TD><A HREF=\""+as_aliasesPath[i]+"\" TARGET=\"_blank\">"+as_aliasesPath[i]+"</A></TD></TR>\n");
				}
				if (i_lengthOfArray==0)
				{
					os.writeBytes("<TR><TD COLSPAN=3><I>No aliases</I></TD></TR>\n");
					os.writeBytes("</TABLE>\n");
				}
				else
				{
					os.writeBytes("</TABLE>\n");
					os.writeBytes("<INPUT VALUE=\"Remove aliases\" TYPE=button onClick=\"removeAliases()\">\n");
				}
			}
			else
			{
				//Show nothing if nothing in list
			}

			os.writeBytes("</FORM>\n");
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("userNameIs(\""+UD_userData.getUsername()+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showAliasesInfo:\n"+e);}
	}


	public static void showPermissionsInfo(DataOutputStream os, UserData UD_userData)
	{
		try {
			String [] as_allPermissions=MyString.makeArrayOfString(UD_userData.getPermissionsString(),",");

			//ALL THESE ARE TEMPORARY VARIABLES (NO GLOBAL VARIABLES)
			int i_lengthAllPermissions=as_allPermissions.length;
			int separatorIndexOf;
			String attribute, path, tmpLine;

			if (i_lengthAllPermissions!=0)
			{
				os.writeBytes("Here you can update permissions for this user.<BR>");
				os.writeBytes("Just make your changes and press the Update-button.");
				os.writeBytes("<TABLE BGCOLOR=\"#eeeeee\" BORDER=2 BORDERCOLORDARK=black BORDERCOLORLIGHT=black BORDERCOLOR=black CELLPADDING=0 CELLSPACING=0>\n");
				os.writeBytes("<TR BGCOLOR=\"#cccccc\"><TH>D</TH><TH>W</TH><TH>R</TH><TH>C</TH><TH>L</TH><TH>S</TH><TH>Path</TH></TR>\n");

				for (int i=0; i<i_lengthAllPermissions; i++)
				{
					tmpLine=as_allPermissions[i];
					separatorIndexOf=tmpLine.lastIndexOf(';');
					path=tmpLine.substring(0,separatorIndexOf);
					attribute=tmpLine.substring(separatorIndexOf+1);

					os.writeBytes("<TR>\n");
					os.writeBytes("<TD><A HREF=\"javascript:removePermissions("+i+")\"><IMG SRC=\"/?action=showImageRecycleBin\" BORDER=0 ALT=\"Unshare this folder (remove from this list)\"></A></TD>\n");

					if (attribute.indexOf('w')!=-1)
					{
						os.writeBytes("<TD><INPUT NAME=write TYPE=checkbox CHECKED></TD>\n");
					}
					else
					{
						os.writeBytes("<TD><INPUT NAME=write TYPE=checkbox></TD>\n");
					}
					if (attribute.indexOf('r')!=-1)
					{
						os.writeBytes("<TD><INPUT NAME=read TYPE=checkbox CHECKED></TD>\n");
					}
					else
					{
						os.writeBytes("<TD><INPUT NAME=read TYPE=checkbox></TD>\n");
					}
					if (attribute.indexOf('c')!=-1)
					{
						os.writeBytes("<TD><INPUT NAME=create TYPE=checkbox CHECKED></TD>\n");
					}
					else
					{
						os.writeBytes("<TD><INPUT NAME=create TYPE=checkbox></TD>\n");
					}
					if (attribute.indexOf('l')!=-1)
					{
						os.writeBytes("<TD><INPUT NAME=list TYPE=checkbox CHECKED></TD>\n");
					}
					else
					{
						os.writeBytes("<TD><INPUT NAME=list TYPE=checkbox></TD>\n");
					}
					if (path.endsWith("*"))
					{
						String tmpPath=path.substring(0,path.length()-1);
						os.writeBytes("<TD><INPUT NAME=subdir TYPE=checkbox CHECKED></TD>\n");
						os.writeBytes("<TD><INPUT TYPE=hidden NAME=\"path"+i+"\" VALUE=\""+tmpPath+"\">\n");
						os.writeBytes("<A HREF=\""+tmpPath+"\" TARGET=\"_blank\">"+tmpPath+"</A></TD>\n");
					}
					else
					{
						os.writeBytes("<TD><INPUT NAME=subdir TYPE=checkbox></TD>\n");
						os.writeBytes("<TD><INPUT TYPE=hidden NAME=\"path"+i+"\" VALUE=\""+path+"\">\n");
						os.writeBytes("<A HREF=\""+path+"\" TARGET=\"_blank\">"+path+"</A></TD>\n");
					}
					os.writeBytes("</TR>\n");
				}
				if (i_lengthAllPermissions==0)
				{
					os.writeBytes("<TR><TD COLSPAN=7><I>No directories shared</I></TD></TR>\n");
					os.writeBytes("</TABLE>\n");
				}
				else
				{
					os.writeBytes("</TABLE>\n");
				}

				os.writeBytes("<INPUT TYPE=button VALUE=\"Update permissions\" onClick=\"updatePermissions()\">\n");
			}
			else
			{
				//Show nothing if nothing in list
			}

			os.writeBytes("</FORM>\n");
			os.writeBytes("<TABLE BGCOLOR=silver BORDER=2 BORDERCOLORDARK=black BORDERCOLORLIGHT=black BORDERCOLOR=black CELLPADDING=2 CELLSPACING=0>\n");
			os.writeBytes("<TR><TD COLSPAN=2><B>Different kind of permissions</B></TD></TR>\n");
			os.writeBytes("<TR><TD><B>W&nbsp;=&nbsp;Write</B>&nbsp;permissions</TD><TD BGCOLOR=\"#eeeeee\">User can delete, overwrite and create files/folders in this folder.</TD></TR>\n");
			os.writeBytes("<TR><TD><B>R&nbsp;=&nbsp;Read</B>&nbsp;permissions</TD><TD BGCOLOR=\"#eeeeee\">User can read and download files in this folder.</TD></TR>\n");
			os.writeBytes("<TR><TD><B>C&nbsp;=&nbsp;Create</B>&nbsp;new&nbsp;files</TD><TD BGCOLOR=\"#eeeeee\">User can can create new files/folders, but can not delete or overwrite existing files.</TD></TR>\n");
			os.writeBytes("<TR><TD><B>L&nbsp;=&nbsp;List</B>&nbsp;directories</TD><TD BGCOLOR=\"#eeeeee\">User can see the what files/folders are stored in this directory.</TD></TR>\n");
			os.writeBytes("<TR><TD><B>S&nbsp;=&nbsp;Subdirectories</B></TD><TD BGCOLOR=\"#eeeeee\">All permissions for this folder shall also apply for subdirectories.</TD></TR>\n");
			os.writeBytes("</TABLE>\n");
			os.writeBytes("<BR>\n");
			os.writeBytes("\"<B>W</B>rite permissions\" means that the user has permissions to do anything to files in a folder.");
			os.writeBytes("<BR>\n");
			os.writeBytes("\"<B>C</B>reate new files\" does only give permissions to create new files.\n");
			os.writeBytes("<BR>\n");
			os.writeBytes("If both <B>W</B> and <B>C</B> are selected, <B>C</B> is \"ignored\" as <B>W</B> is more powerful.\n");
			os.writeBytes("<P>\n");
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("userNameIs(\""+UD_userData.getUsername()+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showAliasesInfo:\n"+e);}
	}


	public static void showPasswordInfo(DataOutputStream os, UserData UD_userData)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("userNameIs(\""+UD_userData.getUsername()+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showPasswordInfo:\n"+e);}
	}


	public static void showGeneralInfo(DataOutputStream os, FTPSettings FTPS_settings)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("setPortNr(\""+FTPS_settings.i_portNr+"\");\n");
			os.writeBytes("setShowAlias(\""+FTPS_settings.i_howToShowAlias+"\");\n");

			if (FTPS_settings.b_guestAccountExists)
				os.writeBytes("setGuestAccount(\"1\");\n");
			else
				os.writeBytes("setGuestAccount(\"0\");\n");

			os.writeBytes("setLogFile(\""+makeJSFriendly(FTPS_settings.s_logFile,"\"")+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showGeneralInfo:\n"+e);}
	}


	public static void showAdvancedInfo(DataOutputStream os, FTPSettings FTPS_settings)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("setMaxIdleTime(\""+FTPS_settings.i_maxTimeToIdle/1000+"\");\n");
			os.writeBytes("setMaxNOOPAllowed(\""+FTPS_settings.i_maxNumberOfNOOP+"\");\n");
			os.writeBytes("setDataPortNr(\""+FTPS_settings.i_dataPortNr+"\");\n");
			os.writeBytes("setLocalIP(\""+FTPS_settings.s_localIP+"\");\n");
			os.writeBytes("setOuterIP(\""+FTPS_settings.s_outerIP+"\");\n");
			String s_rangeValue;
			if (FTPS_settings.ai_portRange == null)
			    s_rangeValue = "";
			else
			    s_rangeValue = FTPS_settings.ai_portRange[0] + "," + FTPS_settings.ai_portRange[1];
			os.writeBytes("setPassiveRange(\""+s_rangeValue+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showAdvancedInfo:\n"+e);}
	}

	public static void showReloadUserFrame(DataOutputStream os)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("parent.usermenu.location.reload();\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showReloadUserFrame:\n"+e);}
	}


	public static void showInvalidrequest(DataOutputStream os)
	{
		try {
			os.writeBytes("<HTML><HEAD><TITLE>An invalid request was made...</TITLE><BODY BGCOLOR=white TEXT=black>\n");
			os.writeBytes("An invalid request was made...\n");
			os.writeBytes("</BODY></HTML>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showInvalidrequest:\n"+e);}
	}


	public static void showAlertInfo(DataOutputStream os, String txt)
	{
		try {
			os.writeBytes("<SCRIPT>\n");
			os.writeBytes("alert(\""+txt+"\");\n");
			os.writeBytes("</SCRIPT>");
		}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showAlertInfo:\n"+e);}
	}


	//terminator shall be " or ' depending on if the JS-string is 'string' or "string"
	private static String makeJSFriendly(String s, String terminator)
	{
		s=MyString.searchAndReplace(s,"\\","\\\\");
		s=MyString.searchAndReplace(s,terminator,"\\"+terminator);
		return s;
	}
}