//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import ftp_server.*;
import webserver.*;
import java.util.BitSet;
import java.io.File;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>MyString</CODE> is a very useful class.
 * <BR>
 * All members in <CODE>MyString</CODE> are <CODE>static</CODE>.
 * <BR>
 * By the name of the members you are supposed to understand what they do. ;)
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MyString		//Contains only static members
{
/*
	public static void main(String  [] s)
	{
		String path;

		path="aa/..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="./aa/bb/..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="./aa/bb/cc";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="./aa/bb/../cc";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="./aa/bb/cc/../../dd";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="aa/bb/../../../../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/aa/bb/../../../../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="aa/bb/../../../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/aa/bb/../../../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="aa/bb/../../../../..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/aa/bb/../../../../..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="aa/bb/../../../..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/aa/bb/../../../..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="..";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path=".";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/abc/def/../../";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/abc/def/../../.";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/abc/def/../../cc/./dd";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/abc/./d/";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="/aa/./bb/./././../cc/../dd";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="../../..///aa/./bb/././//.////../cc/../dd";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
		path="c:/aa/../../../b/";
		System.out.println(path+"\t\t"+makeCanonicalPath(path));
	}
*/

	private MyString()
	{
	}

	public static boolean stringExistInArrayIgnoreCase(String str, String [] strArray)
	{
		for (int i=0, strArrayLength=strArray.length; i<strArrayLength; i++)	//Optimization...
			if (str.equalsIgnoreCase(strArray[i]))
				return true;
		return false;
	}


    /**
     * "12345678" ==> "12'345'678"
     */
	public static String makeNumberToStringWithApostrophe(String txt)
	{

		while ((txt.indexOf("'") > 3 || txt.indexOf("'")==-1) && txt.length() > 3)
		{
			int txtIndexOfApostrophe=txt.indexOf("'");	//Optimization...
			if (txtIndexOfApostrophe != -1)
				txt=txt.substring(0,txtIndexOfApostrophe-3)+"'"+txt.substring(txtIndexOfApostrophe-3);
			else
			{
				int txtLengthMinus3=txt.length()-3;
				txt=txt.substring(0,txtLengthMinus3)+"'"+txt.substring(txtLengthMinus3);
			}
		}

		return txt;
	}



    /**
     * Number of times  "subString" can be found in "bigString".
     */
	public static int numberOfStringsInString(String bigString, String subString)
	{
		if (subString.equals(""))	//If subString is an empty string, my definition of this method is to return bigString.length()
			return bigString.length();

		int raknare=0,
		    bigStringLength=bigString.length(),
                subStringLength=subString.length();	//Optimization...
		int forUntilThis=bigStringLength-subStringLength+1;	//Optimization...

		for (int i=0; i<forUntilThis; i++)	//Optimization...
			if (bigString.substring(i,i+subStringLength).equals(subString))
				raknare++;
		return raknare;
	}


    /**
     * Number of times  "subString" can be found in "bigString". If returnHighValue equals "false" then "aaaa" and "aa" ==> 2. If returnHighValue equals "false" then "aaaa" and "aa" ==> 3.
     */
	public static int numberOfStringsInString(String bigString, String subString, boolean returnHighValue)
	{
		if (subString.equals(""))	//If subString is an empty string, my definition of this method is to return bigString.length()
			return bigString.length();

		if (returnHighValue)
			return numberOfStringsInString(bigString, subString);
		else
		{
			int raknare=0;
			int bigStringLength=bigString.length(),
			    subStringLength=subString.length();
			int forUntilThis=bigStringLength-subStringLength+1;
			for (int i=0; i<forUntilThis; i++)
				if (bigString.substring(i,i+subStringLength).equals(subString))
				{
					i+=subStringLength-1;
					raknare++;
				}
			return raknare;
		}
	}


    /**
     * Search "bigString" for "oldStr" and replace it with "newStr"
     */
	public static String searchAndReplace(String bigString, String oldStr, String newStr)
	{
		String storStrang=bigString;
		int oldStrLength=oldStr.length(),
		    newStrLengthMinusOne=newStr.length()-1;	//Optimization...
		for (int i=0; i<=storStrang.length()-oldStrLength; i++)
		{
			if (storStrang.substring(i,i+oldStrLength).equals(oldStr))
			{
				storStrang=storStrang.substring(0,i)+newStr+storStrang.substring(i+oldStrLength);
				i+=newStrLengthMinusOne;	//Without this the loop will go on forever if you try to replace all "/" with "//" in this string "ab/cd"
			}
		}
		return storStrang;
	}


    /**
     * Make [String:] "a,b,c" ==> [Array:] "a","b,"c"
     */
	public static String [] makeArrayOfString(String str, String separate)
	{
		if (str.equals(""))
		{
			return new String[0];
		}

		String theString=str;
		int numberOfSeparates,
		    separateLength=separate.length();	//Optimization...
		String [] newArray;
		numberOfSeparates=MyString.numberOfStringsInString(theString, separate, false);

		if (separateLength==0)
		{
			int index=0,
			    strLength=str.length();	//Optimization...
			newArray=new String[strLength];
			for (int i=0; i<strLength; i++)
			{
				newArray[index]=str.substring(i,i+1);
			}
		}
		else
		{
			newArray=new String[numberOfSeparates+1];
			int index=0,
			    theStringIndexOfSeparate;	//Optimization...
			while (theString.indexOf(separate)!=-1 && theString.length()>0)
			{
				theStringIndexOfSeparate=theString.indexOf(separate);	//Optimization...
				newArray[index++]=theString.substring(0,theStringIndexOfSeparate);
				theString=theString.substring(theStringIndexOfSeparate+separateLength);
			}
			newArray[index]=theString;
		}//else
		return newArray;
	}


    /**
     * Returns a String with a fix length:
     * <BR>
     * ("abc",5," ") ==> "abc  "
     */
	public static String giveStringWithFixLength(String s, int len, char ch)
	{
		String tmpStr=s;
		if (s==null)
		{
			tmpStr="";
			for (int i=0; i<len; i++)
				tmpStr+=ch;
			return tmpStr;
		}

		int sLength=s.length();
		int lenMinusSLength=len-sLength;	//Optimization...

		if (sLength>len)
			return s.substring(0,len);

		StringBuffer SB_str=new StringBuffer(tmpStr);
		for (int i=0; i<lenMinusSLength; i++)
			SB_str.append(ch);

		return SB_str.toString();
	}





	/**
	* If you set <CODE>b_useSlash</CODE> to true you shall use /, otherwise use \ in your paths.
	*
	* This will take a relative path and remove all . and .. in a proper way.
	* The easiest way to display how this method works is with a few examples:
	*
	* <PRE>
	* aa/..
	* ./aa/bb/..                      aa/
	* ./aa/bb/cc                      aa/bb/cc
	* ./aa/bb/../cc                   aa/cc
	* ./aa/bb/cc/../../dd             aa/dd
	* aa/bb/../../../../../           ../../../
	* /aa/bb/../../../../../          /../../../
	* aa/bb/../../../../              ../../
	* /aa/bb/../../../../             /../../
	* aa/bb/../../../../..            ../../..
	* /aa/bb/../../../../..           /../../..
	* aa/bb/../../../..               ../..
	* /aa/bb/../../../..              /../..
	* ../../                          ../../
	* /../../                         /../../
	* ..                              ..
	* .                               .
	* /abc/def/../../                 /
	* /abc/def/../../.                /
	* /abc/def/../../cc/./dd          /cc/dd
	* /abc/./d/                       /abc/d/
	* /aa/./bb/./././../cc/../dd      /aa/dd
	* c:/aa/../../../b/               ../b/
	* ../../..///aa/./bb/././//.//../cc/../dd      ../../../aa/dd
	* </PRE>
	*
	*
	*/
	public static String makeCanonicalPath(String path, boolean b_useSlash)
	{
		if (path==null)
		{
			return path;
		}
		else if (path.indexOf('.')!=-1)
		{
			String ss, sds, sdds, dds, ds, sdd, sd;	//s=slash, d=dot
			char sChar;
			if (b_useSlash)
			{
				sChar='/';
				ss="//";
				sds="/./";
				sdds="/../";
				dds="../";
				ds="./";
				sdd="/..";
				sd="/.";
			}
			else
			{
				sChar='\\';
				ss="\\\\";
				sds="\\.\\";
				sdds="\\..\\";
				dds="..\\";
				ds=".\\";
				sdd="\\..";
				sd="\\.";
			}

			//Remove all // and replace with /
			int doubleSlash=path.indexOf(ss);
			while (doubleSlash!=-1)
			{
				path=path.substring(0,doubleSlash)+path.substring(doubleSlash+1);
				doubleSlash=path.indexOf(ss);
			}

			//Remove all /./
			int firstDot=path.indexOf(sds);
			while (firstDot!=-1)
			{
				path=path.substring(0,firstDot)+path.substring(firstDot+2);
				firstDot=path.indexOf(sds);
			}

			//Remove all /../
			int firstDotDot=path.indexOf(sdds);
			while (firstDotDot!=-1)
			{
				int prevSlash=path.lastIndexOf(sChar,firstDotDot-1);
				if (prevSlash!=-1)
				{
					String parentDir=path.substring(prevSlash+1,firstDotDot);
					if (parentDir.equals(".."))
					{
						firstDotDot=path.indexOf(sdds, firstDotDot+1);
					}
					else
					{
						path=path.substring(0,prevSlash+1)+path.substring(firstDotDot+4);
						firstDotDot=path.indexOf(sdds);
					}
				}
				else
				{
					if (firstDotDot==0 || path.startsWith(dds) || path.startsWith(ds))
						firstDotDot=path.indexOf(sdds, firstDotDot+1);
					else
					{
						path=path.substring(firstDotDot+4);
						firstDotDot=path.indexOf(sdds);
					}
				}
			}

			//Remove all /.. in end (note: for example "../.." or "/../../.." doesn't get modifed)
			while (path.endsWith(sdd))
			{
				int lastDotDot=path.length()-3;
				int prevSlash=path.lastIndexOf(sChar,path.length()-4);
				if (prevSlash!=-1)
				{
					String parentDir=path.substring(prevSlash+1,lastDotDot);

					if (parentDir.equals(".."))
					{
						break;
					}
					else
					{
						path=path.substring(0,prevSlash+1);
						lastDotDot=path.indexOf(sdd);
					}
				}
				else
				{
					if (path.startsWith(dds))
						break;
					else
						path="";
				}
			}

			//Remove last dot if string ends with /.
			if (path.endsWith(sd))
			{
				path=path.substring(0,path.length()-1);
			}

			//Remove the first ./ in string
			if (path.startsWith(ds))
			{
				path=path.substring(2);
			}

			return path;
		}
		else
		{
			return path;	//No . in path
		}
	}

	/**
	* This returns <CODE>makeCanonicalPath(path, (File.separatorChar=='/'))</CODE>,
	* which means that the paths sent to <CODE>makeCanonicalPath</CODE> shall use
	* \ if you use Windows and / if you use for example UNIX, Linux or Mac.
	*
	* Please see documentation for <CODE>makeCanonicalPath(String path, boolean b_useSlash)</CODE>
	* for more detailed information about this method.
	*/
	public static String makeCanonicalPath(String path)
	{
		return makeCanonicalPath(path, (File.separatorChar=='/'));
	}




	public static String unescapeMakePlusesIntoSpaces(String s)
//	    throws ParseException
	{
		if (s==null)
			return null;
		else
			return UnescapeMethods.unescape(s.replace('+',' '), null);
	}


	public static String unescape(String s)
//	    throws ParseException
	{
		return UnescapeMethods.unescape(s, null);
	}

}


