//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is the install program for Xerver.
 * The user can choose in which directory shall be created and can crate new directories on his harddrive.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class SetupWindow extends JFrame implements MouseListener, ListSelectionListener
{
	private JFolderChooser JFC_folderChooser;
	private JFolderChooser JFC_driverChooser;

	private JButton JB_exitButton;
	private JButton JB_extractButton;
	private JButton JB_createFolderButton;
	private JTextField JTF_installPath;

	public static void main(String [] s)
	{
	try {
    //    UIManager.setLookAndFeel(
    //        UIManager.getCrossPlatformLookAndFeelClassName());
				UIManager.setLookAndFeel(
    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); //Try to use Windows interface
    } catch (Exception e) { }

		new SetupWindow();
	}

	SetupWindow()
	{
		JFC_driverChooser=new JFolderChooser(null);//null=show drivers
		JFC_folderChooser=new JFolderChooser((new PathInfo(null)).getAllDirsWithReadAccess()[0].getPath());

		JFC_driverChooser.addListSelectionListener(this);
		JFC_folderChooser.addListSelectionListener(this);

		Container CP=getContentPane();
		Container CPpath=new Container();
		Container CPdrivers=new Container();
		Container CPfolders=new Container();
		Container CPleft=new Container();
		Container CPlagrebuttons=new Container();
		Container CPbuttons=new Container();	//Inte "BorderLayout"

		CP.setLayout(new BorderLayout());
		CPpath.setLayout(new BorderLayout());
		CPdrivers.setLayout(new BorderLayout());
		CPfolders.setLayout(new BorderLayout());
		CPleft.setLayout(new BorderLayout());
		CPlagrebuttons.setLayout(new BorderLayout());
		CPbuttons.setLayout(new GridLayout(2,1));

		JB_exitButton=new JButton("Exit");
		JB_exitButton.addMouseListener(this);
		JB_createFolderButton=new JButton("Create New Folder");
		JB_createFolderButton.addMouseListener(this);
		CPbuttons.add(JB_createFolderButton);
		CPbuttons.add(JB_exitButton);

		JTF_installPath=new JTextField(JFC_folderChooser.getPath());
		JTF_installPath.setEditable(false);
		JTF_installPath.setDisabledTextColor(Color.red);
		JTF_installPath.setSelectedTextColor(Color.red);
		JTF_installPath.setForeground(Color.red);
		JTF_installPath.setBackground(Color.black);
		JB_extractButton=new JButton("Extract files");
		JB_extractButton.addMouseListener(this);
		CPpath.add(JB_extractButton, BorderLayout.WEST);
		CPpath.add(JTF_installPath, BorderLayout.CENTER);

		CPdrivers.add(new JLabel("Drivers:"), BorderLayout.NORTH);
		CPdrivers.add(JFC_driverChooser, BorderLayout.CENTER);

		CPleft.add(CPdrivers, BorderLayout.NORTH);
		CPleft.add(CPlagrebuttons, BorderLayout.CENTER);

		CPlagrebuttons.add(CPbuttons, BorderLayout.NORTH);
		CPlagrebuttons.add(new JLabel(""), BorderLayout.CENTER);

		CPfolders.add(new JLabel("Folders in drive:"), BorderLayout.NORTH);
		CPfolders.add(JFC_folderChooser, BorderLayout.CENTER);

		CP.add(CPleft, BorderLayout.WEST);
		CP.add(CPfolders, BorderLayout.CENTER);
		CP.add(CPpath, BorderLayout.SOUTH);

		CP.validate();

		setTitle("Install Xerver");
		JFC_driverChooser.setVisibleRowCount(4);
		JFC_folderChooser.setVisibleRowCount(20);
		addWindowListener(MyWindowListener);
		setSize(600,400);
		setVisible(true);
		toFront();
	}

	/**
	* Extract Xerver files into <CODE>JTF_installPath.getText()</CODE>.
	*/
	private void extractFiles()
	{
		new InstallXerver(JTF_installPath.getText());
		if (File.separatorChar=='\\')	//Windows user...
		{
			try {
			JOptionPane.showMessageDialog(null, "Xerver has been successfully installed at:\n"+JTF_installPath.getText()+"\n\nPress OK to quit installer and start Xerver (this might take a few seconds).", "Xerver successfully installed", JOptionPane.INFORMATION_MESSAGE);
			setVisible(false);
			dispose();	//Close install program
			Runtime run;
			Process proc;
			run = Runtime.getRuntime();
			System.out.println("Xerver is now running...");
			proc = run.exec("\""+JTF_installPath.getText()+File.separator+"dontrun.bat\" \""+JTF_installPath.getText()+File.separator+"\"");	//By default c: is shared, so start Xerver for Windows users...
			proc.waitFor();
			System.exit(0);
			} catch (Exception e) {};
			//JOptionPane.showMessageDialog(null, "You can start Xerver by starting:\n"+JTF_installPath.getText()+File.separator+"StartXerver.exe", "Start Xerver", JOptionPane.INFORMATION_MESSAGE);
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Xerver has been successfully installed at:\n"+JTF_installPath.getText()+"\n\nTo start Xerver Setup, type \"java SetupXerver\" when you are located at:\n"+JTF_installPath.getText()+File.separator, "Start Xerver Setup", JOptionPane.INFORMATION_MESSAGE);	//Non-windows users might prefer a setup-window.
			System.exit(0);
		}
	}

	/**
	* Prompt the user for a directory name and then create then directory.
	*/
	private void createNewDir()
	{
		String s_newFolder=(String)JOptionPane.showInputDialog(null, "New folder name:", "Create new folder", JOptionPane.QUESTION_MESSAGE, null, null, "Xerver");
		if (s_newFolder!=null)
		{
			if (!s_newFolder.equals(""))
			{
				String s_newPath=JFC_folderChooser.getPath()+File.separator+s_newFolder;
				File f_newFolder=new File(s_newPath);

				if (f_newFolder.mkdir())
				{
					JFC_folderChooser.setNewPath(f_newFolder.getPath());
					JTF_installPath.setText(f_newFolder.getPath());
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Could not create:\n"+f_newFolder.getPath()+"\n\nThe folder might already exists,\nthe folder might contain illegal characters or\nyou might not have permission to create the folder.", "Error creating folder", JOptionPane.ERROR_MESSAGE);
				}
				getContentPane().validate();
			}
		}
	}


	public void mouseClicked(MouseEvent e)
	{
		if (e.getSource()==JB_extractButton)
		{
			if (JOptionPane.YES_OPTION==JOptionPane.showConfirmDialog(null, "Extract and install Xerver files to "+JTF_installPath.getText()+"?", "Extract Xerver", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE))
				extractFiles();
		}
		else if (e.getSource()==JB_exitButton)
		{
			if (JOptionPane.YES_OPTION==JOptionPane.showConfirmDialog(null, "Exit Xerver Installer?", "Exit Xerver Installer?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE))
				System.exit(0);
		}
		else if (e.getSource()==JB_createFolderButton)
		{
			createNewDir();
		}

		getContentPane().validate();
	}

	/* "Do nothing"-events */
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}

	public void valueChanged(ListSelectionEvent e)
	{
		JList JT=(JList)e.getSource();
		MyFile selectedFile=(MyFile)JT.getSelectedValue();
		//int selRow = JT.getRowForLocation(e.getX(), e.getY());
		//TreePath selPath = JT.getPathForLocation(e.getX(), e.getY());

		if (!JT.isSelectionEmpty())
		{
			JTF_installPath.setText(selectedFile.getPath());
			JFC_folderChooser.setNewPath(selectedFile.getPath());
		}
		getContentPane().validate();
	}

	private WindowAdapter MyWindowListener = new WindowAdapter()
	{
		public void windowClosing(WindowEvent e)	//Window is closeing
		{
			System.exit(0);
		}
	};
}