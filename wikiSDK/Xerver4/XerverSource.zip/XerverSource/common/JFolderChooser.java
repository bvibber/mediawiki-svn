//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import ftp_server.*;
import webserver.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>JFolderChooser</CODE> is used to get a JList in which the user can choose a folder/root (drive) (see constuctor).
 * <BR>
 * This can be used to decide in which drive and in which folder Xerver shall be installed.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */
final public class JFolderChooser extends Container
{
	private JList theJList;
	private JScrollPane JSP;
	private ListSelectionListener theLSL;
	private MyFile [] listOfFiles;
	private String s_location;

/**
 * If argLocation==null all roots (for example c:\ and d:\) will be listed.
 */
	public JFolderChooser(String argLocation)
	{
		s_location=argLocation;
		setLayout(new GridLayout(1,1));
		setNewPath(s_location);
	}

/**
 * Add a ListSelectionListener to the JList inside this JFolderChooser.
 */
	public void addListSelectionListener(ListSelectionListener argLSL)
	{
		theLSL=argLSL;
		theJList.addListSelectionListener(theLSL);
	}

/**
 * Choose which folder shall be listed.
 */
	public void setNewPath(String argLocation)
	{
		s_location=argLocation;
		removeAll();
		listOfFiles=(new PathInfo(s_location)).getAllDirsWithReadAccess();
		theJList=new JList(listOfFiles);
		theJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//theJList.addMouseListener(new myMouseListener());
		JSP=new JScrollPane(theJList);

		add(JSP);

		if (theLSL!=null)
			theJList.addListSelectionListener(theLSL);
	}

/**
 * This simply returns the object which holds in this data.
 * As JFolderChooser is written now this always returns a JList.
 * However, in case someone choose to write a subclass of JFolderChooser with for example a
 * JTree (instead of a JList) this method might always return an JTree.
 */
	public Object getDataContainer()
	{
		return theJList;
	}

/**
 * Set how many rows shall be viewable in the JList.
 */
	public void setVisibleRowCount(int nr)
	{
		theJList.setVisibleRowCount(nr);
	}

/**
 * Returns a MyFile for the entry at index "nr".
 */
	public MyFile getFileAtIndex(int nr)
	{
		return listOfFiles[nr];
	}

/**
 * Get the path for the folder/root which the user has currently choosed.
 */
	public String getPath()
	{
		return s_location;
	}
}
