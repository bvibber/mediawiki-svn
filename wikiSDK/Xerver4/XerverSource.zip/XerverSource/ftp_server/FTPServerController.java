//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################




package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * Want to bound Xerver Free FTP Server to your GNU GPL application?
 * <BR>
 * Then this is the only class your program will use directly.
 * <BR>
 * You shall not have to learn about the other classes that are used.
 * <BR>
 * All methods in this class are static.
 * <BR>
 * <BR>
 * When Xerver Free FTP Server was written it was designed to be easy to bound with other applications.
 * <BR>
 * Xerver Free Web Server is for example using Xerver Free FTP Server.
 * <BR>
 * <BR>
 * <B>To start using Xerver Free FTP Server in your own application follow these steps:</B>
 * <BR>
 * 1.) Download the source files for Xerver Free Web Server.
 * <BR>
 * 2.) Copy the folders called "ftp_server" and "common" to the directory where you have stored your Java GNU GPL application.
 * <BR>
 * 3.) Add "<CODE>import ftp_server.*;import common.*;</CODE>" to the top of all your .java-files.
 * <BR>
 * 4.) You're done! Now you can call the methods of this class and start the FTP server.
 * <BR>
 * <BR>
 * <B>Examples:</B>
 * <BR>
 * Here is an example to show you how you can easily implement Xerver Free FTP Server into your application.
 * <BR>
 * <FONT COLOR=gray>
 * <PRE>
 * <FONT COLOR=red>import ftp_server.*;</FONT>
 * <FONT COLOR=red>import common.*;</FONT>
 *
 * class Dummy
 * {
 *    public static void main(String [] s)
 *    {
 *       <FONT COLOR=red>FTPServerController.startFTPServer();</FONT>
 *       System.out.println(<FONT COLOR=blue>"Xerver Free FTP Server "</FONT>+<FONT COLOR=red>FTPServerController.getVersionString()</FONT>+<FONT COLOR=blue>" is running."</FONT>);
 *       System.out.println(<FONT COLOR=blue>"Connect to "</FONT>+<FONT COLOR=red>FTPServerController.getIP()</FONT>);
 *       System.out.println(<FONT COLOR=blue>"at port "</FONT>+<FONT COLOR=red>FTPServerController.getPort()</FONT>+<FONT COLOR=blue>"."</FONT>);
 *
 *       <FONT COLOR=red>FTPServerController.stopFTPServer();</FONT>
 *       System.out.println(<FONT COLOR=blue>"You can no longer connect to "</FONT>+<FONT COLOR=red>FTPServerController.getIP()</FONT>+<FONT COLOR=blue>"."</FONT>);
 *
 *       <FONT COLOR=red>FTPServerController.startFTPLocalSetup();</FONT>
 *       System.out.println(<FONT COLOR=blue>"Only you (=your IP) can now visit Xerver FTP Setup at:"</FONT>);
 *       System.out.println(<FONT COLOR=blue>"http://"</FONT>+<FONT COLOR=red>FTPServerController.getIP()</FONT>+<FONT COLOR=blue>":"</FONT>+<FONT COLOR=red>FTPServerController.getSetupPort()</FONT>+<FONT COLOR=blue>"/"</FONT>);
 *
 *       <FONT COLOR=red>FTPServerController.startFTPRemoteSetup();</FONT>
 *       System.out.println(<FONT COLOR=blue>"Anyone (any IP) can now visit Xerver FTP Setup at:"</FONT>);
 *       System.out.println(<FONT COLOR=blue>"http://"</FONT>+<FONT COLOR=red>FTPServerController.getIP()</FONT>+<FONT COLOR=blue>":"</FONT>+<FONT COLOR=red>FTPServerController.getSetupPort()</FONT>+<FONT COLOR=blue>"/"</FONT>);
 *
 *       <FONT COLOR=red>FTPServerController.startFTPLocalSetup();</FONT>
 *       System.out.println(<FONT COLOR=blue>"Only you (=your IP) can now visit Xerver FTP Setup at:"</FONT>);
 *       System.out.println(<FONT COLOR=blue>"http://"</FONT>+<FONT COLOR=red>FTPServerController.getIP()</FONT>+<FONT COLOR=blue>":"</FONT>+<FONT COLOR=red>FTPServerController.getSetupPort()</FONT>+<FONT COLOR=blue>"/"</FONT>);
 *       System.out.println(<FONT COLOR=blue>"Remote computers can no longer reach setup."</FONT>);
 *
 *       System.out.println(<FONT COLOR=blue>"Can it be easier to implement an FTP server or what? :)"</FONT>);
 *       System.out.println(<FONT COLOR=blue>"Enjoy Xerver Free FTP Server!"</FONT>);
 *    }//main
 * }//class
 * </PRE>
 * </FONT>
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class FTPServerController
{
	private static FTPServer server=null;
	private static FTPSetup setup=null;

	private static final double d_FTPversion=2.00;
	private static final String s_FTPversion="2.00";

	private static String s_serverIP=null;

	public final static String s_initFile="ftp_data"+File.separator+"FTP2.cfg";
	public final static String s_dataFolder="ftp_data"+File.separator;
	public final static String s_userFolder="users"+File.separator;
/*
	public final static String s_initFile="ftp_server"+File.separator+"data"+File.separator+"FTP2.cfg";
	public final static String s_dataFolder="ftp_server"+File.separator+"data"+File.separator;
	public final static String s_userFolder="ftp_server"+File.separator+"users"+File.separator;
*/
	public final static String s_userDataExtension=".dat";

	public static void main(String [] s)
	{
		startFTPServer();
		startFTPLocalSetup();
	}


	/**
	* Starts the FTP server.
	*/
	public static void startFTPServer()
	{
		if (server==null)	//If [server has not started] or [port number has changed (then restart server)]...
		{
			server=new FTPServer();
			server.start();
		}

		server.startFTPServer();
	}


	/**
	* Stops the FTP server.
	*/
	public static void stopFTPServer()
	{
		/*
		if (server==null)
		{
			server=new FTPServer();
			server.start();
		}
		*/
		if (server!=null)
		{
			server.stopFTPServer();
		}
	}



	/**
	* This will start FTP Setup and it allows everyone to reach the setup and change settings to the server.
	*/
	public static void startFTPRemoteSetup()
	{
		if (setup==null)
		{
			setup=new FTPSetup();
			setup.start();
		}

		setup.startFTPSetup();
	}

	/**
	* This will start FTP Setup but only allows your local IP to visit the setup and change settings to the server.
	*/
	//Turn off remote setup if already turned on
	public static void startFTPLocalSetup()
	{
		if (setup==null)
		{
			setup=new FTPSetup();
			setup.start();
		}

		setup.stopFTPSetup();
	}

	/**
	* This is the same as <CODE>startFTPLocalSetup()</CODE>!
	* <BR>
	* Despite the name, this does not turn off the Xerver FTP Setup.
	* <BR>
	* Your local IP is always allowed to change settings in setup.
	*/
	public static void stopFTPSetup()
	{
		if (setup==null)
		{
			setup=new FTPSetup();
			setup.start();
		}

		setup.stopFTPSetup();
	}



	/**
	* Get the version of Xerver Free FTP Server.
	*/
	public static String getVersionString()
	{
		return s_FTPversion;
	}

	/**
	* Get the version of Xerver Free FTP Server.
	*/
	public static double getVersion()
	{
		return d_FTPversion;
	}

	/**
	* Get your outer IP (the IP that is shown to computers outside your network).
	*/
	public static String getIP()
	{
		if (s_serverIP==null)
		{
			s_serverIP=HostInfo.getOuterIPOrLocalhost();
		}

		return s_serverIP;
	}

	/**
	* Get the port the server is listening for.
	* Clients shall connect to this port.
	*/
	public static int getPort()
	{
		if (server==null)
			return -1;
		else
			return server.getPort();
	}

	/**
	* Get the port the server setup is listening to.
	* Your browser shall connect to http://localhost:PortNumber/
	* when you want change settings.
	*/
	public static int getSetupPort()
	{
		return FTPSetup.getPort();
	}

	/**
	* Returns true iff the FTP Server port is already in use.
	*/
	public static boolean isPortInUseServer()
	{
		return server.isPortInUse();
	}

	/**
	* Returns true iff we have a port error for the FTP Server (for example if you try to run the server on port 999999).
	*/
	public static boolean getPortErrorServer()
	{
		return server.getPortError();
	}

	/**
	* Returns true iff the FTP Setup Server port is already in use.
	*/
	public static boolean isPortInUseSetup()
	{
		return setup.isPortInUse();
	}

	/**
	* Returns true iff we have a port error for the FTP Setup Server (for example if you try to run the setup server on port 999999).
	*/
	public static boolean getPortErrorSetup()
	{
		return setup.getPortError();
	}
}