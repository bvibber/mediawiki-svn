//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package webserver;
import common.*;
import ftp_server.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class has the members that are run when you do something in the <CODE>ProgramWindow</CODE>.
 * <BR>
 * When you for example choose something from the menu, a member of this class is activated.
 * <BR>
 * The constructor of this class needs a copy of <CODE>ProgramWindow</CODE>.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MenuOptions extends GUIMethods implements ActionListener, FocusListener, DocumentListener
{
	public static int MAX_STATS_ITEMS = 100;	//How many statistic items should we show in the list
	private static final boolean b_showErrors=false;
	private static Font defaultFont;

	//private XerverKernel xerverThread;
	public boolean xerverIsRunning=false,  xerverSetupIsRunning=false;
	private ProgramWindow theProgramWindow;
	private SetupXerverKernel xerverSetupThread;
	public String s_egetIp;
	public int i_portNr;
	private JList JL_allIPConnected;
   	private DefaultListModel DLM_listWithAllIPConnected;
	private JScrollPane JSP_IPScrollPane;
	private JPanel JP_IPPanel;
	private JCheckBox [] JCB_showWhatStatistic;
	private JTextFieldInt [] JTF_showStatisticFieldLength;
	private JTextField JTF_hitsField;
	private JTextField JTF_bytesField;
	private JTextField JTF_connectionsField;
	private JTextFieldInt JTF_nrRows;

	public MenuOptions(ProgramWindow argProgramWindow)
	{
		defaultFont=GUIMethods.defaultFont;
		XerverKernel.setInstance(new XerverKernel(this));
		initSwingButtons();
		updateStatList();
		DLM_listWithAllIPConnected.addElement(new HitStatistic());


		theProgramWindow=argProgramWindow;
		XerverKernel.getInstance().stopXerver();
		XerverKernel.getInstance().start();
		xerverSetupThread=new SetupXerverKernel(this);
		xerverSetupThread.stopXerverSetup();
		xerverSetupThread.start();

		FTPServerController.startFTPLocalSetup();	//Start the FTP Server (but ignore if the port already is in use or not)

		s_egetIp=XerverKernel.getInstance().s_egetIp;
		i_portNr=XerverKernel.getInstance().i_portNr;

		//Start thread to update the stats regulary (showing how many bytes have been downloaded, number of active connections etc.)
		(new StatsUpdater(this)).start();
	}

	/**
	* Update the stats window.
	*/
	public void statsHasBeenUpdated()
	{
		if (theProgramWindow.getCurrentMode()==theProgramWindow.STATS_MODE)
		{
			JTF_hitsField.setText(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfHits+"")+" hits");
			JTF_bytesField.setText(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfBytesDownloaded+"")+" bytes");
			int i_antalConnections = XerverKernel.getInstance().getNumberOfActiveConnections();
			if (i_antalConnections == 1)
			{
				JTF_connectionsField.setText(MyString.makeNumberToStringWithApostrophe(i_antalConnections+"")+" connection");
			}
			else
			{
				JTF_connectionsField.setText(MyString.makeNumberToStringWithApostrophe(i_antalConnections+"")+" connections");
			}
			theProgramWindow.updateStatsContainer();
		}
	}

	public void xerverSetupIsDone(boolean setupIsFinished)
	{
		XerverKernel.getInstance().getServerDefaults();
		XerverKernel.getInstance().stuffToDoAfterSettingsAreReloaded();	//ALWAYS run this after running "getServerDefaults()"

		if (setupIsFinished)
			theProgramWindow.showAsMainFrame(GUIMethods.showAsNorthBorderLayout(showSettingsHaveBeenSaved()));	//we choose to only show this message when the setup is complete... we might prefer to show this as soon as something has been updated (in this case, remove the if-case above)...
	}


	public Container showSettingsHaveBeenSaved()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.SETUPSAVED_MODE);

		String [] showThisText=new String [6];
		showThisText[0]="Xerver Setup has changed settings to Xerver!";
		showThisText[1]="";
		if (xerverSetupIsRunning)
		{
			showThisText[2]="If you feel that you are satisfied with your new settings,";
			showThisText[3]="please turn off the Xerver Remote Setup.";
			showThisText[4]="";
			showThisText[5]="You don't need to restart Xerver!";
		}
		else
		{
			showThisText[2]="You don't need to restart Xerver!";
			showThisText[3]="";
			showThisText[4]="";
			showThisText[5]="";
		}
		return giveContainerWithText(showThisText);
	}


	public void runXerverSetup()
	{
		if (!xerverSetupIsRunning)
		{
			xerverSetupIsRunning=true;
			xerverSetupThread.startXerverSetup();
			theProgramWindow.setStatusText("Xerver Remote Setup is running");
		}// else System.out.println("Xerver is already running!");
	}

	public void stopXerverSetup()
	{
		if (xerverSetupIsRunning)
		{
			xerverSetupIsRunning=false;
			xerverSetupThread.stopXerverSetup();
			theProgramWindow.setStatusText("Xerver Remote Setup is not running");
		}// else System.out.println("Xerver is not running!");
	}


	public void runXerver()
	{
		if (!xerverIsRunning)
		{
			xerverIsRunning=true;
			XerverKernel.getInstance().startXerver();
			theProgramWindow.setStatusText("Xerver is running");
		}// else System.out.println("Xerver is already running!");
	}


	public void stopXerver()
	{
		if (xerverIsRunning)
		{
			xerverIsRunning=false;
			XerverKernel.getInstance().stopXerver();
			theProgramWindow.setStatusText("Xerver is not running");
		}// else System.out.println("Xerver is not running!");
	}

	public void addIPToList(HitStatistic hit)
	{
		DLM_listWithAllIPConnected.addElement(hit);
		if (MAX_STATS_ITEMS >= 0 && DLM_listWithAllIPConnected.size() > MAX_STATS_ITEMS+1)	//Note the +1 because the first entry is not really a log entry but just the header (showing "IP/Host", "Date" etc.)
		    DLM_listWithAllIPConnected.remove(1);
		//JL_allIPConnected.setSelectedIndex(DLM_listWithAllIPConnected.getSize()-1);;
	}

	public Container showTurnOffSetup()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.SETUPTURNEDOFF_MODE);

		String [] showThisText=new String [3];
		showThisText[0]="Xerver Remote Setup has been turned off!";
		showThisText[1]="";
		showThisText[2]="Settings can no longer be saved to Xerver from Internet.";
		return giveContainerWithText(showThisText);
	}

	public Container showTurnOnSetup()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.SETUPTURNEDON_MODE);

		String [] showThisTextUp=new String [3], showThisTextDown=new String [2];
		showThisTextUp[0]="Xerver Remote Setup has been turned on!";
		showThisTextUp[1]="";
		showThisTextUp[2]="A remote administrator can now change settings to Xerver at:";
		JTextField txtIPAdress;

		String s_outerIP = HostInfo.getOuterIP();	//Returns null if not detected
		if (s_outerIP != null)
		{
			txtIPAdress=new JTextField("http://"+s_outerIP+":32123/", 17);
		}
		else
		{
			txtIPAdress=new JTextField("IP could not be detected!", 17);
		}

		txtIPAdress.setBackground(Color.white);
		txtIPAdress.setEditable(false);
		txtIPAdress.setFont(defaultFont);
		showThisTextDown[0]="";
		showThisTextDown[1]="Please turn off Xerver Remote Setup when you feel you are done!";
		return make2ContainersTo1ContainerAbove(make2ContainersTo1ContainerAbove(giveContainerWithText(showThisTextUp),make2ContainersTo1ContainerBeside(txtIPAdress,new JLabel(""))),giveContainerWithText(showThisTextDown));
	}


	public Container showHelp()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.HELP_MODE);

		String [] showThisText=new String [8];
		showThisText[0]="Xerver help pages";
		showThisText[1]="";
		showThisText[2]="Xerver comes with a large number of help files";
		showThisText[3]="categorized by subject. However, the help files";
		showThisText[4]="are written in HTML and are available in the";
		showThisText[5]="help directory in the Xerver directory.";
		showThisText[6]="";
		showThisText[7]="To start using help, start index.html in the help directory.";
		return giveContainerWithText(showThisText);
	}


	public Container showAbout()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.ABOUT_MODE);

		String [] showThisText=new String [14];
		showThisText[0]="You are using Xerver "+XerverKernel.getThisVersionString()+".";
		showThisText[1]="";
		showThisText[2]="This version of Xerver is bounded with";
		showThisText[3]="Xerver Free FTP Server "+FTPServerController.getVersionString()+".";
		showThisText[4]="";
		showThisText[5]="Xerver is an open source project started in January 2002 by";
		showThisText[6]="Omid Rouhani at Chalmers University of Technology, Sweden.";
		showThisText[7]="Xerver has actively been developed since then.";
		showThisText[8]="";
		showThisText[9]="The official website is available at:";
		showThisText[10]="http://www.JavaScript.nu/xerver/";
		showThisText[11]="";
		showThisText[12]="For information about the license,";
		showThisText[13]="please read Xerver License (GNU GPL).";
		return giveContainerWithText(showThisText);
	}

	public Container showXerverSetupInfo()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.SETUP_MODE);

		if (xerverSetupIsRunning)
			theProgramWindow.setStatusText("Xerver Remote Setup is running");
		else
			theProgramWindow.setStatusText("Xerver Remote Setup is not running");


		theProgramWindow.setCurrentMode(ProgramWindow.SETUPTURNEDON_MODE);

		String [] showThisTextUp=new String [3], showThisTextDown=new String [14];
		showThisTextUp[0]="Welcome to \"Xerver Setup\".";
		showThisTextUp[1]="";
		showThisTextUp[2]="You can change settings to Xerver at this adress:";
		JTextField txtIPAdress=new JTextField("http://"+HostInfo.getLocalIPOrLocalhost()+":32123/", 17);
		txtIPAdress.setBackground(Color.white);
		txtIPAdress.setEditable(false);
		txtIPAdress.setFont(defaultFont);
		showThisTextDown[0]="";
		showThisTextDown[1]="However, Xerver is also supporting remote administration.";
		showThisTextDown[2]="";
		showThisTextDown[3]="Remote administartion means that someone on Internet can ";
		showThisTextDown[4]="help you configure Xerver.";
		showThisTextDown[5]="";
		showThisTextDown[6]="Only allow people you trust setup Xerver for you!";
		showThisTextDown[7]="";
		showThisTextDown[8]="For security reasons you must turn on remote administration";
		showThisTextDown[9]="before anyone from Internet can setup Xerver.";
		showThisTextDown[10]="";
		showThisTextDown[11]="You (and only you) can always setup Xerver at the URL given above.";
		showThisTextDown[12]="";
		showThisTextDown[13]="Don't turn on Xerver Remote Setup if you don't want use it!";
		return 	make2ContainersTo1ContainerAbove(
						make2ContainersTo1ContainerAbove(
							giveContainerWithText(showThisTextUp),
							make2ContainersTo1ContainerBeside(
								txtIPAdress,
								new JLabel(""))),
						giveContainerWithText(showThisTextDown));
	}

	public static Container showStatsText()
	{
		String [] showThisText;

		if (NewConnection.l_logFile.getFileName() == null || NewConnection.l_logFile.getFileName().equals(""))
		{
			showThisText=new String [5];
			showThisText[0]="Xerver is currently not writing to the log file on the hard drive.";
			showThisText[1]="";
			showThisText[2]="The latest log entries are shown below (this list is not stored on hard drive).";
			showThisText[3]="(Check what information you want to see and the size of each field in the list below)";
			showThisText[4]="";
		}
		else
		{
			showThisText=new String [6];
			showThisText[0]="Xerver log file:";
			showThisText[1]=NewConnection.l_logFile.getFileName();
			showThisText[2]="";
			showThisText[3]="The latest entries in the log file are shown below.";
			showThisText[4]="(Check what information you want to see and the size of each field in the list below)";
			showThisText[5]="";
		}

		return giveContainerWithText(showThisText);
	}


	public Container showStats()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.STATS_MODE);

		Container statsCP=new Container();
		statsCP.setLayout(new BorderLayout());

			Container statsCP2=new Container();
			statsCP2.setLayout(new BorderLayout());
			statsCP2.add(showButtonsAndTextStats(),BorderLayout.WEST);
			statsCP2.add(new JLabel(""),BorderLayout.CENTER);

		statsCP.add(statsCP2,BorderLayout.NORTH);
		statsCP.add(JP_IPPanel,BorderLayout.CENTER);
		statsCP.add(showBytesAndNrRows(),BorderLayout.SOUTH);

		return statsCP;
	}


	private Container showBytesAndNrRows()
	{

		Container cp=new Container();
		cp.setLayout(new BorderLayout());

		cp.add(showBytesDownloaded(),BorderLayout.WEST);
		cp.add(new JLabel(""),BorderLayout.NORTH);
		cp.add(showNrRowsFields(),BorderLayout.EAST);

		return cp;

	}

	public Container showBytesDownloaded()
	{
		JTF_hitsField.setText(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfHits+"")+" hits");
		JTF_bytesField.setText(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfBytesDownloaded+"")+" bytes");
		JTF_connectionsField.setText(MyString.makeNumberToStringWithApostrophe(XerverKernel.getInstance().getNumberOfActiveConnections()+"")+" connections");
		JTF_hitsField.setBackground(Color.white);
		JTF_bytesField.setBackground(Color.white);
		JTF_connectionsField.setBackground(Color.white);
		JTF_hitsField.setEditable(false);
		JTF_bytesField.setEditable(false);
		JTF_connectionsField.setEditable(false);

		Container threeFields=new Container();
		threeFields.setLayout(new GridLayout(1,3));
		//threeFields.setLayout(new FlowLayout());
		threeFields.add(JTF_hitsField);
		threeFields.add(JTF_bytesField);
		threeFields.add(JTF_connectionsField);

		Container fieldsWithBlankAreas=new Container();
		fieldsWithBlankAreas.setLayout(new BorderLayout());
		fieldsWithBlankAreas.add(threeFields,BorderLayout.WEST);
		fieldsWithBlankAreas.add(ProgramWindow.EMPTY_JLABEL,BorderLayout.CENTER);

		return make2ContainersTo1ContainerAbove(fieldsWithBlankAreas,new JLabel(""));

//		return make2ContainersTo1ContainerBeside(make2ContainersTo1ContainerBeside(JTF_hitsField,JTF_bytesField),make2ContainersTo1ContainerBeside(JTF_connectionsField,ProgramWindow.EMPTY_JLABEL));
	}



	public Container showNrRowsFields()
	{
		Container twoFields=new Container();
		//twoFields.setLayout(new GridLayout(1,2));
		twoFields.setLayout(new FlowLayout());
		twoFields.add(new JLabel("Rows to display:"));
		twoFields.add(showAsNorthAndWestBorderLayout(JTF_nrRows));

		Container fieldsWithBlankAreas=new Container();
		fieldsWithBlankAreas.setLayout(new BorderLayout());
		fieldsWithBlankAreas.add(ProgramWindow.EMPTY_JLABEL, BorderLayout.CENTER);
		fieldsWithBlankAreas.add(twoFields,BorderLayout.EAST);
		return fieldsWithBlankAreas;
//		return make2ContainersTo1ContainerBeside(make2ContainersTo1ContainerBeside(JTF_hitsField,JTF_bytesField),make2ContainersTo1ContainerBeside(JTF_connectionsField,ProgramWindow.EMPTY_JLABEL));
	}


	public Container showButtonsAndTextStats()
	{
		Container statsCP=new Container();
		statsCP.setLayout(new BorderLayout());
		statsCP.add(showStatsText(),BorderLayout.CENTER);
		statsCP.add(showStatsButtons(),BorderLayout.SOUTH);

		return statsCP;
	}


	public Container showStatsButtons()
	{
		Container statsCP=new Container();
		statsCP.setLayout(new GridLayout(2,4));

		for (int i=0, showWhatStatisticLength=JCB_showWhatStatistic.length; i<showWhatStatisticLength; i++)	//Optimization...
		{
			statsCP.add(make2ContainersTo1ContainerBeside(JTF_showStatisticFieldLength[i],JCB_showWhatStatistic[i]));
		}
		statsCP.add(new JLabel(""));


		updateStatList();
		return statsCP;
	}



	public Container checkForUpdates()
	{
		theProgramWindow.setCurrentMode(ProgramWindow.UPDATE_MODE);

		try
		{
			double latestVersionFromNet=getLatestVersion();

			if (XerverKernel.getThisVersion() >= latestVersionFromNet)	//If we currently are running a newer version than the official release (=this is a BETA), then say no new version available
			{
				String [] showThisText=new String [6];
				showThisText[0]="No new version available!";
				showThisText[1]="";
				showThisText[2]="You are currently using the latest version of Xerver ("+XerverKernel.getThisVersionString()+").";
				showThisText[3]="";
				showThisText[4]="The official Xerver website is available at:";
				showThisText[5]="http://www.javascript.nu/xerver/";

				theProgramWindow.setStatusText("No New Version Available!");
				return GUIMethods.showAsNorthBorderLayout(giveContainerWithText(showThisText));
			}
			else	//Regardless if getThisVersion() or latestVersionFromNet is greatest, a new version has been released (as the two versions are different)
			{
				theProgramWindow.setStatusText("New Version Available!");

				String [] showThisTextUp=new String [3], showThisTextDown=new String [14];
				showThisTextUp[0]="New version available!";
				showThisTextUp[1]="";
				showThisTextUp[2]="You can download Xerver "+latestVersionFromNet+" for free at:";
				showThisTextDown[0]="";
				showThisTextDown[1]="You are strongly recommended to download the latest version.";
				JTextField txtIPAdress=new JTextField("http://www.javascript.nu/xerver/", 17);
				txtIPAdress.setBackground(Color.white);
				txtIPAdress.setEditable(false);
				txtIPAdress.setFont(defaultFont);
				return 	make2ContainersTo1ContainerAbove(
						make2ContainersTo1ContainerAbove(
							giveContainerWithText(showThisTextUp),
							make2ContainersTo1ContainerBeside(
								txtIPAdress,
								new JLabel(""))),
							giveContainerWithText(showThisTextDown));
			}

		}
		catch (Exception e)	//java.net.ConnectException: Connection refused: connect
		{
			theProgramWindow.setStatusText("No Internet connection detected!");

			JTextField txtIPAdress=new JTextField("http://www.javascript.nu/xerver/", 17);
			txtIPAdress.setBackground(Color.white);
			txtIPAdress.setEditable(false);
			txtIPAdress.setFont(defaultFont);

			String [] showThisTextUp=new String [5];
			showThisTextUp[0]="No Internet connection detected!";
			showThisTextUp[1]="";
			showThisTextUp[2]="Xerver failed to connect to Internet.";
			showThisTextUp[3]="";
			showThisTextUp[4]="You can find the latest version of Xerver at the official Xerver website:";

			return 	GUIMethods.showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						make2ContainersTo1ContainerBeside(
							txtIPAdress,
							new JLabel(""))));
		}
	}

	public static double getLatestVersion() throws Exception
	{
		double versionNumber=-1;
		//try {
			URL updateFile=new URL("http://www.javascript.nu/xerver/currentversion.js");
			BufferedReader inStr=new BufferedReader(new InputStreamReader(updateFile.openStream()));
			String tmpStr;
			while ((tmpStr=inStr.readLine())!=null)
			{
				if (tmpStr.startsWith("newestVersion"))
				{
					String versionNumberStr=tmpStr.substring(tmpStr.indexOf("\"")+1,tmpStr.lastIndexOf("\""));
					versionNumber=(new Double(versionNumberStr)).doubleValue();
				}
			}
		//} catch (Exception e) {System.out.println(e);}
		return versionNumber;
	}



	private void initSwingButtons()
	{
		DLM_listWithAllIPConnected = new DefaultListModel();
		JL_allIPConnected=new JList(DLM_listWithAllIPConnected);
		JL_allIPConnected.setFont(new Font("Courier", Font.PLAIN, 12));
		JL_allIPConnected.setVisibleRowCount(12);
		JL_allIPConnected.setFixedCellHeight(12);
		JL_allIPConnected.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION); 	//SINGLE_SELECTION);
		JL_allIPConnected.setSelectedIndex(0);
		//JSP_IPScrollPane = new JScrollPane(JL_allIPConnected);

		JSP_IPScrollPane = new JScrollPane();
		JSP_IPScrollPane.getViewport().add(JL_allIPConnected);

		JP_IPPanel=new JPanel();
		JP_IPPanel.setLayout(new BoxLayout(JP_IPPanel, BoxLayout.X_AXIS));
		JP_IPPanel.add(JSP_IPScrollPane);

		JCB_showWhatStatistic=new JCheckBox[7];
		JCB_showWhatStatistic[0]=new JCheckBox("IP/Host",true);
		JCB_showWhatStatistic[1]=new JCheckBox("Status Code",false);
		JCB_showWhatStatistic[2]=new JCheckBox("Extension",false);
		JCB_showWhatStatistic[3]=new JCheckBox("Zone",false);
		JCB_showWhatStatistic[4]=new JCheckBox("UserName",false);
		JCB_showWhatStatistic[5]=new JCheckBox("Date",true);
		JCB_showWhatStatistic[6]=new JCheckBox("File",true);

		for (int i=0 , showWhatStatisticLength=JCB_showWhatStatistic.length; i<showWhatStatisticLength; i++)	//Optimization...
			JCB_showWhatStatistic[i].setFont(defaultFont);

		for (int i=0 , showWhatStatisticLength=JCB_showWhatStatistic.length; i<showWhatStatisticLength; i++)	//Optimization...
			JCB_showWhatStatistic[i].addActionListener(this);


		JTF_showStatisticFieldLength=new JTextFieldInt[7];
		JTF_showStatisticFieldLength[0]=new JTextFieldInt(30,3);
		JTF_showStatisticFieldLength[1]=new JTextFieldInt(14,3);
		JTF_showStatisticFieldLength[2]=new JTextFieldInt(6,3);
		JTF_showStatisticFieldLength[3]=new JTextFieldInt(10,3);
		JTF_showStatisticFieldLength[4]=new JTextFieldInt(10,3);
		JTF_showStatisticFieldLength[5]=new JTextFieldInt(15,3);
		JTF_showStatisticFieldLength[6]=new JTextFieldInt("Inf",3);	//doesn't matter, this isn't used anyway, but we want [JTF_showStatisticFieldLength.length==JCB_showWhatStatistic.length]
		JTF_showStatisticFieldLength[6].setEditable(false);
		JTF_showStatisticFieldLength[6].setEnabled(false);

		JTF_nrRows = new JTextFieldInt(MAX_STATS_ITEMS,3);

		for (int i=0 , showStatisticFieldLengthLength=JTF_showStatisticFieldLength.length; i<showStatisticFieldLengthLength; i++)	//Optimization...
		{
			JTF_showStatisticFieldLength[i].setFont(defaultFont);
			JTF_showStatisticFieldLength[i].setColumns(3);
			JTF_showStatisticFieldLength[i].addActionListener(this);
			JTF_showStatisticFieldLength[i].getDocument().addDocumentListener(this);
		}

		JTF_nrRows.setFont(defaultFont);
		JTF_nrRows.setColumns(3);
		JTF_nrRows.addFocusListener(this);
		JTF_nrRows.getDocument().addDocumentListener(this);

		JTF_hitsField=new JTextField(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfHits+"")+" hits",8);
		JTF_bytesField=new JTextField(MyString.makeNumberToStringWithApostrophe(NewConnection.totalNumberOfBytesDownloaded+"")+" bytes",11);
		JTF_connectionsField=new JTextField(MyString.makeNumberToStringWithApostrophe(XerverKernel.getInstance().getNumberOfActiveConnections()+"")+" connections",9);
	}



	private void updateStatList()
	{
		HitStatistic.showIP=JCB_showWhatStatistic[0].isSelected();
		HitStatistic.showStatusCode=JCB_showWhatStatistic[1].isSelected();
		HitStatistic.showFileExtension=JCB_showWhatStatistic[2].isSelected();
		HitStatistic.showLoginRealm=JCB_showWhatStatistic[3].isSelected();
		HitStatistic.showLoginUserName=JCB_showWhatStatistic[4].isSelected();
		HitStatistic.showHitDate=JCB_showWhatStatistic[5].isSelected();
		HitStatistic.showFileLocation=JCB_showWhatStatistic[6].isSelected();
/*
		for (int i=0; i<JTF_showStatisticFieldLength.length; i++)
			if (JTF_showStatisticFieldLength[i].getText().equals(""))
				JTF_showStatisticFieldLength[i].setText("0");
*/
		try
		{
			if (!JTF_showStatisticFieldLength[0].getText().equals(""))
				HitStatistic.showLengthIP=Integer.parseInt(JTF_showStatisticFieldLength[0].getText());

			if (!JTF_showStatisticFieldLength[1].getText().equals(""))
				HitStatistic.showLengthStatusCode=Integer.parseInt(JTF_showStatisticFieldLength[1].getText());

			if (!JTF_showStatisticFieldLength[2].getText().equals(""))
				HitStatistic.showLengthFileExtension=Integer.parseInt(JTF_showStatisticFieldLength[2].getText());

			if (!JTF_showStatisticFieldLength[3].getText().equals(""))
				HitStatistic.showLengthLoginRealm=Integer.parseInt(JTF_showStatisticFieldLength[3].getText());

			if (!JTF_showStatisticFieldLength[4].getText().equals(""))
				HitStatistic.showLengthLoginUserName=Integer.parseInt(JTF_showStatisticFieldLength[4].getText());

			if (!JTF_showStatisticFieldLength[5].getText().equals(""))
				HitStatistic.showLengthHitDate=Integer.parseInt(JTF_showStatisticFieldLength[5].getText());
		}
		catch (Exception e)	//There is not an integer in the fields
		{
			if (b_showErrors)System.out.println("An error has occured @ updateStatList:\n"+e.getMessage());
		}
		//JL_allIPConnected.repaint();
		JSP_IPScrollPane.repaint();
	}




	public void actionPerformed( ActionEvent event )
	{
		updateStatList();
	}


	/**
	* Required by FocusListener interface.
	* Is executed when we give focus to objects that have ".addFocusListener(this);".
	*/
	public void focusGained(FocusEvent e)
	{
		//Do nothing
	}

	/**
	* Required by FocusListener interface.
	* Is executed when focus is lost in objects that have ".addFocusListener(this);".
	*/
	public void focusLost(FocusEvent e)
	{
		if (e.getSource() == JTF_nrRows)
		{
			//Max log entries
			if (!JTF_nrRows.getText().equals(""))
			{
				MAX_STATS_ITEMS=Integer.parseInt(JTF_nrRows.getText());
				synchronized(DLM_listWithAllIPConnected)
				{
					//Take lock for the list and remove all entries that are too many
					while (MAX_STATS_ITEMS >= 0 && DLM_listWithAllIPConnected.size() > MAX_STATS_ITEMS+1)	//Note the +1 because the first entry is not really a log entry but just the header (showing "IP/Host", "Date" etc.)
						DLM_listWithAllIPConnected.remove(1);
				}
			}
		}
	}

	public void insertUpdate(DocumentEvent e)
	{
		updateStatList();
	}

	public void removeUpdate(DocumentEvent e)
	{
		updateStatList();
	}


	public void changedUpdate(DocumentEvent e)
	{
		updateStatList();
	}
}


