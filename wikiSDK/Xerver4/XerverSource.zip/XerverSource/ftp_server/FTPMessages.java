//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.awt.*;
import javax.swing.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This class only contains static methods.
 * It returns Containers with texts such as "FTP server started",
 * "FTP setup shut down" etc. which are used in the Swing mode of Xerver.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


public class FTPMessages extends GUIMethods
{
	public static final int START_FTP=0;
	public static final int STOP_FTP=1;
	public static final int START_FTP_SETUP=2;
	public static final int STOP_FTP_SETUP=3;
	public static final int SERVER_PORT_IN_USE=4;
	public static final int SETUP_PORT_IN_USE=5;
	public static final int SERVER_PORT_ERROR=6;
	public static final int SETUP_PORT_ERROR=7;

	public static Container getContainer(int show)
	{
		switch (show)
		{
			case START_FTP:
				return showStartFTP();
			case STOP_FTP:
				return showStopFTP();
			case START_FTP_SETUP:
				return showStartFTPSetup();
			case STOP_FTP_SETUP:
				return showStopFTPSetup();
			case SERVER_PORT_IN_USE:
				return showServerPortInUse();
			case SETUP_PORT_IN_USE:
				return showSetupPortInUse();
			case SERVER_PORT_ERROR:
				return showServerPortError();
			case SETUP_PORT_ERROR:
				return showSetupPortError();
		}
		return null;
	}

	private static Container showStartFTP()
	{
		Container cont=new Container();
		cont.setLayout(new BorderLayout());

		JTextField addressInfo;
		JTextField addressInfo2;
		JLabel txtAboveIP;
		JLabel txtAboveIP2;


		Container theFields=new Container();
		theFields.setLayout(new BoxLayout(theFields, BoxLayout.Y_AXIS));

		txtAboveIP=new JLabel("Your server's outer IP is:");
		String s_outerIP = HostInfo.getOuterIP();	//Returns null if not detected
		if (s_outerIP != null)
		{
			addressInfo=new JTextField(s_outerIP,17);
		}
		else
		{
			addressInfo=new JTextField("IP could not be detected!",17);
		}

		txtAboveIP2=new JLabel("Your server's local IP is:  ");
		addressInfo2=new JTextField(HostInfo.getLocalIP(),17);

		JLabel textTop = new JLabel("Xerver Free FTP Server has been started!");
		JLabel textBottom = new JLabel("Server is running on port "+FTPServerController.getPort()+".");

		txtAboveIP.setFont(defaultFont);
		txtAboveIP2.setFont(defaultFont);
		textTop.setFont(defaultFont);
		textBottom.setFont(defaultFont);

		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(textTop,ProgramWindow.EMPTY_JLABEL));
		theFields.add(new JLabel(" "));
		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP,MenuOptions.make2ContainersTo1ContainerBeside(addressInfo,ProgramWindow.aboutOuterIPButton)),ProgramWindow.EMPTY_JLABEL));
		theFields.add(new JLabel(" "));
		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP2,MenuOptions.make2ContainersTo1ContainerBeside(addressInfo2,ProgramWindow.aboutLocalIPButton)),ProgramWindow.EMPTY_JLABEL));
		theFields.add(new JLabel(" "));
		theFields.add(MenuOptions.make2ContainersTo1ContainerBeside(textBottom,ProgramWindow.EMPTY_JLABEL));

		cont.add(MenuOptions.make2ContainersTo1ContainerAbove(MenuOptions.make2ContainersTo1ContainerBeside(theFields,ProgramWindow.EMPTY_JLABEL),ProgramWindow.EMPTY_JLABEL),BorderLayout.CENTER);
		//Cont.add(MenuOptions.make2ContainersTo1ContainerAbove(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP,addressInfo),EMPTY_JLABEL),EMPTY_JLABEL),BorderLayout.CENTER);
		//Cont.add(MenuOptions.make2ContainersTo1ContainerBeside(MenuOptions.make2ContainersTo1ContainerAbove(txtAboveIP2,addressInfo2),EMPTY_JLABEL),BorderLayout.SOUTH);
		return cont;

//		return MenuOptions.make2ContainersTo1ContainerAbove(MenuOptions.make2ContainersTo1ContainerBeside(theFields,ProgramWindow.EMPTY_JLABEL),ProgramWindow.EMPTY_JLABEL);


			/*
			String [] showThisTextUp=new String [3], showThisTextDown=new String [2];
			showThisTextUp[0]="Xerver Free FTP Server has been started!";
			showThisTextUp[1]="";
			showThisTextUp[2]="Host: ";
			showThisTextDown[0]="";
			showThisTextDown[1]="Server is running on port "+FTPServerController.getPort()+".";
			JTextField txtIPAdress=new JTextField(FTPServerController.getIP(), 17);
			txtIPAdress.setBackground(Color.white);
			txtIPAdress.setEditable(true);
			txtIPAdress.setFont(defaultFont);
			return 	make2ContainersTo1ContainerAbove(
					make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						make2ContainersTo1ContainerBeside(
							txtIPAdress,
							new JLabel(""))),
						giveContainerWithText(showThisTextDown));
						*/

	}

	private static Container showStopFTP()
	{
			String [] showThisTextUp=new String [1];
			showThisTextUp[0]="Xerver Free FTP Server has been shut down!";

			return 	showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						new JLabel("")));

	}

	private static Container showStartFTPSetup()
	{
		String [] showThisTextUp=new String [3], showThisTextDown=new String [2];
		showThisTextUp[0]="Xerver Remote Setup has been turned on!";
		showThisTextUp[1]="";
		showThisTextUp[2]="A remote administrator can now change settings to Xerver at:";

		JTextField txtIPAdress;
		String s_outerIP = HostInfo.getOuterIP();	//Returns null if not detected
		if (s_outerIP != null)
		{
			txtIPAdress=new JTextField("http://"+s_outerIP+":32124/", 17);
		}
		else
		{
			txtIPAdress=new JTextField("IP could not be detected!", 17);
		}

		txtIPAdress.setBackground(Color.white);
		txtIPAdress.setEditable(true);
		txtIPAdress.setFont(defaultFont);
		showThisTextDown[0]="";
		showThisTextDown[1]="Please turn off Xerver Remote Setup when you feel you are done!";
		return make2ContainersTo1ContainerAbove(make2ContainersTo1ContainerAbove(giveContainerWithText(showThisTextUp),make2ContainersTo1ContainerBeside(txtIPAdress,new JLabel(""))),giveContainerWithText(showThisTextDown));
	}

	private static Container showStopFTPSetup()
	{

		String [] showThisTextUp=new String [7];
		//String [] showThisTextMiddle=new String [3];
		//String [] showThisTextDown=new String [1];
		showThisTextUp[0]="Xerver FTP Remote Setup has been shut down!";
		showThisTextUp[1]="";
		showThisTextUp[2]="Other people from Internet can no longer change settings to the setup.";
		showThisTextUp[3]="Only you can change settings to the setup now.";
		showThisTextUp[4]="";
		showThisTextUp[5]="Note that the local FTP Setup only shuts down when you shut down Xerver.";
		showThisTextUp[6]="";
		JTextField localIPAddress=new JTextField("http://"+HostInfo.getLocalIP()+":32124/", 17);
		localIPAddress.setBackground(Color.white);
		localIPAddress.setEditable(true);
		localIPAddress.setFont(defaultFont);
		//showThisTextMiddle[0]="";
		//showThisTextMiddle[1]="or";
		//showThisTextMiddle[2]="";
		JTextField outerIPAddress=new JTextField("http://"+HostInfo.getOuterIP()+":32124/", 17);
		outerIPAddress.setBackground(Color.white);
		outerIPAddress.setEditable(true);
		outerIPAddress.setFont(defaultFont);
		//showThisTextDown[0]="";
		/*
		return make2ContainersTo1ContainerAbove(
						make2ContainersTo1ContainerAbove(
							giveContainerWithText(showThisTextUp),
							make2ContainersTo1ContainerBeside(
								outerIPAddress,
								new JLabel(""))),
						giveContainerWithText(showThisTextDown)
				);
				*/

		JLabel outerIPLabel = new JLabel("Your outer IP:   ");
		JLabel localIPLabel = new JLabel("Your local IP:   ");

		outerIPLabel.setFont(defaultFont);
		localIPLabel.setFont(defaultFont);
		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints constraint = new GridBagConstraints();
		constraint.gridwidth = GridBagConstraints.REMAINDER;
		constraint.anchor = GridBagConstraints.WEST;
		constraint.fill = GridBagConstraints.NONE;
		Container con=new Container();
		con.setLayout(gridbag);
		//con.setLayout(new BoxLayout());
		Container tmpCon;

		tmpCon = giveContainerWithText(showThisTextUp);
		con.add(tmpCon);
		gridbag.setConstraints(tmpCon,constraint);

		//tmpCon = make2ContainersTo1ContainerBeside(localIPLabel,localIPAddress);
		tmpCon = make2ContainersTo1ContainerBeside(	make2ContainersTo1ContainerAbove(localIPLabel,outerIPLabel),
													make2ContainersTo1ContainerAbove(localIPAddress,outerIPAddress));
		con.add(tmpCon);
		gridbag.setConstraints(tmpCon,constraint);

		//tmpCon = giveContainerWithText(showThisTextMiddle);
		//con.add(tmpCon);
		//gridbag.setConstraints(tmpCon,constraint);

		//tmpCon = make2ContainersTo1ContainerBeside(outerIPLabel,outerIPAddress);
		//con.add(tmpCon);
		//gridbag.setConstraints(tmpCon,constraint);

		//tmpCon = giveContainerWithText(showThisTextDown);
		//con.add(tmpCon);
		//gridbag.setConstraints(tmpCon,constraint);

		return make2ContainersTo1ContainerBeside(con,new JLabel());

	}

	private static Container showServerPortInUse()
	{
			String [] showThisTextUp=new String [6];
			showThisTextUp[0]="Xerver FTP Server can't start since port "+FTPServerController.getPort()+" is already in use!";
			showThisTextUp[1]="";
			showThisTextUp[2]="Please start FTP Setup and change which port shall be used.";
			showThisTextUp[3]="";
			showThisTextUp[4]="It is also possible that you have another instance of";
			showThisTextUp[5]="Xerver FTP Setup running using this port number.";

			return 	showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						new JLabel("")));
	}

	private static Container showSetupPortInUse()
	{
			String [] showThisTextUp=new String [6];
			showThisTextUp[0]="Xerver FTP Setup can't start the setup at port "+FTPServerController.getSetupPort()+" since the port is already in use!";
			showThisTextUp[1]="";
			showThisTextUp[2]="Please close any other application using this port and try again.";
			showThisTextUp[3]="";
			showThisTextUp[4]="It is also possible that you have another instance of";
			showThisTextUp[5]="Xerver FTP Setup running using this port number.";

			return 	showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						new JLabel("")));
	}

	private static Container showServerPortError()
	{
			String [] showThisTextUp=new String [3];
			showThisTextUp[0]="Xerver FTP Server can't start since port "+FTPServerController.getPort()+" is an invalid port number!";
			showThisTextUp[1]="";
			showThisTextUp[2]="Please start FTP Setup and change which port shall be used.";

			return 	showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						new JLabel("")));
	}

	private static Container showSetupPortError()
	{
			String [] showThisTextUp=new String [1];
			showThisTextUp[0]="Xerver FTP Setup can't start the setup at port "+FTPServerController.getSetupPort()+" since it is an invalid port number!";

			return 	showAsNorthBorderLayout(
						make2ContainersTo1ContainerAbove(
						giveContainerWithText(showThisTextUp),
						new JLabel("")));
	}
}



