//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################

package ftp_server;
import webserver.*;
import common.*;
import java.io.File;




/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is similar to <CODE>MyHashTable</CODE> except this is comparing
 * keys cAsE sEnSiTiVe when using Windows and cAsE iNsEnSiTiVe when
 * when using for example UNIX, Linux, Mac etc.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


//Note: To make MyHashTable CaSe SeNsItIvE, change all "equalsIgnoreCase" to "equals"
final public class MyHashTableWithPaths
{
	private String [] sa_keys;
	private String [] sa_values;
	//private String s_wholeString;
	private int i_sizeOfArray;
	private static boolean isWindows=File.separatorChar=='\\';


	/**
	* Creates a hash table with <CODE>separator1=","</CODE> and <CODE>separator2="="</CODE>
	* @param txtToMakeHashWith "key1=value1,key2=value2,key3=value3"
	*/
	public MyHashTableWithPaths(String txtToMakeHashWith)
	{
		this(txtToMakeHashWith, ",", "=");
	}


	/**
	* @param txtToMakeHashWith = "key1=value1,key2=value2,key3=value3"
	* @param separator1 by default <CODE>==','</CODE>;
	* @param separator2 by default <CODE>=='='</CODE>;
	*/
	public MyHashTableWithPaths(String txtToMakeHashWith, String separator1, String separator2)
	{
		String s_wholeString=txtToMakeHashWith;	//Previously this was a global variable
		String [] sa_nyckelVardePar=MyString.makeArrayOfString(txtToMakeHashWith, separator1);
		i_sizeOfArray=sa_nyckelVardePar.length;
		sa_keys=new String[i_sizeOfArray];
		sa_values=new String[i_sizeOfArray];

		for (int i=0; i<i_sizeOfArray; i++)
		{
			if (sa_nyckelVardePar[i].indexOf(separator2)!=-1)
			{
				sa_keys[i]=sa_nyckelVardePar[i].substring(0,sa_nyckelVardePar[i].indexOf(separator2));
				sa_values[i]=sa_nyckelVardePar[i].substring(sa_nyckelVardePar[i].indexOf(separator2)+separator2.length());
			}
			else
			{
				sa_keys[i]=sa_nyckelVardePar[i];
				sa_values[i]="";
			}
		}
	}


	/**
	* This will unescape (<CODE>Mystring.unescape(java.lang.String)</CODE>) all values stored in this HashTable.
	*/
	public void unescapeAllValues()
	{
		for (int i=0; i<i_sizeOfArray; i++)
		{
			sa_values[i]=MyString.unescape(sa_values[i]);
		}
	}


	/**
	* All values in this HashTable will be unescaped and all plus signes (+) will be converted into spaces ( ) (<CODE>Mystring.unescapeMakePlusesIntoSpaces(java.lang.String)</CODE>).
	*/
	public void unescapeMakePlusesIntoSpacesAllValues()
	{
		for (int i=0; i<i_sizeOfArray; i++)
		{
			sa_values[i]=MyString.unescapeMakePlusesIntoSpaces(sa_values[i]);
		}
	}

	/**
	* Give the value at "index" <CODE>key</CODE>.
	* @return Returns null if key doesn't exist.
	*/
	public String giveValueByIndex(String key)
	{
/*
		//not necessery, but makes this method faster (is this really faster?)
		if (s_wholeString.indexOf(key)==-1)
			return null;
*/

		for (int i=0; i<i_sizeOfArray; i++)
			if (keyEqual(key, sa_keys[i]))
				return sa_values[i];

		return null;
	}



	/**
	* Give the unescaped value at "index" <CODE>key</CODE>.
	* @return Returns null if key doesn't exist.
	*/
	public String giveUnescapedValueByIndex(String key)
	{
/*
		//not necessery, but makes this method faster (is this really faster?)
		if (s_wholeString.indexOf(key)==-1)
			return null;
*/

		for (int i=0; i<i_sizeOfArray; i++)
			if (keyEqual(key,sa_keys[i]))
				return MyString.unescape(sa_values[i]);

		return null;
	}

	/**
	* If the <CODE>bigKey</CODE> is "aaabcd" and there is an index "aaa" and an index "aa", then "aaa".lenth() (=3) is returned (<CODE>bigKey</CODE> shall be longer than the real index).
	* @return Returns -1 if key doesn't exist
	*/
	public int giveBiggestKeySize(String bigKey)
	{
		if (bigKey==null)
			return -1;

		int largestCurrentKey=-1;

		for (int i=0 , sharedPathsLength=sa_keys.length; i<sharedPathsLength; i++)	//Optimization...
		{
			String tmpDir=sa_keys[i];//.replace('\\','/');

			if (tmpDir.endsWith("*"))
			{
				int pathLengthWithAsterix=tmpDir.length()-1;
				if (largestCurrentKey<pathLengthWithAsterix)
				{
					if (tmpDir.regionMatches(isWindows,0,bigKey,0,pathLengthWithAsterix))
					{
						if (largestCurrentKey<pathLengthWithAsterix)
							largestCurrentKey=pathLengthWithAsterix;
					}
				}
			}
			else if (keyEqual(tmpDir,bigKey))
			{
				int lengthNow=tmpDir.length();
				if (largestCurrentKey<lengthNow)
					largestCurrentKey=lengthNow;
			}
		}

/*
		for (int i=0; i<i_sizeOfArray; i++)
		{
			if (bigKey.length()>=sa_keys[i].length())
				if (keyEqual(sa_keys[i],bigKey.substring(0,sa_keys[i].length())))
					if (sa_keys[i].length()>largestCurrentKey)
						largestCurrentKey=sa_keys[i].length();
		}
*/

		return largestCurrentKey;
}


	/**
	* This is instead of an "equal()" or "equalIgnoreCase()" so we can choose when we shall consider
	* @return Returns true if k1 and k2 equals each other
	*/
	private boolean keyEqual(String k1, String k2)
	{
		if (isWindows)	//If Windows...
		{
			return k1.equalsIgnoreCase(k2);
		}
		else
		{
			return k1.equals(k2);
		}
	}
}
