//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################


package common;
import webserver.*;
import ftp_server.*;
import java.io.*;
import java.net.*;





/**
 *
 * <B>About this class:</B>
 * <BR>
 * Classes you can use to get a computers outer IP.
 * <BR>
 * Note that this class connects to www.javascript.nu to get the outer IP.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class HostInfo
{
	private static String s_IPstored=null;
	private static String s_forcedLocalIP = null;
	private static String s_forcedOuterIP = null;

	/**
	* Set the local IP.
	* We will no longer try to obtain the local IP address from the computer.
	*/
	public static void setLocalIP(String s_ip)
	{
		if (s_ip != null && !s_ip.equals(""))
		{
			s_forcedLocalIP = s_ip;
		}
	}

	/**
	* Set the outer IP.
	* We will no longer try to obtain the outer IP address from internet.
	*/
	public static void setOuterIP(String s_ip)
	{
		if (s_ip != null && !s_ip.equals(""))
		{
			s_forcedOuterIP = s_ip;
		}
	}

	/**
	* Returns computers outer IP.
	* If no internet connection is found or if www.javascript.nu is down it returns <CODE>InetAddress.getLocalHost().getHostAddress()</CODE>.
	* <BR>
	* Exception are only thrown from "InetAddress.getLocalHost().getHostAddress()", which should not happen under normal circumstances(??).
	*/
	static public String getIP() throws Exception
	{
		if (s_forcedOuterIP != null)
			return s_forcedOuterIP;

		String s_IP=getIPFromInternet();
		if (s_IP==null)
			s_IP=InetAddress.getLocalHost().getHostAddress();

		return s_IP;
	}


	/**
	* Returns local computers host name.
	* <BR>
	* If <CODE>InetAddress.getLocalHost()</CODE> throws an Exception "localhost" is returned.
	*/
	static public String getLocalHostNameOrLocalhost()
	{
		try
		{
			return InetAddress.getLocalHost().getHostName();
		}
		catch (Exception e)
		{
			return "localhost";
		}
	}


	/**
	* Returns computers outer IP.
	* Returns null if no internet connection is found or if website is down.
	*/
	//
	static private String getIPFromInternet()
	{
		if (s_IPstored!=null)
		{
			return s_IPstored;
		}

		try
		{
			URL updateFile=new URL("http://www.javascript.nu/xerver/scripts/getip.pl");
			BufferedReader inStr=new BufferedReader(new InputStreamReader(updateFile.openStream()));
			String tmpStr;

			while ((tmpStr=inStr.readLine())!=null)
			{
				if (tmpStr.startsWith("outerIP"))
				{
					s_IPstored=tmpStr.substring(tmpStr.indexOf("\"")+1,tmpStr.lastIndexOf("\""));
				}
			}

			return s_IPstored;
		}
		catch (Exception e)
		{
			return null;
		}
	}


	/**
	* Returns computers outer IP address.
	* Returns null if not found.
	*/
	static public String getOuterIP()
	{
		try
		{
			if (s_forcedOuterIP != null)
				return s_forcedOuterIP;

			return getIPFromInternet();
		}
		catch (Exception e)
		{
			return null;
		}
	}

	/**
	* Returns computers local IP address.
	* Returns null if not found.
	*/
	static public String getLocalIP()
	{
		try
		{
			if (s_forcedLocalIP != null)
				return s_forcedLocalIP;

			return InetAddress.getLocalHost().getHostAddress();
		}
		catch (Exception e)
		{
			return null;
		}
	}


	/**
	* Returns computers outer IP address.
	* Returns "localhost" if not found.
	*/
	static public String getOuterIPOrLocalhost()
	{
		String s_ip = getOuterIP();
		return (s_ip == null) ? ("localhost") : s_ip;
	}

	/**
	* Returns computers local IP address.
	* Returns "localhost" if not found.
	*/
	static public String getLocalIPOrLocalhost()
	{
		String s_ip = getLocalIP();
		return (s_ip == null) ? "localhost" : s_ip;
	}
}

