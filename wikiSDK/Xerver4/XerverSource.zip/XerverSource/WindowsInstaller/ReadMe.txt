Xerver is an Open Source project (developed 2002-2007).

If you need help, free support is available at:
http://www.JavaScript.nu/xerver/

Please enjoy using Xerver!