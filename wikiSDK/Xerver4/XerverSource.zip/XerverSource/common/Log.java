//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package common;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;


/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is used to write events to the log file.
 * <BR>
 * All the methods are static, so you can call the methods directly without keeping track of a corresponding object.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */



public class Log
{
	private static final boolean b_showErrors=false;
	private String s_logFileName;
	private BufferedWriter bw_logFile;


	public Log(String logFile)
	{
		try
		{
			if (logFile != null && !logFile.equals(""))
			{
				File f_file = new File(logFile);
				s_logFileName = f_file.getAbsolutePath();
				bw_logFile = new BufferedWriter(new FileWriter(f_file, true));	//true = append
			}
			else
			{
				bw_logFile = null;	//Don't log anything
			}

		}
		catch (Exception e)
		{
			bw_logFile = null;	//Don't log anything
			showError(e);
		}
	}


	public void writeToLog(String s)
	{
		try
		{
			if (bw_logFile != null)
			{
				//synchronized(bw_logFile)
				//{
					bw_logFile.write(s);
					bw_logFile.newLine();
					bw_logFile.flush();
				//}
			}
		}
		catch (Exception e)
		{
			showError(e);
		}
	}


	private static void showError(Exception e)
	{
		if (b_showErrors)
		{
			System.out.println("Error: " + e);
			e.printStackTrace();
		}
	}


	protected void finalize() throws Throwable
	{
		if (bw_logFile != null)
		{
			bw_logFile.flush();
			bw_logFile.close();	//Close BufferedWriter it it is already open
			bw_logFile = null;
		}
	}

	public String getFileName()
	{
		return s_logFileName;
	}
}