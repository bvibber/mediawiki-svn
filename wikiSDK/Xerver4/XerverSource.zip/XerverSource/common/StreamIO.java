//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################




package common;
import webserver.*;
import common.*;
import java.io.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * <CODE>StreamIO</CODE> contains only static classes.
 * <BR>
 * By the name of the members you are supposed to understand what they do. ;)
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */

final public class StreamIO
{
	final static private boolean b_showErrors=false;


	static public void writeStreamToStream(InputStream is, OutputStream os)
	{
		try
		{
			int n;
			byte [] buffer=new byte [8192];
			while ((n=is.read(buffer))!=-1)
			{
				os.write(buffer,0,n);
			}

			os.flush();
		} catch (Exception e) {if (b_showErrors)System.out.println("An error has occured @ writeStreamToStream:\n"+e);}

	}


	static public void writeFileToStream(File theFile, OutputStream os)
	{
		writeFileToStream(theFile, os, 0);
	}

	static public void writeFileToStream(File theFile, OutputStream os, int i_startPosition)
	{
		FileInputStream fileStreamed=null;

		try
		{
			//setPriority(MIN_PRIORITY);
			int numberOfBytesThatWillBeSent=0;
			fileStreamed=new FileInputStream(theFile);
			fileStreamed.skip(i_startPosition);		//Skippa i_startPosition bytes of data from the file

			byte [] myBuffer = new byte[8192];//	40960];	//2048*20	(I tested and this value seems to give a very high speed when you download files)


			while ((numberOfBytesThatWillBeSent=fileStreamed.read(myBuffer))!=-1)
			{
				os.write(myBuffer,0,numberOfBytesThatWillBeSent);
			}

			//NO MORE TIMEOUT STUFF:	yield();
			//NO MORE TIMEOUT STUFF:	sleep(50);	//Be safe, don't close before all data has been sent

			//setPriority(NORM_PRIORITY);
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}

		try
		{
			if (fileStreamed!=null)	//If fileStreamed "holds" a file
			{
				os.flush();
				fileStreamed.close();	//Important: This must be reached no matter what! Even if an exception occurs in the try block, whis must be reached. Otherwise the file will be locked by Xerver (locked by Java.exe) until the garbage collector is runned (and you don't know when it will run) and detects that the file (the object "fileStreamed") is no longer referenced from anywhere else and it release the file by automatic. Until this happenes, no other application can write to or rename this file (however, this problem is solved with this line).
			}
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFileToStream:\n"+e.getMessage());
		}
	}


	static public void writeASCIIFileToStream(File theFile, OutputStream os)
	{
		writeFileToStream(theFile, os, 0);
	}


	static public void writeFile(String s_theFile, DataInputStreamWithReadLine bis, boolean b_append)
	{
		FileOutputStream fileStreamed=null;

		try
		{
			//setPriority(MIN_PRIORITY);
			int numberOfBytesThatWillBeSent=0;
			fileStreamed=new FileOutputStream(s_theFile, b_append);

			byte [] myBuffer = new byte[8192];//	40960];	//2048*20	(i tested and this value seems to give a very high speed when you download files)


			while ((numberOfBytesThatWillBeSent=bis.read(myBuffer))!=-1)
			{
				fileStreamed.write(myBuffer,0,numberOfBytesThatWillBeSent);
			}

			//NO MORE TIMEOUT STUFF:	yield();
			//NO MORE TIMEOUT STUFF:	sleep(50);	//Be safe, don't close before all data has been sent

			//setPriority(NORM_PRIORITY);
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFile:\n"+e.getMessage());
		}

		try
		{
			if (fileStreamed!=null)	//If fileStreamed "holds" a file
			{
				fileStreamed.flush();
				fileStreamed.close();	//Important: This must be reached no matter what! Even if an exception occurs in the try block, whis must be reached. Otherwise the file will be locked by Xerver (locked by Java.exe) until the garbage collector is runned (and you don't know when it will run) and detects that the file (the object "fileStreamed") is no longer referenced from anywhere else and it release the file by automatic. Until this happenes, no other application can write to or rename this file (however, this problem is solved with this line).
			}
		}
		catch (Exception e)
		{
			if (b_showErrors)
				System.out.println("An error occured @ writeFile:\n"+e.getMessage());
		}
	}
}


