//  Xerver Free Web Server
//  Copyright (C) 2002-2007 Omid Rouhani
//
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
//  #############################################################
//  ##  YOU CAN CONTACT THE AUTHOR (OMID ROUHANI) AT:          ##
//  ##  HTTP://WWW.JAVASCRIPT.NU/XERVER/                       ##
//  ##                                                         ##
//  ##  IF YOUR SOFTWARE IS NOT RELEASED UNDER THE             ##
//  ##  GNU GENERAL PUBLIC LICENSE (GPL),                      ##
//  ##  PLEASE DO NOT COPY ANYTHING FROM THIS SOURCE CODE!!!   ##
//  ##                                                         ##
//  ##  FOR FULL LICENSE, PLEASE READ "XERVER LICENSE".        ##
//  #############################################################



package ftp_server;
import webserver.*;
import common.*;
import ftp_server.*;
import java.io.*;
import java.util.*;



/**
 *
 * <B>About this class:</B>
 * <BR>
 * This is doing a directory listing with the format used by DIR in MS-DOS.
 *
 * @author <a href="http://www.JavaScript.nu/xerver/" TARGET="_top">Omid Rouhani</a>
 * @version 1.0
 */


final public class MSDosListing
{
	private File f_folder;
	private String s_path;
	private boolean isValidDirectory=false;

	private final static boolean b_showErrors=false;

	public MSDosListing(String argPath)
	{
		s_path=argPath;
		f_folder=new File(s_path);
		if (f_folder.isDirectory())
			isValidDirectory=true;
	}

	public boolean isValidDirectory()
	{
		return isValidDirectory;
	}

	/**
	* Send the line that is related to this file when we do a normal folder listing.
	*/
	public void sendFileInfo(DataOutputStream bos) throws Exception
	{
		if (isValidDirectory)
		{
			sendDirectoryListing(bos);	//If the argument gave a folder, list the content of the folder
		}
		else
		{
			System.out.println("Start send info about file");
			MyGregorianCalendar tmpDate=new MyGregorianCalendar();
			int hour, minute, sec, year, day, month, length, am_pm;
			String tmpStr;
			StringBuffer sb_tmpStr;
			String tmpLengthAsString;

			sb_tmpStr=new StringBuffer(70);	//Example, "06-06-01  04:51AM                   84 MYFILE1.TXT" is 50 chars
			tmpDate.mySetTimeInMillis(f_folder.lastModified());
			hour=tmpDate.get(GregorianCalendar.HOUR);
			minute=tmpDate.get(GregorianCalendar.MINUTE);
			day=tmpDate.get(GregorianCalendar.DAY_OF_MONTH);
			month=tmpDate.get(GregorianCalendar.MONTH);
			year=tmpDate.get(GregorianCalendar.YEAR);
			am_pm=tmpDate.get(GregorianCalendar.AM_PM);
			year=year%100;

			month++;

			if (month<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(month+"-");

			if (day<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(day+"-");

			if (year<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(year+"  ");

			if (hour<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(hour+":");

			if (minute<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(minute);

			if (am_pm==GregorianCalendar.PM)
				sb_tmpStr.append("PM       ");
			else
				sb_tmpStr.append("AM       ");

			//Note, here we know that f_folder is a file, not a directory...
			tmpLengthAsString=""+f_folder.length();
			int timesToLoop=14-tmpLengthAsString.length();
			for (int j=0; j<timesToLoop; j++)
			{
				sb_tmpStr.append(" ");
			}
			sb_tmpStr.append(tmpLengthAsString+" ");


			sb_tmpStr.append(f_folder.getName());

			bos.writeBytes(sb_tmpStr.toString()+"\r\n");
			bos.flush();
			System.out.println("Stop send info about file");
		}
	}

	/**
	* Send the directory listing to bos.
	*/
	public void sendDirectoryListing(DataOutputStream bos) throws Exception
	{
//		try {
		String [] as_allFilesAndFolders;
		int i_numberOfFiles;
		as_allFilesAndFolders=f_folder.list();
		if (as_allFilesAndFolders != null)
		{
			i_numberOfFiles=as_allFilesAndFolders.length;
		}
		else
		{
			throw new Exception("Could not get directory listing. The folder might not exist.");
		}

		//Om vi hade velat sortera:	Arrays.sort(allFilesAndFolders, new ComparatorIgnoreCase());

		File tmpFile;
		MyGregorianCalendar tmpDate=new MyGregorianCalendar();
		int hour, minute, sec, year, day, month, length, am_pm;
		String tmpStr;
		StringBuffer sb_tmpStr;
		String tmpLengthAsString;
		for (int i=0; i<i_numberOfFiles; i++)
		{
			sb_tmpStr=new StringBuffer(70);	//Example, "06-06-01  04:51AM                   84 MYFILE1.TXT" is 50 chars
			tmpFile=new File(s_path+as_allFilesAndFolders[i]);
			tmpDate.mySetTimeInMillis(tmpFile.lastModified());
			hour=tmpDate.get(GregorianCalendar.HOUR);
			minute=tmpDate.get(GregorianCalendar.MINUTE);
			day=tmpDate.get(GregorianCalendar.DAY_OF_MONTH);
			month=tmpDate.get(GregorianCalendar.MONTH);
			year=tmpDate.get(GregorianCalendar.YEAR);
			am_pm=tmpDate.get(GregorianCalendar.AM_PM);
			year=year%100;

			month++;

			if (month<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(month+"-");

			if (day<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(day+"-");

			if (year<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(year+"  ");

			if (hour<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(hour+":");

			if (minute<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(minute);

			if (am_pm==GregorianCalendar.PM)
				sb_tmpStr.append("PM       ");
			else
				sb_tmpStr.append("AM       ");

			if (tmpFile.isDirectory())
			{
				sb_tmpStr.append("<DIR>          ");
			}
			else
			{
				tmpLengthAsString=""+tmpFile.length();
				int timesToLoop=14-tmpLengthAsString.length();
				for (int j=0; j<timesToLoop; j++)
				{
					sb_tmpStr.append(" ");
				}
				sb_tmpStr.append(tmpLengthAsString+" ");
			}

			sb_tmpStr.append(as_allFilesAndFolders[i]);

			bos.writeBytes(sb_tmpStr.toString()+"\r\n");
			//bos.writeBytes("+s1234,\t"+as_allFilesAndFolders[i]+"\r\n");
		}
//		} catch (Exception e) {if (b_showErrors)System.out.println("Error @ sendDirectoryListing:\n"+e);}
		bos.flush();
	}





	/**
	* Send the directory listing to bos. However, each line starts with "213-".
	*/
	public void sendDirectoryListingAsResponseFormat(DataOutputStream bos) throws Exception
	{
//		try {
		String [] as_allFilesAndFolders;
		int i_numberOfFiles;
		as_allFilesAndFolders=f_folder.list();
		if (as_allFilesAndFolders != null)
		{
			i_numberOfFiles=as_allFilesAndFolders.length;
		}
		else
		{
			throw new Exception("Could not get directory listing. The folder might not exist.");
		}
		//Om vi hade velat sortera:	Arrays.sort(allFilesAndFolders, new ComparatorIgnoreCase());


		bos.writeBytes("213-STAT directory listing:\r\n");

		File tmpFile;
		MyGregorianCalendar tmpDate=new MyGregorianCalendar();
		int hour, minute, sec, year, day, month, length, am_pm;
		String tmpStr;
		StringBuffer sb_tmpStr;
		String tmpLengthAsString;
		for (int i=0; i<i_numberOfFiles; i++)
		{
			sb_tmpStr=new StringBuffer(70);	//Example, "06-06-01  04:51AM                   84 MYFILE1.TXT" is 50 chars
			tmpFile=new File(s_path+as_allFilesAndFolders[i]);
			tmpDate.mySetTimeInMillis(tmpFile.lastModified());
			hour=tmpDate.get(GregorianCalendar.HOUR);
			minute=tmpDate.get(GregorianCalendar.MINUTE);
			day=tmpDate.get(GregorianCalendar.DAY_OF_MONTH);
			month=tmpDate.get(GregorianCalendar.MONTH);
			year=tmpDate.get(GregorianCalendar.YEAR);
			am_pm=tmpDate.get(GregorianCalendar.AM_PM);
			year=year%100;

			month++;

			if (month<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(month+"-");

			if (day<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(day+"-");

			if (year<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(year+"  ");

			if (hour<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(hour+":");

			if (minute<10)
				sb_tmpStr.append(0);
			sb_tmpStr.append(minute);

			if (am_pm==GregorianCalendar.PM)
				sb_tmpStr.append("PM       ");
			else
				sb_tmpStr.append("AM       ");

			if (tmpFile.isDirectory())
			{
				sb_tmpStr.append("<DIR>          ");
			}
			else
			{
				tmpLengthAsString=""+tmpFile.length();
				int timesToLoop=14-tmpLengthAsString.length();
				for (int j=0; j<timesToLoop; j++)
				{
					sb_tmpStr.append(" ");
				}
				sb_tmpStr.append(tmpLengthAsString+" ");
			}

			sb_tmpStr.append(as_allFilesAndFolders[i]);

			bos.writeBytes("213-"+sb_tmpStr.toString()+"\r\n");
			//bos.writeBytes("+s1234,\t"+as_allFilesAndFolders[i]+"\r\n");
		}
//		} catch (Exception e) {if (b_showErrors)System.out.println("Error @ sendDirectoryListingAsResponseFormat:\n"+e);}
		bos.flush();
	}


	/**
	* Send a alias listing as if the aliases where directories.
	*/
	static public void sendAliasListing(DataOutputStream bos, String [] aliases) throws Exception
	{
		String tmpAlias;
		for (int i=0; i<aliases.length; i++)
		{
			tmpAlias=aliases[i];
			bos.writeBytes("01-01-01  01:01AM       <DIR>          "+tmpAlias+"\r\n");
		}
		bos.flush();
	}


	/**
	* Send a alias listing as if the aliases where directories. However, each line starts with "213-".
	*/
	static public void sendAliasListingAsResponseFormat(DataOutputStream bos, String [] aliases) throws Exception
	{
		String tmpAlias;
		for (int i=0; i<aliases.length; i++)
		{
			tmpAlias=aliases[i];
			bos.writeBytes("213-01-01-01  01:01AM       <DIR>          "+tmpAlias+"\r\n");
		}
	}





	/**
	* Send a HTML-page where you can choose a folder located at <CODE>argPath</CODE>.
	*/
	static public void showChooseDirectory(DataOutputStream os, String argPath)
	{
try {
		String s_path=argPath;
		PathInfo PI_path=new PathInfo(s_path);
		File f_currentFolder		=PI_path.getCurrentFolder();	//This is null if "argPath" given to the constructor is (1) null, (2) "", (3) an invalid path or (4) an unreadable path, such as A: without a floppy disk.
		File [] af_allFiles		=PI_path.getAllFiles();
		boolean directoryIsValid=PI_path.getDirectoryIsValid();


		os.writeBytes("<HTML><HEAD>"+
					"<TITLE>Choose directory!</TITLE>"+
					"<SCRIPT LANGUAGE=javascript>"+
					"function chooseDir(path)"+
					"{"+
					"  if (opener==null || opener==\"undefined\")"+
					"  {"+
					"    alert(\"An error has occured: Please close the \\\"Choose a directory\\\" window and re-open again before you can choose a directory.\");"+
					"  }"+
					"  else"+
					"  {"+
					"    if (path.substring(path.length-1,path.length)!=\"/\" && path.substring(path.length-1,path.length)!=\"\\\\\")"+		 //Path is a normal folder, not a root... //If path is a root path already has an / (or \) in the end, but if path is just a normal folder there is no / (or \) in path
					"    {"+
					"      path+=\"\\"+File.separator+"\";"+			// Will result in: path+="\\";  or  path+="\/";
					"    }"+
					"    opener.dirChoosen(path);"+
					"    top.close();"+
					"  }"+
					"}"+
					""+
					""+
					"function replace(str,oldChar,newChar)"+
					"{"+
					"	for (i=0;i<str.length; i++)"+
					"	{"+
					"		if (str.substring(i,i+1)==oldChar)"+
					"			str=str.substring(0,i)+newChar+str.substring(i+1,str.length);"+
					"	}"+
					""+
					"	return str;"+
					"}"+
					""+
					"</SCRIPT>"+
					"</HEAD><BODY>"+
					"<FONT FACE=\"tahoma, arial, verdana\">"+
					"<H2>Choose a directory");
		if (f_currentFolder!=null && directoryIsValid)
			os.writeBytes(" [ "+f_currentFolder.toString()+" ]");
		os.writeBytes("</H2>");

		if (!directoryIsValid)
		{
			os.writeBytes("Xerver had problems try to find or read <B>"+s_path+"</B>."+
						"<BR>"+
						"Listing your roots instead!"+
						"<P>");
		}
		os.writeBytes("Choose a directory by pressing the Choose-button."+
					"<BR>"+
					"Browse a directory by pressing the directory name."+
					"</FONT>"+
					"<P>"+
					"<PRE>");

		if (f_currentFolder!=null) //If [All roots are NOT being listed]...
		{
			os.writeBytes("<B>[<A HREF=\"javascript:chooseDir(\'"+MyString.searchAndReplace(MyString.searchAndReplace(f_currentFolder.toString(),"\\","\\\\"),"'","\\'")+"\');\" STYLE=\"text-decoration: none;\">Choose this folder</A>]&nbsp;&nbsp;&nbsp;"+f_currentFolder.toString()+"</B>\r\n");
			os.writeBytes("\r\n");

			File f_oneLevelUp=f_currentFolder.getParentFile();

			if (f_oneLevelUp!=null)	//This is NOT root level, so show a ".." link
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"#\" onClick=\"location='/?action=chooseDirectory&currentPath='+replace(escape('"+MyString.searchAndReplace(MyString.searchAndReplace(f_oneLevelUp.toString(),"\\","\\\\"),"'","\\'")+"'),'+','%2B')\" STYLE=\"text-decoration: none;\">../</A>\r\n");
			else //This is the root letter, press ".." to show all drives
				os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF='/?action=chooseDirectory' STYLE=\"text-decoration: none;\">../</A>\r\n");
		}

		Arrays.sort(af_allFiles);
		boolean tmpFoldersShown=false;
		for (int i=0 , allFilesLength=af_allFiles.length; i<allFilesLength; i++)
		{
			File tmpFile=af_allFiles[i];
			if (f_currentFolder==null || tmpFile.isDirectory()) //If [it's a directory] OR [All roots are being listed]...
			{
				tmpFoldersShown=true;
				os.writeBytes("[<A HREF=\"javascript:chooseDir(\'"+MyString.searchAndReplace(MyString.searchAndReplace(tmpFile.toString(),"\\","\\\\"),"'","\\'")+"\');\" STYLE=\"text-decoration: none;\">Choose</A>]&nbsp;&nbsp;&nbsp;<A HREF=\"#\" onClick=\"location='/?action=chooseDirectory&currentPath='+replace(escape('"+MyString.searchAndReplace(MyString.searchAndReplace(tmpFile.toString(),"\\","\\\\"),"'","\\'")+"'),'+','%2B')\" STYLE=\"text-decoration: none;\">"+tmpFile+"</A>\r\n");
			}
		}
		if (!tmpFoldersShown)
		{
			os.writeBytes("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No folders exists in\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>"+s_path+"</B>");
		}
		os.writeBytes("</PRE>");
		os.writeBytes("</BODY>");
		os.writeBytes("</HTML>");
}catch(Exception e){if (b_showErrors)System.out.println("An error has occured @ showChooseDirectory:\n"+e);}
	}
}



